import test from 'node:test';
import assert from 'node:assert/strict';
import { canTransitionSessionState, createEnvelope, encodeEnvelope, isValidEnvelope } from '../dist/index.js';

test('session lifecycle is strict', () => {
  assert.equal(canTransitionSessionState('created', 'negotiating'), true);
  assert.equal(canTransitionSessionState('created', 'connected'), false);
  assert.equal(canTransitionSessionState('connected', 'created'), false);
  assert.equal(canTransitionSessionState('closed', 'negotiating'), false);
});

test('envelope validation and size boundary are enforced', () => {
  const e = createEnvelope('session.state', 'ABCDEFGH', 0, { fps: 60 });
  assert.equal(isValidEnvelope(e), true);
  assert.doesNotThrow(() => encodeEnvelope(e));
  assert.throws(() => createEnvelope('session.state', 'bad', 0, {}));
  assert.throws(() => encodeEnvelope({ ...e, payload: { data: 'x'.repeat(300_000) } }));
});
