export const PROTOCOL_NAME = 'NEXORA' as const;
export const PROTOCOL_VERSION = 1 as const;
export const MAX_ENVELOPE_BYTES = 256 * 1024;
export const MAX_PAYLOAD_KEYS = 64;

export const SESSION_TRANSITIONS: Readonly<Record<SessionState, readonly SessionState[]>> = {
  created: ['negotiating', 'closed'],
  negotiating: ['connected', 'disconnected', 'closed'],
  connected: ['disconnected'],
  disconnected: ['negotiating', 'closed'],
  closed: []
};

export type SessionState =
  | 'created'
  | 'negotiating'
  | 'connected'
  | 'disconnected'
  | 'closed';

export type MessageType =
  | 'auth'
  | 'pair.open'
  | 'pair.request'
  | 'pair.accept'
  | 'pair.reject'
  | 'pair.opened'
  | 'session.open'
  | 'session.state'
  | 'sdp.offer'
  | 'sdp.answer'
  | 'ice.candidate'
  | 'session.close';

export interface Envelope<T = unknown> {
  protocol: typeof PROTOCOL_NAME;
  version: typeof PROTOCOL_VERSION;
  type: MessageType;
  sessionId: string;
  sequence: number;
  timestamp: number;
  payload: T;
}

const MESSAGE_TYPES = new Set<MessageType>([
  'auth', 'pair.open', 'pair.request', 'pair.accept', 'pair.reject', 'pair.opened',
  'session.open', 'session.state', 'sdp.offer', 'sdp.answer', 'ice.candidate', 'session.close'
]);

const SESSION_ID_RE = /^[A-Za-z0-9_-]{8,128}$/;

export function isValidSessionId(value: unknown): value is string {
  return typeof value === 'string' && SESSION_ID_RE.test(value);
}

export function canTransitionSessionState(from: SessionState, to: SessionState): boolean {
  return SESSION_TRANSITIONS[from].includes(to);
}

export function isMessageType(value: unknown): value is MessageType {
  return typeof value === 'string' && MESSAGE_TYPES.has(value as MessageType);
}

export function isValidEnvelope(value: unknown): value is Envelope {
  if (!value || typeof value !== 'object') return false;
  const v = value as Record<string, unknown>;
  if (v.protocol !== PROTOCOL_NAME || v.version !== PROTOCOL_VERSION) return false;
  if (!isMessageType(v.type) || !isValidSessionId(v.sessionId)) return false;
  if (!Number.isSafeInteger(v.sequence) || (v.sequence as number) < 0) return false;
  if (!Number.isSafeInteger(v.timestamp) || (v.timestamp as number) < 0) return false;
  if (!v.payload || typeof v.payload !== 'object' || Array.isArray(v.payload)) return false;
  if (Object.keys(v.payload as object).length > MAX_PAYLOAD_KEYS) return false;
  return true;
}

export function createEnvelope<T extends Record<string, unknown>>(
  type: MessageType,
  sessionId: string,
  sequence: number,
  payload: T,
  now = Date.now()
): Envelope<T> {
  if (!isMessageType(type)) throw new Error('Invalid message type');
  if (!isValidSessionId(sessionId)) throw new Error('Invalid session ID');
  if (!Number.isSafeInteger(sequence) || sequence < 0) throw new Error('Invalid sequence');
  if (!Number.isSafeInteger(now) || now < 0) throw new Error('Invalid timestamp');
  if (Object.keys(payload).length > MAX_PAYLOAD_KEYS) throw new Error('Payload too large');
  return {
    protocol: PROTOCOL_NAME,
    version: PROTOCOL_VERSION,
    type,
    sessionId,
    sequence,
    timestamp: now,
    payload
  };
}

export function encodeEnvelope(envelope: Envelope): string {
  if (!isValidEnvelope(envelope)) throw new Error('Invalid envelope');
  const encoded = JSON.stringify(envelope);
  if (new TextEncoder().encode(encoded).byteLength > MAX_ENVELOPE_BYTES) {
    throw new Error('Envelope exceeds maximum size');
  }
  return encoded;
}
