/**
 * NEXORA key / controller map
 *
 * Uses Xbox-style button names (industry standard — works with Xbox, DualSense
 * via Steam Input, Switch Pro via common drivers, and touch overlays).
 * Two directions:
 *  - controller mode: keyboard keys become gamepad buttons (Cricket 22 and similar)
 *  - keyboard mode: gamepad buttons become keyboard keys
 */

export const GAMEPAD_BUTTONS = [
  'A', 'B', 'X', 'Y',
  'L1', 'R1', 'L2', 'R2',
  'L3', 'R3',
  'Start', 'Select',
  'DpadUp', 'DpadDown', 'DpadLeft', 'DpadRight'
] as const;

export const GAMEPAD_AXES = [
  'LeftStickX', 'LeftStickY', 'RightStickX', 'RightStickY'
] as const;

export type GamepadButton = (typeof GAMEPAD_BUTTONS)[number];
export type GamepadAxis = (typeof GAMEPAD_AXES)[number];

/** Browser / OS-neutral keyboard codes (KeyboardEvent.code style). */
export type KeyCode = string;

export interface KeyBinding {
  /** Gamepad button or axis name */
  control: string;
  /** Keyboard code, e.g. KeyW, Space, ArrowUp, Digit1 */
  key: KeyCode;
  /** For axes: which direction maps to key press (negative | positive) */
  axisDir?: 'neg' | 'pos';
}

export interface KeyMapProfile {
  id: string;
  name: string;
  /** short label for UI */
  description: string;
  genre: 'universal' | 'action' | 'racing' | 'shooter' | 'sports' | 'rpg' | 'custom';
  version: 1;
  bindings: KeyBinding[];
}

const ID_RE = /^[A-Za-z0-9_-]{1,32}$/;
const KEY_RE = /^[A-Za-z0-9_.:-]{1,48}$/;
const CONTROL_RE = /^[A-Za-z0-9_.:-]{1,48}$/;

/** Common aliases from DualSense / Switch / generic HID → Xbox-style names */
const BUTTON_ALIASES: Record<string, string> = {
  Cross: 'A', Circle: 'B', Square: 'X', Triangle: 'Y',
  South: 'A', East: 'B', West: 'X', North: 'Y',
  BtnA: 'A', BtnB: 'B', BtnX: 'X', BtnY: 'Y',
  LB: 'L1', RB: 'R1', LT: 'L2', RT: 'R2',
  L: 'L1', R: 'R1', ZL: 'L2', ZR: 'R2',
  Options: 'Start', Share: 'Select', Touchpad: 'Select',
  Menu: 'Start', View: 'Select', Plus: 'Start', Minus: 'Select',
  DPadUp: 'DpadUp', DPadDown: 'DpadDown', DPadLeft: 'DpadLeft', DPadRight: 'DpadRight',
  HatUp: 'DpadUp', HatDown: 'DpadDown', HatLeft: 'DpadLeft', HatRight: 'DpadRight'
};

export function normalizeControlName(code: string): string {
  const c = String(code || '').trim();
  if (!c) return c;
  if (BUTTON_ALIASES[c]) return BUTTON_ALIASES[c];
  // case-insensitive match on known buttons
  const lower = c.toLowerCase();
  for (const b of GAMEPAD_BUTTONS) {
    if (b.toLowerCase() === lower) return b;
  }
  for (const a of GAMEPAD_AXES) {
    if (a.toLowerCase() === lower) return a;
  }
  return c;
}

export function validateKeyMapProfile(v: unknown): v is KeyMapProfile {
  if (!v || typeof v !== 'object') return false;
  const x = v as Record<string, unknown>;
  if (!ID_RE.test(String(x.id))) return false;
  if (typeof x.name !== 'string' || x.name.length < 1 || x.name.length > 48) return false;
  if (typeof x.description !== 'string' || x.description.length > 120) return false;
  if (!['universal', 'action', 'racing', 'shooter', 'sports', 'rpg', 'custom'].includes(String(x.genre))) return false;
  if (x.version !== 1 || !Array.isArray(x.bindings) || x.bindings.length > 48) return false;
  const seen = new Set<string>();
  for (const b of x.bindings) {
    if (!b || typeof b !== 'object') return false;
    const row = b as Record<string, unknown>;
    if (typeof row.control !== 'string' || !CONTROL_RE.test(row.control)) return false;
    if (typeof row.key !== 'string' || !KEY_RE.test(row.key)) return false;
    if (row.axisDir !== undefined && row.axisDir !== 'neg' && row.axisDir !== 'pos') return false;
    const k = `${row.control}:${row.axisDir ?? ''}`;
    if (seen.has(k)) return false;
    seen.add(k);
  }
  return true;
}

export function normalizeKeyMapProfile(p: KeyMapProfile): KeyMapProfile {
  if (!validateKeyMapProfile(p)) throw new Error('Invalid key map profile');
  return {
    ...p,
    name: p.name.trim(),
    description: p.description.trim(),
    bindings: p.bindings.map(b => ({
      control: normalizeControlName(b.control),
      key: b.key,
      ...(b.axisDir ? { axisDir: b.axisDir } : {})
    }))
  };
}

function b(control: string, key: string, axisDir?: 'neg' | 'pos'): KeyBinding {
  return axisDir ? { control, key, axisDir } : { control, key };
}

/** WASD + Space/Shift style — works for many PC ports */
export function createDefaultKeyMap(genre: KeyMapProfile['genre'] = 'universal'): KeyMapProfile {
  const common: KeyBinding[] = [
    b('A', 'Space'),
    b('B', 'KeyF'),
    b('X', 'KeyR'),
    b('Y', 'KeyE'),
    b('L1', 'KeyQ'),
    b('R1', 'KeyC'),
    b('L2', 'ControlLeft'),
    b('R2', 'ShiftLeft'),
    b('Start', 'Escape'),
    b('Select', 'Tab'),
    b('DpadUp', 'ArrowUp'),
    b('DpadDown', 'ArrowDown'),
    b('DpadLeft', 'ArrowLeft'),
    b('DpadRight', 'ArrowRight'),
    b('LeftStickY', 'KeyW', 'neg'),
    b('LeftStickY', 'KeyS', 'pos'),
    b('LeftStickX', 'KeyA', 'neg'),
    b('LeftStickX', 'KeyD', 'pos')
  ];

  if (genre === 'racing') {
    return {
      id: 'keymap_racing',
      name: 'Racing',
      description: 'Drive with WASD, boost with A, brake with B',
      genre: 'racing',
      version: 1,
      bindings: [
        b('A', 'ShiftLeft'),
        b('B', 'Space'),
        b('X', 'KeyR'),
        b('Y', 'KeyE'),
        b('L1', 'KeyQ'),
        b('R1', 'KeyE'),
        b('L2', 'KeyS'),
        b('R2', 'KeyW'),
        b('Start', 'Escape'),
        b('Select', 'Tab'),
        b('DpadLeft', 'ArrowLeft'),
        b('DpadRight', 'ArrowRight'),
        b('LeftStickX', 'KeyA', 'neg'),
        b('LeftStickX', 'KeyD', 'pos'),
        b('LeftStickY', 'KeyW', 'neg'),
        b('LeftStickY', 'KeyS', 'pos')
      ]
    };
  }

  if (genre === 'shooter') {
    return {
      id: 'keymap_shooter',
      name: 'Shooter',
      description: 'Move WASD, aim sticks → arrows, fire R2',
      genre: 'shooter',
      version: 1,
      bindings: [
        b('A', 'Space'),
        b('B', 'ControlLeft'),
        b('X', 'KeyR'),
        b('Y', 'KeyF'),
        b('L1', 'KeyQ'),
        b('R1', 'KeyE'),
        b('L2', 'KeyG'),
        b('R2', 'MouseLeft'),
        b('Start', 'Escape'),
        b('Select', 'Tab'),
        b('DpadUp', 'Digit1'),
        b('DpadDown', 'Digit2'),
        b('DpadLeft', 'Digit3'),
        b('DpadRight', 'Digit4'),
        b('LeftStickY', 'KeyW', 'neg'),
        b('LeftStickY', 'KeyS', 'pos'),
        b('LeftStickX', 'KeyA', 'neg'),
        b('LeftStickX', 'KeyD', 'pos'),
        b('RightStickY', 'ArrowUp', 'neg'),
        b('RightStickY', 'ArrowDown', 'pos'),
        b('RightStickX', 'ArrowLeft', 'neg'),
        b('RightStickX', 'ArrowRight', 'pos')
      ]
    };
  }

  if (genre === 'sports') {
    return {
      id: 'keymap_sports',
      name: 'Sports (Cricket and more)',
      description: 'Keyboard acts like an Xbox controller for Cricket 22 and sports titles',
      genre: 'sports',
      version: 1,
      bindings: [
        b('LeftStickY', 'KeyW', 'neg'),
        b('LeftStickY', 'KeyS', 'pos'),
        b('LeftStickX', 'KeyA', 'neg'),
        b('LeftStickX', 'KeyD', 'pos'),
        b('RightStickY', 'ArrowUp', 'neg'),
        b('RightStickY', 'ArrowDown', 'pos'),
        b('RightStickX', 'ArrowLeft', 'neg'),
        b('RightStickX', 'ArrowRight', 'pos'),
        b('A', 'Space'),
        b('B', 'KeyF'),
        b('X', 'KeyR'),
        b('Y', 'KeyE'),
        b('L1', 'KeyQ'),
        b('R1', 'KeyC'),
        b('L2', 'ControlLeft'),
        b('R2', 'ShiftLeft'),
        b('L3', 'KeyZ'),
        b('R3', 'KeyX'),
        b('Start', 'Enter'),
        b('Select', 'Tab'),
        b('DpadUp', 'Digit1'),
        b('DpadDown', 'Digit2'),
        b('DpadLeft', 'Digit3'),
        b('DpadRight', 'Digit4')
      ]
    };
  }

  return {
    id: `keymap_${genre === 'custom' ? 'universal' : genre}`,
    name: genre === 'universal' ? 'Universal' : genre[0].toUpperCase() + genre.slice(1),
    description:
      genre === 'action' ? 'Jump, attack, and move - great for adventure games'
      : genre === 'rpg' ? 'Confirm, cancel, menu - classic RPG feel'
      : 'Standard layout for most games',
    genre: genre === 'custom' ? 'universal' : genre,
    version: 1,
    bindings: common
  };
}

export function listBuiltinKeyMaps(): KeyMapProfile[] {
  return (['universal', 'action', 'racing', 'shooter', 'sports', 'rpg'] as const).map(g => createDefaultKeyMap(g));
}

/**
 * Turn a gamepad-style InputEvent into zero or more keyboard/mouse InputEvents
 * using the active profile. Pass-through when mapping mode is off.
 */
export function mapGamepadEventToKeys(
  event: {
    kind: string;
    action: string;
    code: string;
    value?: number;
    sequence: number;
    timestamp: number;
  },
  profile: KeyMapProfile | null,
  opts?: { axisThreshold?: number }
): Array<{ kind: 'key' | 'mouse-button'; action: 'down' | 'up'; code: string; sequence: number; timestamp: number }> {
  if (!profile) return [];
  const threshold = opts?.axisThreshold ?? 0.45;
  const control = normalizeControlName(event.code);
  const out: Array<{ kind: 'key' | 'mouse-button'; action: 'down' | 'up'; code: string; sequence: number; timestamp: number }> = [];

  const emit = (key: string, action: 'down' | 'up') => {
    const kind = key.startsWith('Mouse') ? 'mouse-button' as const : 'key' as const;
    out.push({
      kind,
      action,
      code: key,
      sequence: event.sequence,
      timestamp: event.timestamp
    });
  };

  if (event.kind === 'gamepad-button') {
    const binds = profile.bindings.filter(b => b.control === control && !b.axisDir);
    for (const bind of binds) {
      if (event.action === 'down' || event.action === 'up') emit(bind.key, event.action);
    }
    return out;
  }

  if (event.kind === 'gamepad-axis' || (event.kind === 'gamepad-button' && event.value !== undefined)) {
    const value = typeof event.value === 'number' ? event.value : 0;
    const pos = profile.bindings.find(b => b.control === control && b.axisDir === 'pos');
    const neg = profile.bindings.find(b => b.control === control && b.axisDir === 'neg');
    // Caller tracks previous axis state for up/down edges; here we only emit when clearly active.
    // InputManager edge-tracking will refine; emit down for active side when |value| high.
    if (pos && value >= threshold) emit(pos.key, 'down');
    if (neg && value <= -threshold) emit(neg.key, 'down');
    if (pos && value < threshold && value > -threshold) emit(pos.key, 'up');
    if (neg && value < threshold && value > -threshold) emit(neg.key, 'up');
    return out;
  }

  return out;
}


/**
 * Keyboard / mouse -> gamepad (games that require a controller, e.g. Cricket 22).
 */
export function mapKeyEventToGamepad(
  event: {
    kind: string;
    action: string;
    code: string;
    value?: number;
    sequence: number;
    timestamp: number;
  },
  profile: KeyMapProfile | null
): Array<{
  kind: 'gamepad-button' | 'gamepad-axis';
  action: 'down' | 'up' | 'move';
  code: string;
  value?: number;
  sequence: number;
  timestamp: number;
}> {
  if (!profile) return [];
  if (event.kind !== 'key' && event.kind !== 'mouse-button') return [];

  const out: Array<{
    kind: 'gamepad-button' | 'gamepad-axis';
    action: 'down' | 'up' | 'move';
    code: string;
    value?: number;
    sequence: number;
    timestamp: number;
  }> = [];

  for (const bind of profile.bindings) {
    if (bind.key !== event.code) continue;

    if (bind.axisDir) {
      let value = 0;
      if (event.action === 'down') value = bind.axisDir === 'pos' ? 1 : -1;
      out.push({
        kind: 'gamepad-axis',
        action: 'move',
        code: normalizeControlName(bind.control),
        value,
        sequence: event.sequence,
        timestamp: event.timestamp
      });
    } else {
      if (event.action !== 'down' && event.action !== 'up') continue;
      out.push({
        kind: 'gamepad-button',
        action: event.action,
        code: normalizeControlName(bind.control),
        value: event.action === 'down' ? 1 : 0,
        sequence: event.sequence,
        timestamp: event.timestamp
      });
    }
  }
  return out;
}
