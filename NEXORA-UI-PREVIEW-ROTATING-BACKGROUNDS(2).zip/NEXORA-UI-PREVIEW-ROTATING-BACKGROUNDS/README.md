# NEXORA — UI Preview Edition (Empty Library + Rotating Backgrounds)

This is a **visual UI-testing build**, not a finished Windows application. It preserves the frosted-glass NEXORA Desktop/Console prototype that we designed, while intentionally leaving the game library empty so the UI can be inspected before game adding is implemented.

## Run the preview

1. Extract this ZIP.
2. Double-click `PREVIEW.bat` in the project root.
3. It opens `design-reference/current-frosted-glass-ui-prototype/index.html` in your default browser.

No dependency installation or program build is required to inspect the UI. The preview buttons do not add games, launch executables, pair devices, or stream media.

## Empty-library background rotation

When the preview opens, the empty-library backdrop advances to the next local wallpaper in this order:

1. Space Horizon
2. Nebula
3. Forest Vista
4. Earth Orbit

The fourth entry wraps back to Space Horizon. The selected wallpaper is applied to the prototype hero, outer backdrop, and Console backdrop. The rotation remembers its position using browser local storage. If the browser blocks storage for local files, the preview falls back to a time-based selection.

## What changed for this UI test

- Removed preloaded demonstration games from Dashboard, Library, and Console Mode.
- Preserved the previous frosted-glass layout, navigation, UI structure, typography, and controller-style Console switch.
- Added the four wallpaper assets locally, so no network download is needed for the backgrounds.
- Kept Add Game controls as visual placeholders for a later phase; they only show a message and do not create game records.
- Kept `PREVIEW.bat` as the **only batch file**. No build or installer BAT files are included yet.

## Important distinction

The original Electron renderer is still at `apps/host/src/ui/`. The intended frosted-glass design remains in `design-reference/current-frosted-glass-ui-prototype/`. This preview launcher opens the prototype intentionally so it does not send you back to the legacy/dismantled UI. **This ZIP does not claim the prototype has been merged into the live Electron renderer.** That integration will be done after the UI preview is approved.

## Source and validation

- `UI-PREVIEW-UPDATE.md` explains this delivery.
- `design-reference/current-frosted-glass-ui-prototype/empty-library-backgrounds.css` contains only backdrop and empty-state styles; the original `styles.css` and `refinement.css` are left unchanged.
- `design-reference/current-frosted-glass-ui-prototype/background-rotation.js` chooses the next wallpaper on each open.
- `design-reference/current-frosted-glass-ui-prototype/tests/empty-library-preview.test.cjs` covers no-game UI and rotation behavior.
- Existing Settings prototype tests remain available in the same `tests` folder.

This preview does not prove real Electron IPC, native window controls, game launching, device pairing, streaming, Windows startup, or installer behavior.
