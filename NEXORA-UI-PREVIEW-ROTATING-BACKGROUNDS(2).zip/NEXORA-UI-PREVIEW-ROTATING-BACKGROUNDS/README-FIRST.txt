NEXORA UI PREVIEW — READ FIRST

1. Extract the ZIP to a folder.
2. Double-click PREVIEW.bat.
3. It opens the built frosted-glass prototype at design-reference/current-frosted-glass-ui-prototype/index.html, not the old live renderer.
4. There are no preloaded games. Add Game is a placeholder and does not add anything.
5. Backgrounds cycle on each opening: Space Horizon → Nebula → Forest Vista → Earth Orbit → repeat.
6. This is a browser UI prototype, not a Windows program build. No build/installer BAT files are included; PREVIEW.bat is the only BAT file.
7. The real Electron renderer at apps/host/src/ui/ is preserved separately and has not been declared merged with this prototype.
