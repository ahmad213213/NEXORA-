﻿param(
  [Parameter(Mandatory=$true)][string]$Package,
  [Parameter(Mandatory=$true)][string]$InstallDir,
  [Parameter(Mandatory=$true)][int]$ProcessId,
  [Parameter(Mandatory=$true)][string]$Sha256,
  [Parameter(Mandatory=$true)][string]$Version
)
$ErrorActionPreference = 'Stop'

# The installed app's exe is NEXORA.exe (installer build); older portable builds used NEXORA-Host.exe. Accept either.
function Find-AppExe([string]$Dir) {
  foreach ($n in @('NEXORA.exe','NEXORA-Host.exe')) {
    $p = Join-Path $Dir $n
    if (Test-Path -LiteralPath $p) { return $p }
  }
  return $null
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$form = New-Object System.Windows.Forms.Form
$form.Text = 'NEXORA Update'
$form.Width = 520; $form.Height = 190
$form.StartPosition = 'CenterScreen'
$form.TopMost = $true
$status = New-Object System.Windows.Forms.Label
$status.Left = 24; $status.Top = 24; $status.Width = 450; $status.Text = "Preparing NEXORA $Version update…"
$bar = New-Object System.Windows.Forms.ProgressBar
$bar.Left = 24; $bar.Top = 62; $bar.Width = 450; $bar.Height = 24
$bar.Style = 'Continuous'; $bar.Minimum = 0; $bar.Maximum = 100
$detail = New-Object System.Windows.Forms.Label
$detail.Left = 24; $detail.Top = 98; $detail.Width = 450; $detail.Text = 'Waiting for NEXORA to close…'
$form.Controls.Add($status); $form.Controls.Add($bar); $form.Controls.Add($detail)
$form.Show()
[System.Windows.Forms.Application]::DoEvents()

function Set-Progress([int]$Value, [string]$StatusText, [string]$DetailText) {
  $bar.Value = [Math]::Max(0, [Math]::Min(100, $Value))
  $status.Text = $StatusText
  $detail.Text = $DetailText
  [System.Windows.Forms.Application]::DoEvents()
}
function Fail-Update([string]$Message) {
  Set-Progress 0 'Update failed' $Message
  [System.Windows.Forms.MessageBox]::Show($Message, 'NEXORA Update', 'OK', 'Error') | Out-Null
  exit 1
}

try {
  Set-Progress 5 'Closing NEXORA' 'Waiting for the exact Host process to exit…'
  for ($i = 0; $i -lt 60; $i++) {
    try { Get-Process -Id $ProcessId -ErrorAction Stop | Out-Null; Start-Sleep -Milliseconds 500; [System.Windows.Forms.Application]::DoEvents() }
    catch { break }
  }
  try { Get-Process -Id $ProcessId -ErrorAction Stop | Out-Null; throw 'NEXORA did not exit before the updater timeout.' } catch { if ($_.Exception.Message -like '*did not exit*') { throw } }

  Set-Progress 20 'Verifying package' 'Checking SHA-256…'
  $actualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Package).Hash
  if ($actualHash.ToLower() -ne $Sha256.ToLower()) { throw 'Update package SHA-256 does not match the signed manifest.' }

  Set-Progress 35 'Extracting update' 'Preparing a temporary installation…'
  $root = Join-Path $env:TEMP ('NEXORA-update-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force -Path $root | Out-Null
  Expand-Archive -LiteralPath $Package -DestinationPath $root -Force
  $candidate = $root
  foreach ($sub in @('NEXORA','NEXORA-Host')) {
    $subDir = Join-Path $root $sub
    if ((Test-Path -LiteralPath $subDir) -and (Find-AppExe $subDir)) { $candidate = $subDir; break }
  }
  if (-not (Find-AppExe $candidate)) { throw 'Updated NEXORA.exe was not found in the package.' }

  Set-Progress 55 'Backing up current version' 'Creating a rollback copy before replacement…'
  $backup = $InstallDir + '.backup-' + (Get-Date -Format 'yyyyMMddHHmmss')
  try {
    if (Test-Path $InstallDir) { Move-Item -LiteralPath $InstallDir -Destination $backup -ErrorAction Stop }
  } catch [System.UnauthorizedAccessException] {
    $args = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$PSCommandPath,'-Package',$Package,'-InstallDir',$InstallDir,'-ProcessId',$ProcessId,'-Sha256',$Sha256,'-Version',$Version)
    Start-Process powershell.exe -Verb RunAs -ArgumentList $args | Out-Null
    Set-Progress 100 'Administrator approval required' 'A Windows UAC prompt was opened for the protected installation.'
    Start-Sleep -Seconds 2
    exit 0
  }

  Set-Progress 70 'Installing update' 'Replacing application files atomically…'
  Move-Item -LiteralPath $candidate -Destination $InstallDir
  if (-not (Find-AppExe $InstallDir)) { throw 'Installation verification failed.' }

  Set-Progress 90 'Finalizing' 'Update installed successfully. Restarting NEXORA…'
  $appExe = Find-AppExe $InstallDir
  if (-not $appExe) { throw 'NEXORA.exe was not found after the update.' }
  Start-Process -FilePath $appExe
  if (Test-Path $backup) { Remove-Item -LiteralPath $backup -Recurse -Force -ErrorAction SilentlyContinue }
  Set-Progress 100 'Update complete' "NEXORA $Version is starting."
  Start-Sleep -Seconds 2
} catch {
  try {
    if ($backup -and (Test-Path $backup) -and -not (Test-Path $InstallDir)) { Move-Item -LiteralPath $backup -Destination $InstallDir -ErrorAction Stop }
  } catch { }
  Fail-Update $_.Exception.Message
} finally {
  if ($root) { Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue }
  $form.Close()
  $form.Dispose()
}
