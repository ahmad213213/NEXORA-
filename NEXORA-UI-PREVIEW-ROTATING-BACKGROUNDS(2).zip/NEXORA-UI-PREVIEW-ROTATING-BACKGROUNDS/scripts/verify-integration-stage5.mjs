import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(new URL('..', import.meta.url).pathname);
const checks = [
  ['health classifier exists', 'apps/host/src/integration/health.ts'],
  ['health tests exist', 'apps/host/test/integration-health.test.mjs'],
  ['connection flow exists', 'apps/host/src/integration/connection-flow.ts'],
  ['session orchestrator exists', 'apps/host/src/integration/session-orchestrator.ts'],
  ['WebRTC peer session exists', 'apps/host/src/webrtc/peer-session.ts'],
  ['Android WebRTC receiver exists', 'apps/receiver/android/app/src/main/java/com/nexora/receiver/webrtc/WebRtcReceiver.kt'],
  ['Android connection controller exists', 'apps/receiver/android/app/src/main/java/com/nexora/receiver/connection/ConnectionController.kt'],
  ['Windows SendInput adapter exists', 'apps/host/src/input/windows-send-input.ts'],
  ['stream manager exists', 'apps/host/src/streaming/stream-manager.ts'],
  ['production updater exists', 'apps/host/src/update/updater.ts'],
  ['stage 5 test plan exists', 'docs/INTEGRATION-STAGE5-TEST-PLAN.md'],
  ['stage 5 verification exists', 'docs/INTEGRATION-STAGE5-VERIFICATION.md']
];
let failed = 0;
for (const [label, rel] of checks) {
  const ok = fs.existsSync(path.join(root, rel));
  console.log(`${ok ? 'PASS' : 'FAIL'} ${label}`);
  if (!ok) failed++;
}
process.exitCode = failed ? 1 : 0;
