import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = p => fs.readFileSync(path.join(root,p),'utf8');
const checks = [];
function ok(name, cond){ checks.push([name,!!cond]); if(!cond) throw new Error(`FAIL: ${name}`); }
const html=read('apps/host/src/ui/index.html');
const js=read('apps/host/src/ui/app.js');
const main=read('apps/host/src/main.ts');
const rtc=read('apps/receiver/android/app/src/main/java/com/nexora/receiver/webrtc/WebRtcReceiver.kt');
const manifest=read('apps/receiver/android/app/src/main/AndroidManifest.xml');
const widx=read('apps/host/src/webrtc/index.ts');
const win=read('apps/host/src/input/windows-send-input.ts');
ok('metadata modal exists', html.includes('id="metadataModal"') && html.includes('id="candidateList"'));
ok('dashboard navigation exists', html.includes('data-view="dashboard"') && (html.includes('>Home</span>') || html.includes('>Dashboard</span>')));
ok('devices navigation exists', html.includes('data-view="devices"') && (html.includes('>Remote Play</span>') || html.includes('>Devices</span>')));
ok('settings owns update UI', !html.includes('id="update-check"') && js.includes('Check for updates'));
ok('no stale Part 4/5 UI promises', !js.includes('will connect in Part 4') && !js.includes('will connect in Part 5'));
ok('default layouts initialized', main.includes('await layoutController.ensureDefaults()'));
ok('webrtc index uses NodeNext-safe extension', widx.includes("'./peer-session.js'"));
ok('Android Internet permission', manifest.includes('android.permission.INTERNET'));
ok('Android WebRTC initialization is guarded', rtc.includes('initializeFactory(context)') && rtc.includes('Volatile private var initialized'));
ok('Windows input does not silently succeed', win.includes('Native Windows SendInput provider is not installed'));
ok('no obvious secret key material', !/-----BEGIN (RSA|EC|OPENSSH|PRIVATE) KEY-----/.test(read('README.md')));
// v3+ selection integrity (TDZ + consistent selected class)
ok('selectedGameId declared early (no TDZ)', /let selectedGameId = null;/.test(js) && js.indexOf('let selectedGameId = null;') < js.indexOf('function selectGame'));
ok('renderCard uses selectedGameId (not games[0])', js.includes("selectedGameId === game.id") && !js.includes("games[0]?.id === game.id"));
ok('remove clears selectedGameId when needed', js.includes('if (selectedGameId === game.id) selectedGameId = null;'));
// Contract-complete additions
const media = read('apps/host/src/webrtc/media-bridge.ts');
const winsink = read('apps/host/src/input/windows-send-input.ts');
ok('WebRtcMediaBridge exists and is honest about readiness', media.includes('class WebRtcMediaBridge') && media.includes('get ready()'));
ok('WindowsInputSink uses optional native loader', winsink.includes('nexora-sendinput') && winsink.includes('get available()'));
console.log(checks.map(([n,p])=>`${p?'PASS':'FAIL'} ${n}`).join('\n'));
console.log(`${checks.filter(x=>x[1]).length}/${checks.length} PASS`);
