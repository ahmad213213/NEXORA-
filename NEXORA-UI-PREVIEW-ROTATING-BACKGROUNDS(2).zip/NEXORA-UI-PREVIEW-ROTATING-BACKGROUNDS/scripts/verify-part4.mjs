import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('..', import.meta.url).pathname);
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const checks = [
  ['streaming types', 'apps/host/src/streaming/types.ts', [/interface StreamingConfig/, /interface MediaSink/, /interface StreamStats/]],
  ['FFmpeg video builder', 'apps/host/src/streaming/ffmpeg.ts', [/ddagrab/, /gdigrab/, /h264_nvenc/, /h264_qsv/, /h264_amf/, /libx264/, /-f', 'rtp'/]],
  ['FFmpeg audio builder', 'apps/host/src/streaming/ffmpeg.ts', [/dshow/, /libopus/, /48000/, /-ac', '2'/]],
  ['encoder fallback', 'apps/host/src/streaming/capture-engine.ts', [/encoder_fallback/, /this\.encoder = 'x264'/]],
  ['generation ownership', 'apps/host/src/streaming/capture-engine.ts', [/generation/, /generation !== this\.generation/]],
  ['bounded audio recovery', 'apps/host/src/streaming/capture-engine.ts', [/audioRestarts < 2/, /audio_disabled/]],
  ['quality normalization', 'apps/host/src/streaming/ffmpeg.ts', [/clampQuality/, /25000/]],
  ['adaptive bitrate', 'apps/host/src/streaming/adaptive-bitrate.ts', [/packetLossPct/, /cooldown/, /step/]],
  ['stream manager', 'apps/host/src/streaming/stream-manager.ts', [/class StreamManager/, /setBitrate/, /setAudioDevice/]],
  ['config streaming contract', 'apps/host/src/config.ts', [/streaming:/, /ffmpegPath/, /audioDevice/]]
];
let passed = 0;
for (const [name, file, patterns] of checks) {
  const source = read(file);
  for (const pattern of patterns) if (!pattern.test(source)) throw new Error(`${name}: missing ${pattern}`);
  passed++;
  console.log(`PASS ${name}`);
}
console.log(`Part 4 static verification: ${passed}/${checks.length}`);
