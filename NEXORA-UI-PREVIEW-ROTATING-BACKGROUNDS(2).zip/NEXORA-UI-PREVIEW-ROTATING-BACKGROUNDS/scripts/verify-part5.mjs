import fs from 'node:fs'; import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..'); const must=['apps/host/src/networking/security.ts','apps/host/src/networking/pairing.ts','apps/host/src/networking/session-security.ts','apps/host/src/networking/ice.ts','apps/host/src/networking/signaling-client.ts','docs/PART5-NETWORKING-SECURITY-SPEC.md','docs/PART5-VERIFICATION.md'];
let n=0; for(const f of must){if(!fs.existsSync(path.join(root,f))) throw new Error('Missing '+f); n++;}
const proto=fs.readFileSync(path.join(root,'packages/shared/src/protocol.ts'),'utf8'); for(const bad of ["'input.event'","'stream.stats'"]){if(proto.includes(bad)) throw new Error('Signaling protocol still contains forbidden media/input type '+bad);} if(!proto.includes("'session.state'")) throw new Error('Missing session.state');
const sec=fs.readFileSync(path.join(root,'apps/host/src/networking/session-security.ts'),'utf8'); for(const x of ['lastInbound','verifySignature','sessionId','peerDeviceId']) if(!sec.includes(x)) throw new Error('Missing security invariant '+x); n+=4;
const pair=fs.readFileSync(path.join(root,'apps/host/src/networking/pairing.ts'),'utf8'); for(const x of ['single-use','maxAttempts','expiresAt']) if(!pair.includes(x)) throw new Error('Missing pairing invariant '+x); n+=3;
console.log(`Part 5 static verification: ${n}/${n} PASS`);
