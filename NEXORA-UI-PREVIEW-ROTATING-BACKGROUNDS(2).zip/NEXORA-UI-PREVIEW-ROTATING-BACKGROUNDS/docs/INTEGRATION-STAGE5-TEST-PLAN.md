# NEXORA Integration Stage 5 — Real-device validation plan

Stage 5 is the boundary between source-level integration and physical target testing. The Linux build environment can validate contracts and deterministic logic, but it cannot truthfully certify Windows capture, Windows hardware encoders, Android rendering, NAT traversal, or physical-device latency.

## Test matrix

1. Windows Host startup/shutdown and portable packaging.
2. Android install, landscape lock, immersive gameplay and screen-on behavior.
3. Pairing: temporary PIN, authorization, reconnect and revocation.
4. WebRTC: SDP, ICE, STUN direct path and TURN fallback.
5. Media: 720p/60 H.264 plus Opus audio; verify video and audio continue after transient network loss.
6. Input: touch controls over the WebRTC data channel, release-all on disconnect, keyboard/mouse/gamepad mapping.
7. Network profiles: same LAN, different LANs, mobile-data receiver, high latency, 1–5% packet loss.
8. Soak: minimum 30 minutes, target 2 hours; watch memory, CPU/GPU, encoder restarts and reconnects.
9. Update: stage, exit, external replacement, verification failure and rollback.

## Suggested acceptance targets

- UI remains responsive; no continuous render loop introduced by streaming.
- 720p/60 is sustainable on a representative Windows gaming PC when hardware encoding is available.
- Audio remains synchronized and does not require the signaling server.
- Input has no duplicate/replayed events after reconnect.
- A failed connection can be closed and retried without restarting NEXORA.
- A corrupt update package never replaces the active installation.

Record device model, Windows/Android version, encoder, network type, RTT, packet loss, FPS and observed failure for every run.
