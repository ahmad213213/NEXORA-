# Part 6 — Controller + Android Gameplay

Part 6 establishes the end-to-end input boundary without coupling Android UI to the Windows native implementation.

## Flow
Android touch overlay → sequenced InputEvent → Part 5 authenticated transport → Host InputManager → WindowsInputSink → native SendInput adapter.

## Guarantees
- monotonic input sequence numbers
- duplicate/replay rejection
- explicit key/button down/up
- release-all hook for disconnect/stop
- landscape-only gameplay shell
- immersive fullscreen
- touch overlay is real Android UI, not an image
- native Windows input remains isolated behind an adapter

## Deliberate boundary
WebRTC media rendering/transport is not duplicated in Part 6. Part 5 supplies the authenticated transport/session boundary; Part 7 will add editable control-layout persistence and live editing.
