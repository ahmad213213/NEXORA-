# NEXORA Part 4 — Streaming Engine

Part 4 adds the host-side media engine without coupling it to signaling or WebRTC.

## Pipeline

Windows desktop/audio capture → FFmpeg → H.264/Opus RTP on localhost → media sink contract → Part 5 networking/WebRTC.

The signaling server never receives media.

## Video

- 720p/60 is the default target.
- Desktop capture prefers `ddagrab` and automatically falls back to `gdigrab` when the installed FFmpeg build lacks the filter.
- H.264 hardware encoder probing order: NVENC → QSV → AMF → x264.
- If a selected hardware encoder fails during real capture, the engine falls back to x264 once.
- Baseline H.264, yuv420p, no B-frames, low-latency presets, one-second GOP.
- RTP packets use bounded UDP packet size (1200 bytes).

## Audio

- Optional DirectShow capture.
- Opus, 48 kHz, stereo, 96 kbps, 10 ms frames, low-delay application mode.
- Audio restart is bounded to two attempts; repeated failure disables audio without killing video.

## Lifecycle safety

- Start is single-flight.
- Every capture run owns a generation number.
- Delayed FFmpeg callbacks from an old run cannot modify a newer run.
- Stop is idempotent and closes child processes and localhost sockets.
- A stop during encoder probing cannot resurrect capture.
- Video failures are bounded; after repeated failure the capture engine stops cleanly.

## Quality / bitrate

Quality changes are normalized to safe bounds and restart only the video encoder. The adaptive bitrate controller is isolated from networking and uses bounded step changes plus cooldowns. Part 5 will feed real WebRTC statistics into it.

## Deliberate boundary

Part 4 does **not** implement signaling, ICE, TURN, WebRTC peer creation, controller input, or Android receiver behavior. Those belong to later parts. The media sink is the stable integration boundary.
