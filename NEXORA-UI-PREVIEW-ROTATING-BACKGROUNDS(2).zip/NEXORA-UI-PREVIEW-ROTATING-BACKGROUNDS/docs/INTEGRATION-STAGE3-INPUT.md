# NEXORA Integration Stage 3 — End-to-End Input

Stage 3 connects the existing Android touch/input pipeline to the Host input manager through an ordered WebRTC data channel.

## Flow

Android control → SequencedInputDispatcher → WebRTC data channel `nexora-input-v1` → Host InputDataChannelRouter → InputManager → WindowsInputSink.

The data channel carries only bounded JSON input frames. Existing sequence validation remains authoritative at the Host boundary.

## Safety

- Channel label is fixed and validated.
- Input frame size is capped at 8 KiB.
- Frame version/type are required.
- InputEvent validation is repeated on the Host.
- Host sequence/replay checks remain authoritative.
- Disconnect/stop detaches the channel and resets pressed inputs.

## Runtime limitation

This stage provides the real data-channel adapter and end-to-end code path, but actual Windows `SendInput` and Android/WebRTC network behavior require target-device runtime testing.
