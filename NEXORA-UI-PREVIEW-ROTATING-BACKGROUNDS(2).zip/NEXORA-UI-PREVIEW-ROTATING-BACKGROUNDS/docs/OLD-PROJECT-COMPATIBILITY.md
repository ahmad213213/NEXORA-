# Old NEXORA → Rebuild compatibility map

Part 2 keeps proven old-project UI lessons while using a fresh implementation.

| Old-project lesson | Part 2 treatment |
|---|---|
| Fixed sidebar / navigation geometry | Rebuilt with fixed responsive sidebar and bounded content region |
| Non-wrapping recent-game strip | Fixed/minimum card widths + horizontal scrolling |
| `contain` on expensive UI regions | Retained on sidebar, hero art, cards and panels |
| Excessive visual effects can hurt UI | No backdrop blur or CSS blur; restrained shadows/gradients |
| Responsive window behavior | Desktop, compact, and narrow breakpoints |
| Keyboard focus | Visible `:focus-visible` treatment |
| Game card selected state | Explicit selected class and deterministic click behavior |
| Local artwork fallback | Self-contained SVG placeholders; no network dependency |
| Secure Electron boundary | Part 1 preload/security remains unchanged in scope |
| Device identity contract | Part 1 shared contract remains untouched; identity implementation is later |
| FFmpeg runtime contract | Part 1 prerequisite contract remains untouched; capture is later |
| Strict session state machine | Part 1 protocol contract remains untouched; networking is later |
| Remote-access preference | Part 1 configuration contract remains untouched; networking is later |

Not copied from the old project: its monolithic UI HTML, old API routes, old application state, or old renderer implementation.

## Part 4 comparison

The old project was used as a reference for the proven capture/encoding behaviors: ddagrab→gdigrab fallback, hardware encoder probing, low-latency H.264 settings, optional DirectShow/Opus audio, bounded process recovery, generation-scoped streaming cleanup, and adaptive bitrate cooldowns. The rebuild reimplements these as isolated modules with a MediaSink boundary and no dependency on the old signaling/session code.
