# NEXORA Integration Stage 1 — Session/Media/Input Boundary

This stage connects the already-built Part 4 capture engine, Part 5 session/security layer and Part 6 input layer through an explicit host-side session orchestrator.

## Boundary

Windows capture/audio → `CaptureEngine` → `SessionOrchestrator` → `PeerMediaTransport` → future WebRTC adapter → Android receiver.

Android input → future receiver transport → `SessionOrchestrator` → `InputManager` → Windows input adapter.

## Safety rules

- Session IDs are validated before activation.
- A new session increments a generation and invalidates callbacks from the old session.
- Media packets are forwarded only while the exact session is active.
- Stopping a session closes media transport and releases input state.
- Input sequence replay protection remains in the existing `InputManager`.
- WebRTC is intentionally kept behind `PeerMediaTransport`; this stage does not pretend that a fake transport is real WebRTC.

## Real-device work still required

A platform WebRTC adapter must implement `PeerMediaTransport` using a real `RTCPeerConnection`, RTP ingestion, ICE/DTLS/SRTP and receiver decoding. The Android app must provide the matching transport and actual video/audio renderers. Windows `SendInput` also requires its native implementation.
