# Part 5 — Networking + Security

## Boundary

Signaling is control-plane only:

- pairing and authorization
- device authentication
- session creation/state
- SDP offer/answer
- ICE candidates

Video, audio and controller/input traffic never travel through the signaling service.

## Identity

The host owns a persistent Ed25519 identity. The device ID is derived from the public key. Existing malformed or mismatched identities are rejected rather than silently regenerated.

## Pairing

PINs are six digits, temporary, single-use, and rate-limited. The PIN is only a pairing capability; it is not a long-term encryption key. Approved receiver public keys are persisted locally and can be revoked.

## Session security

Every session message is bound to:

- protocol/version
- message type
- sender and intended peer
- session ID
- monotonic sequence
- timestamp
- complete payload

The receiving peer verifies the Ed25519 signature and rejects replayed, stale, misaddressed or cross-session messages.

## NAT traversal

ICE configuration accepts bounded STUN/TURN entries. Relay-only policy is supported for networks where direct peer-to-peer connectivity fails. WebRTC transport itself remains a later integration boundary; this part does not move media into signaling.

## Reconnect

The signaling client uses bounded exponential reconnect (1s → 30s). Session authorization remains local and survives signaling reconnects.
