# Phase 0 checks — current preview package

- Root archive structure is preserved.
- `PREVIEW.bat` resolves to the approved prototype HTML rather than `apps/host/src/ui/index.html`.
- The prototype currently renders empty states for Dashboard, Library, and Console Mode (no sample games).
- Four local background JPGs are available at 1920×1080.
- Wallpaper rotation is tested by `design-reference/current-frosted-glass-ui-prototype/tests/empty-library-preview.test.cjs`.
- The archive includes only one batch file: `PREVIEW.bat`.

These checks cover the source package and prototype behavior; they do not verify a native Electron app or Windows installer.
