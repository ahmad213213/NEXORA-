# NEXORA Integration Stage 4 — Full Connection Flow

The connection flow now coordinates PIN-authorized peers, signed signaling, SDP/ICE, WebRTC, streaming, and teardown without moving media through the signaling server.

## Flow
1. Device pairing/authorization occurs through the existing Part 5 security layer.
2. Host creates a signed session-open message.
3. Host creates a WebRTC offer.
4. SDP and ICE travel through signaling only.
5. Once the peer is negotiated, `SessionOrchestrator` owns capture/media lifecycle.
6. Video/audio remain WebRTC media; controller input remains the WebRTC data channel.
7. Session generation prevents stale callbacks from a previous connection affecting a new connection.
8. Closing the session tears down WebRTC, media capture, signaling session state, and input state.

## Runtime boundary
The source now has a complete orchestration boundary, but real Windows↔Android NAT traversal, TURN, capture, and device runtime testing still require target hardware/network infrastructure.
