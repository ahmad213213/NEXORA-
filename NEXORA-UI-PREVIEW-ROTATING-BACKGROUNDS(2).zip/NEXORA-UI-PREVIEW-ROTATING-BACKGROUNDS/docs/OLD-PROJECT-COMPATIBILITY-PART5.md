# Old NEXORA comparison — Part 5

The old project was used as a behavioral reference, not copied wholesale.

Carried forward because it was proven useful:

- Ed25519 device identity with public-key-derived device IDs.
- Refusal to silently replace a corrupted/mismatched identity.
- Six-digit temporary PIN pairing with bounded TTL and rate limiting.
- Persisted paired-device authorization and explicit revocation.
- Signed session operations bound to sender, peer and session.
- Replay protection and bounded session operation history.
- Signaling-only control plane; video/audio/input remain outside signaling.
- Bounded reconnect behavior.
- STUN/TURN configuration as a WebRTC boundary rather than embedding media transport into signaling.

Improved in the rebuild:

- Protocol message names are explicit and no longer include `input.event` or `stream.stats` in the signaling contract.
- Signature bytes include the complete payload, not only selected signaling fields.
- SessionSecurity enforces timestamp freshness in addition to monotonic sequence checks.
- Pairing persistence is isolated from transport and can be tested independently.
- SignalingCore is transport-neutral, making a future hosted WebSocket service replaceable without moving security rules into the UI or media engine.
- The client does not invent a local PIN for a remote signaling service; the server remains authoritative for the displayed pairing code.
