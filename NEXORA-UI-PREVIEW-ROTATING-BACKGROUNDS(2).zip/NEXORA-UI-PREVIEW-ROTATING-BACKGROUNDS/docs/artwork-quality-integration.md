# Artwork quality integration

Newly fetched game covers and screenshots are passed through an optional local Real-ESRGAN upscaling stage before being cached. The first attempt retrieves the upstream Windows command-line engine into the application's user-data directory. No image is sent to a cloud image service. If download, GPU/driver, format, timeout, or output-size checks fail, the original asset is retained and the add-game flow continues. Existing artwork presentation uses cover-fit sizing, so artwork fills its UI frame without being stretched.

This is an internal implementation note; it adds no visible settings or labels to the application.
