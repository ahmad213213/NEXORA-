# Phase 0 status — source foundation and UI preview

Phase 0 preserves the Electron source and the built frosted-glass UI prototype in one source package, with reference assets and checks. The root `PREVIEW.bat` opens the prototype at `design-reference/current-frosted-glass-ui-prototype/index.html` so the intended UI is tested, not the legacy renderer.

The current UI preview is intentionally empty of games and rotates the default background on each opening: Space Horizon, Nebula, Forest Vista, Earth Orbit.

The original Electron renderer remains at `apps/host/src/ui/`. Phase 0 does not claim the prototype has been merged into it. Only `PREVIEW.bat` is included as a batch file; build/install scripts belong to later work.
