# NEXORA Final Release Hardening

This stage is the final source-level release gate after Integration Stage 5.

## Gates
- All Parts 1–8 verification scripts must pass.
- Integration Stages 1–5 verification must pass.
- No private signing key is shipped in source or release archives.
- Production update signing keys remain outside the repository.
- Windows release must be built on Windows.
- Android release must be built and installed on a real Android device.
- End-to-end WebRTC, capture, audio and input must be physically tested before claiming a production release.
- Failed update must preserve the previous installation.

## Device acceptance
1. Pair with a temporary PIN.
2. Establish signaling session.
3. Complete SDP/ICE negotiation.
4. Receive 720p/60 video.
5. Receive audio.
6. Send touch/controller input.
7. Disconnect/reconnect.
8. Test a non-host network and TURN fallback.
9. Run a long-session soak test.
10. Test update, failure and rollback.

## Release status
Source-level hardening: ready.
Physical Windows/Android acceptance: pending real devices.
Production signing: pending operator-controlled signing key.
