# Integration Stage 5 verification

## Source-level checks
- Health classifier normalizes invalid telemetry.
- Health classification is deterministic and bounded.
- Stage 1–4 integration modules remain present.
- WebRTC, input, streaming, Android and updater boundaries remain intact.

## Runtime checks possible in this environment
- TypeScript compilation of the host integration modules.
- Node unit tests for the health classifier.
- Static integration verification.

## Target-machine checks intentionally not claimed
- Windows desktop capture.
- NVENC/QSV/AMF hardware encoding.
- Actual Windows SendInput injection.
- Physical Android WebRTC rendering/audio.
- Internet NAT traversal and TURN reachability.
- End-to-end latency on a real network.
- Long-duration thermal/memory behavior.

These require Windows and an Android device and must be executed before a production release is declared.
