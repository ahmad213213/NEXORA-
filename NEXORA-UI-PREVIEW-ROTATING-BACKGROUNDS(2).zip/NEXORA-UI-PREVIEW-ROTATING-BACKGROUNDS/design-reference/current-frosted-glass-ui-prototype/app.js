(() => {
  "use strict";
  const app = document.getElementById("app");
  const desktop = document.getElementById("desktop-ui");
  const consoleUI = document.getElementById("console-ui");
  const toConsole = document.getElementById("to-console");
  const toDesktop = document.getElementById("console-return");
  const overlay = document.getElementById("console-overlay");
  const overlayTitle = document.getElementById("console-panel-title");
  const overlayContent = document.getElementById("console-panel-content");
  const crumb = document.getElementById("crumb-current");
  const toast = document.getElementById("preview-toast");
  const pageNames = {
    dashboard: "Home", library: "Library", remoteplay: "Remote Play", performance: "Performance",
    streaming: "Streaming", networking: "Networking", controls: "Controls",
    patcher: "AI Patcher", settings: "Settings"
  };
  const ACCENTS = {
    cyan:   { name: "Aurora cyan",  stops: ["#ed40eb", "#8b69ff", "#3aabff", "#27f4ff"], a: "#4ac8ff", a2: "#8b69ff", a3: "#27f4ff", glow: "rgba(74,200,255,.38)" },
    blue:   { name: "Electric blue", stops: ["#5b8cff", "#3a6bff", "#2d9bff", "#5ee7ff"], a: "#4b9dff", a2: "#547bff", a3: "#5ee7ff", glow: "rgba(75,157,255,.38)" },
    violet: { name: "Nebula violet", stops: ["#c84bff", "#9b5cff", "#6b7bff", "#4ad4ff"], a: "#ab8bff", a2: "#9b5cff", a3: "#c84bff", glow: "rgba(171,139,255,.4)" },
    amber:  { name: "Solar amber",  stops: ["#ff8a3d", "#ffb347", "#ffd06b", "#ffe9a0"], a: "#ffc067", a2: "#ff8a3d", a3: "#ffd06b", glow: "rgba(255,192,103,.4)" },
    emerald:{ name: "Jade emerald", stops: ["#2ee6a6", "#1ec8b0", "#3ab8ff", "#7ef0d0"], a: "#2ee6a6", a2: "#1ec8b0", a3: "#3ab8ff", glow: "rgba(46,230,166,.38)" },
    rose:   { name: "Rose neon",    stops: ["#ff4d8d", "#ff6bb5", "#c77dff", "#ff9ec8"], a: "#ff4d8d", a2: "#ff6bb5", a3: "#c77dff", glow: "rgba(255,77,141,.4)" }
  };

  const settingsSections = window.NEXORASettingsStore.schema;
  const qualityChoices = ["720p · 30 fps", "720p · 60 fps", "1080p · 60 fps", "1440p · 60 fps", "2160p · 60 fps"];
  let toastTimer = null;
  let switchTimer = null;
  let selectedQuality = 2;
  let selectedGame = null;
  let activeSettings = "Appearance";
  let activeDesktopSettings = "Appearance";


  function showToast(message = "UI preview only — feature not connected") {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
  }

  function showPage(page) {
    if (!pageNames[page]) return;
    document.querySelectorAll(".nav-item[data-page]").forEach(button => {
      const active = button.dataset.page === page;
      button.classList.toggle("active", active);
      if (active) button.setAttribute("aria-current", "page");
      else button.removeAttribute("aria-current");
    });
    document.querySelectorAll(".page-view[data-view]").forEach(view => {
      view.classList.toggle("active", view.dataset.view === page);
    });
    crumb.textContent = pageNames[page];
    document.getElementById("desktop-content").scrollTop = 0;
  }

  function enterConsole() {
    clearTimeout(switchTimer);
    closeConsolePanel();
    desktop.style.display = "flex";
    desktop.classList.remove("mode-return");
    desktop.classList.add("mode-leave");
    consoleUI.classList.remove("mode-exit");
    consoleUI.classList.add("active");
    consoleUI.setAttribute("aria-hidden", "false");
    app.classList.remove("desktop-mode");
    app.classList.add("console-mode");
    toConsole?.setAttribute("aria-pressed", "true");
    toast.classList.remove("show");
    switchTimer = setTimeout(() => {
      desktop.style.display = "none";
      desktop.classList.remove("mode-leave");
    }, 440);
  }

  function enterDesktop() {
    clearTimeout(switchTimer);
    closeConsolePanel();
    consoleUI.classList.remove("mode-exit");
    consoleUI.classList.remove("active");
    consoleUI.setAttribute("aria-hidden", "true");
    desktop.style.display = "flex";
    desktop.classList.remove("mode-leave");
    desktop.classList.add("mode-return");
    app.classList.remove("console-mode");
    app.classList.add("desktop-mode");
    toConsole?.setAttribute("aria-pressed", "false");
    toast.classList.remove("show");
    switchTimer = setTimeout(() => desktop.classList.remove("mode-return"), 500);
  }

  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
  }

  function accentSwatchHTML(prefix = "desktop") {
    const current = window.NEXORASettingsStore.get("accent") || "cyan";
    return `<div class="accent-choices" role="group" aria-label="Accent color">${["cyan","blue","violet","amber","emerald","rose"].map(key =>
      `<button type="button" class="accent-${key}${key === current ? " selected-accent" : ""}" data-setting-accent="${key}" aria-label="${ACCENTS[key].name}" aria-pressed="${key === current}" title="${ACCENTS[key].name}"><span class="sr-only">${ACCENTS[key].name}</span></button>`
    ).join("")}</div>`;
  }

  function settingControlMarkup(field, prefix) {
    const store = window.NEXORASettingsStore;
    const value = store.get(field.key);
    const key = escapeHTML(field.key);
    const label = escapeHTML(field.label);
    const id = `setting-${prefix}-${key.replace(/[^a-z0-9_-]/gi, "-")}`;
    if (field.type === "accent") return accentSwatchHTML(prefix);
    if (field.type === "toggle") {
      const enabled = value === true;
      return `<button type="button" class="mock-toggle setting-toggle${prefix === "console" ? " console-setting-toggle" : ""}${enabled ? " enabled" : ""}" data-setting-key="${key}" role="switch" aria-checked="${enabled}" aria-label="${label}" title="${label}"></button>`;
    }
    if (field.type === "select") {
      const choices = field.options.map(option => `<option value="${escapeHTML(option.value)}"${String(option.value) === String(value) ? " selected" : ""}>${escapeHTML(option.label)}</option>`).join("");
      return `<select id="${id}" class="setting-select${prefix === "console" ? " console-setting-select" : ""}" data-setting-key="${key}" aria-label="${label}">${choices}</select>`;
    }
    if (field.type === "text") {
      return `<input id="${id}" class="setting-input" type="text" maxlength="${field.maxLength || 40}" data-setting-key="${key}" value="${escapeHTML(value)}" aria-label="${label}" autocomplete="off" spellcheck="false">`;
    }
    if (field.type === "range") {
      return `<div class="setting-range"><input id="${id}" type="range" min="${field.min}" max="${field.max}" step="${field.step}" value="${Number(value)}" data-setting-key="${key}" aria-label="${label}"><output for="${id}" data-range-output="${key}">${Number(value)} ${escapeHTML(field.unit || "")}</output></div>`;
    }
    if (field.type === "action") {
      return `<button type="button" class="setting-action-button" data-setting-action="${escapeHTML(field.action)}">${escapeHTML(field.actionLabel || "Open")}</button>`;
    }
    if (field.type === "info") {
      return `<span class="setting-value-badge">${escapeHTML(field.value || "Not available")}</span>`;
    }
    return "";
  }

  function rowMarkup(field, prefix = "console") {
    const key = escapeHTML(field.key || "info");
    const label = escapeHTML(field.label);
    const description = escapeHTML(field.description || "");
    const control = settingControlMarkup(field, prefix);
    const typeClass = field.type ? ` setting-type-${field.type}` : "";
    const nativeNote = field.native ? `<small class="setting-integration-note">Windows integration pending</small>` : "";
    return `<div class="console-setting-row setting-line settings-field${typeClass}" data-setting-row="${key}"><span class="setting-copy"><b>${label}</b><small>${description}</small>${nativeNote}</span><span class="setting-control">${control}</span></div>`;
  }

  function settingsToolsMarkup(prefix) {
    return `<div class="settings-tools" role="group" aria-label="Settings file and reset actions"><div class="settings-save-status" data-settings-status><span class="status-dot"></span><span>${escapeHTML(window.NEXORASettingsStore.statusLabel())}</span></div><div class="settings-tool-actions"><button type="button" data-setting-action="export">Export JSON</button><button type="button" data-setting-action="import">Import JSON</button><button type="button" class="settings-reset-action" data-setting-action="reset">Reset defaults</button></div><input class="settings-import-file" type="file" accept="application/json,.json" aria-label="Import NEXORA settings file" hidden></div>`;
  }

  function settingsRuntimeNote() {
    return `<p class="settings-runtime-note">Preferences autosave as you change them. Theme, accent, reduced motion and startup mode apply in this UI. Windows tray/startup, networking, updater and live-stream options are saved for their native services to consume when those systems are connected.</p>`;
  }

  function renderSettingsSection(section) {
    activeSettings = settingsSections[section] ? section : "Appearance";
    const data = settingsSections[activeSettings];
    overlayTitle.textContent = "Settings";
    const rows = data.rows.map(field => rowMarkup(field, "console")).join("");
    const statusCard = activeSettings === "Appearance" ? `<article class="settings-info-card"><div><span class="eyebrow-small">SETTINGS ENGINE</span><h4>Preferences are saved automatically</h4><p>Changes persist on this device and are shared by Desktop and Console Mode. Native Windows and streaming actions remain separate integrations.</p></div><div class="settings-info-meta"><span>STORAGE</span><b data-settings-storage>${escapeHTML(window.NEXORASettingsStore.statusLabel())}</b><span>CONFIG VERSION</span><b>1 · Migratable</b></div></article>` : "";
    overlayContent.innerHTML = `<div class="console-settings-layout"><nav class="console-settings-nav" aria-label="Console settings">${Object.keys(settingsSections).map(name => `<button type="button" data-settings-tab="${escapeHTML(name)}" class="${name === activeSettings ? "active" : ""}" aria-current="${name === activeSettings ? "page" : "false"}"><svg aria-hidden="true"><use href="#${name === "Network" ? "i-network" : name === "Streaming" ? "i-stream" : name === "Updates" ? "i-download" : name === "Privacy & security" ? "i-shield" : name === "General" ? "i-sliders" : "i-monitor"}"/></svg>${escapeHTML(name)}</button>`).join("")}</nav><div class="console-settings-content"><span class="eyebrow-small">${escapeHTML(data.kicker)}</span><h3>${escapeHTML(data.title)}</h3><p>${escapeHTML(data.desc)}</p><div class="settings-fields">${rows}</div>${settingsRuntimeNote()}${settingsToolsMarkup("console")}${statusCard}</div></div>`;
  }

  function renderDesktopSettings(section) {
    activeDesktopSettings = settingsSections[section] ? section : "Appearance";
    const data = settingsSections[activeDesktopSettings];
    document.querySelectorAll(".settings-nav button").forEach(button => {
      button.classList.toggle("active", button.dataset.desktopSetting === activeDesktopSettings);
      if (button.dataset.desktopSetting === activeDesktopSettings) button.setAttribute("aria-current", "page");
      else button.removeAttribute("aria-current");
    });
    const target = document.querySelector(".settings-content");
    if (!target) return;
    const rows = data.rows.map(field => rowMarkup(field, "desktop")).join("");
    const statusCard = activeDesktopSettings === "Appearance" ? `<article class="panel glass setting-card settings-info-card"><div class="settings-info-main"><div class="panel-head"><div><span class="eyebrow-small">SETTINGS ENGINE</span><h3>Preferences & storage</h3></div><span class="tiny-tag">AUTOSAVE</span></div><p>Settings are validated, versioned, and saved as you change them. Import/export makes your profile portable. Desktop-specific actions will activate when the native Windows services are wired in.</p><div class="connection-stats settings-system-stats"><div><span>APP PACKAGE</span><b>1.3.0 · UI prototype</b></div><div><span>STORAGE</span><b data-settings-storage>${escapeHTML(window.NEXORASettingsStore.statusLabel())}</b></div><div><span>NATIVE SERVICES</span><b>Integration pending</b></div></div></div></article>` : "";
    target.innerHTML = `<article class="panel glass setting-card"><div class="panel-head"><div><span class="eyebrow-small">${escapeHTML(data.kicker)}</span><h3>${escapeHTML(data.title)}</h3></div><span class="tiny-tag">${activeDesktopSettings === "Appearance" ? "PREFERENCES" : "AUTOSAVE"}</span></div><div class="settings-fields">${rows}</div>${settingsRuntimeNote()}</article>${statusCard}${settingsToolsMarkup("desktop")}`;
    refreshSettingsStatus();
  }

  function refreshSettingsStatus() {
    const store = window.NEXORASettingsStore;
    document.querySelectorAll("[data-settings-status]").forEach(node => {
      const span = node.querySelector("span:last-child");
      if (span) span.textContent = store.statusLabel();
      node.classList.toggle("storage-warning", store.backend === "memory");
      node.title = store.lastError || "NEXORA preferences save automatically.";
    });
    document.querySelectorAll("[data-settings-storage]").forEach(node => node.textContent = store.statusLabel());
  }

  function updateProfileName() {
    const name = window.NEXORASettingsStore.get("profileName") || "NEXORA User";
    const topName = document.querySelector(".top-user b");
    const avatar = document.querySelector(".top-avatar");
    if (topName) topName.textContent = name;
    if (avatar) avatar.textContent = (Array.from(name.trim())[0] || "N").toLocaleUpperCase();
  }

  function qualityIndexFromSettings() {
    const resolution = window.NEXORASettingsStore.get("resolution");
    const frameRate = window.NEXORASettingsStore.get("frameRate");
    const label = `${resolution} · ${frameRate} fps`;
    const exact = qualityChoices.indexOf(label);
    if (exact >= 0) return exact;
    const fallback = qualityChoices.findIndex(item => item.startsWith(`${resolution} ·`));
    return fallback >= 0 ? fallback : 2;
  }

  function updateQualityLabel() {
    selectedQuality = qualityIndexFromSettings();
    const label = document.getElementById("console-quality-label");
    if (label) label.textContent = qualityChoices[selectedQuality];
    document.querySelectorAll(".quality-option").forEach(option => {
      const title = option.querySelector("b")?.textContent.trim() || "";
      const resolution = title === "4K" ? "2160p" : title;
      const frameText = option.querySelector("small")?.textContent || "";
      const matchesFps = frameText.includes("30–60") ? window.NEXORASettingsStore.get("frameRate") === "60" : frameText.includes(`${window.NEXORASettingsStore.get("frameRate")} frames/sec`);
      option.classList.toggle("selected", resolution === window.NEXORASettingsStore.get("resolution") && matchesFps);
    });
  }

  function applyTheme(theme) {
    document.documentElement.dataset.theme = ["midnight", "obsidian", "earth"].includes(theme) ? theme : "midnight";
  }

  function applyReducedMotion(enabled) {
    document.documentElement.classList.toggle("reduced-motion", enabled === true);
  }

  function applyStoredSettings() {
    const store = window.NEXORASettingsStore;
    applyTheme(store.get("theme"));
    applyAccent(store.get("accent"), false);
    applyReducedMotion(store.get("reducedMotion"));
    updateProfileName();
    updateQualityLabel();
    refreshSettingsStatus();
  }

  async function commitSetting(key, value, options = {}) {
    const store = window.NEXORASettingsStore;
    const result = await store.set(key, value);
    applyStoredSettings();
    if (key === "profileName") {
      document.querySelectorAll('[data-setting-key="profileName"]').forEach(input => {
        if (document.activeElement !== input) input.value = store.get("profileName");
      });
    }
    if (options.render) {
      renderDesktopSettings(activeDesktopSettings);
      if (overlay && !overlay.hasAttribute("hidden")) renderSettingsSection(activeSettings);
    }
    if (options.silent) return result;
    if (!result.ok && result.backup) {
      showToast("App storage unavailable — a browser backup was saved");
    } else if (!result.ok || store.backend === "memory") {
      showToast("Storage unavailable — changes apply for this session only");
    } else if (key === "desktopModeOnStartup") {
      showToast(`Startup mode saved: ${store.get(key) ? "Desktop" : "Console"}`);
    } else if (key === "startWithWindows" || key === "minimizeToTray") {
      showToast("Preference saved; Windows shell integration is not connected yet");
    } else if (["connectionMode", "relayFallback", "pairingCodeLifetime", "resolution", "frameRate", "bitrateMbps", "encoder", "audioCapture", "adaptiveQuality", "requireDeviceApproval", "encryptSessions", "diagnosticLogging", "shareCrashReports", "updateChannel", "automaticUpdateChecks"].includes(key)) {
      showToast("Preference saved locally; its native service is not connected in this package");
    } else {
      showToast("Preference saved on this device");
    }
    return result;
  }

  function downloadSettings() {
    const payload = window.NEXORASettingsStore.exportPayload();
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `nexora-settings-${new Date().toISOString().slice(0, 10)}.json`;
    anchor.style.display = "none";
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    showToast("Settings exported as a JSON backup");
  }

  async function handleSettingsImport(input) {
    const file = input.files && input.files[0];
    if (!file) return;
    try {
      if (file.size > 1024 * 1024) throw new Error("Settings file must be smaller than 1 MB.");
      const payload = JSON.parse(await file.text());
      if (!payload || payload.app !== "NEXORA" || payload.schemaVersion !== 1 || !payload.settings || typeof payload.settings !== "object" || Array.isArray(payload.settings)) {
        throw new Error("This is not a supported NEXORA settings backup.");
      }
      if (!confirm("Import these NEXORA settings? Your current preferences will be replaced.")) return;
      const result = await window.NEXORASettingsStore.replace(payload.settings);
      if (!result.ok && !result.backup && window.NEXORASettingsStore.backend === "memory") throw new Error("Settings were loaded for this session but could not be saved.");
      applyStoredSettings();
      renderDesktopSettings(activeDesktopSettings);
      if (overlay && !overlay.hasAttribute("hidden")) renderSettingsSection(activeSettings);
      showToast(!result.ok && result.backup ? "Imported; browser backup saved because app storage failed" : "Settings imported and validated");
    } catch (error) {
      showToast(error && error.message ? error.message : "Could not import the settings file");
    } finally {
      input.value = "";
    }
  }

  async function handleSettingsAction(button) {
    const action = button.dataset.settingAction;
    if (action === "export") {
      downloadSettings();
    } else if (action === "import") {
      const input = button.closest(".settings-tools")?.querySelector(".settings-import-file");
      input?.click();
    } else if (action === "reset") {
      if (!confirm("Reset every NEXORA preference to its default? This cannot be undone unless you exported a backup.")) return;
      const result = await window.NEXORASettingsStore.reset();
      applyStoredSettings();
      renderDesktopSettings(activeDesktopSettings);
      if (overlay && !overlay.hasAttribute("hidden")) renderSettingsSection(activeSettings);
      showToast(result.ok ? "All settings reset to defaults" : result.backup ? "Defaults saved to browser backup; app storage unavailable" : "Defaults restored for this session; storage is unavailable");
    } else if (action === "check-updates") {
      showToast("Updater is not connected in this UI package; no network request was made");
    }
  }

  function openConsolePanel(kind) {
    if (!overlay) return;
    overlay.removeAttribute("hidden");
    overlay.setAttribute("aria-hidden", "false");
    requestAnimationFrame(() => overlay.classList.add("open"));
    if (kind === "settings") {
      renderSettingsSection(activeSettings);
      return;
    }
    if (kind === "updates") {
      overlayTitle.textContent = "Updates";
      overlayContent.innerHTML = `<div class="console-update-card"><span class="update-symbol"><svg><use href="#i-download"/></svg></span><div class="console-update-copy"><b>NEXORA is up to date</b><small>Prototype build 1.3.0 · update checks are not connected.</small></div><button class="console-action-button primary" type="button" data-demo-action="update">Check again</button></div><p class="preview-note">No update manifest is contacted and no files are downloaded or changed.</p>`;
      return;
    }
    if (kind === "quality") {
      overlayTitle.textContent = "Stream quality";
      overlayContent.innerHTML = `<div class="console-settings-content"><h3>Choose a picture profile</h3><p>Pick a quality preset for the visual preview. This does not change a real encoder.</p><div class="console-quality-options">${qualityChoices.map((label,index) => `<button type="button" class="${index === selectedQuality ? "active" : ""}" data-quality-choice="${index}"><b>${label.split(" · ")[0]}</b><small>${label.split(" · ")[1]} · preview</small></button>`).join("")}</div><p class="preview-note">Your choice is saved as the default stream profile. A live encoder is not connected in this package.</p></div>`;
      return;
    }
    if (kind === "stream") {
      overlayTitle.textContent = "Remote play";
      overlayContent.innerHTML = `<div class="console-stream-card"><div class="console-stream-head"><i class="status-dot"></i><div><b>Host ready · no active stream</b><p>Connect a receiver to start a session. This preview cannot pair or stream.</p></div></div><div class="console-stream-details"><div><small>HOST COMPUTER</small><b>ORION-DESKTOP</b></div><div><small>RECEIVER</small><b>Not connected</b></div><div><small>PAIRING PIN</small><b>482 731 · sample</b></div></div><button class="console-action-button primary" type="button" data-demo-action="pair">Pair a receiver</button><p class="preview-note">Pairing and session transport are intentionally not wired in this UI-only build.</p></div>`;
      return;
    }
    if (kind === "details") {
      if (!selectedGame) {
        overlayTitle.textContent = "Game details";
        overlayContent.innerHTML = `<div class="console-empty-panel"><h3>No game selected</h3><p>This preview intentionally starts with an empty library. Game selection will be added in a later phase.</p></div>`;
        return;
      }
      overlayTitle.textContent = "Game details";
      const selected = document.querySelector(".console-cover.is-selected");
      const className = selected ? [...selected.classList].find(name => name.startsWith("cover-")) : "cover-god";
      overlayContent.innerHTML = `<div class="console-game-detail"><div class="console-detail-art ${className || "cover-god"}"></div><div class="console-detail-text"><span class="eyebrow-small">SELECTED FROM YOUR LIBRARY</span><h3>${selectedGame}</h3><p>Explore game details, platform information, and play history. This record is sample content for the interface preview.</p><div class="console-detail-tags"><span>Windows PC</span><span>Verified sample</span><span>Ready to play</span></div><button class="console-action-button primary" type="button" data-demo-action="launch">Play ${selectedGame}</button><p class="preview-note">Game launching is not connected in this UI-only build.</p></div></div>`;
      return;
    }
    renderSettingsSection("Appearance");
  }

  function closeConsolePanel() {
    if (!overlay) return;
    overlay.classList.remove("open");
    overlay.setAttribute("aria-hidden", "true");
    overlay.setAttribute("hidden", "");
  }

  function selectConsoleGame(button) {
    selectedGame = button.dataset.game || "Selected game";
    document.querySelectorAll(".console-cover").forEach(card => {
      const selected = card === button;
      card.classList.toggle("is-selected", selected);
      card.setAttribute("aria-pressed", String(selected));
    });
    const normalized = selectedGame.toUpperCase();
    const words = normalized.split(" ");
    const title = document.getElementById("console-game-title");
    if (title) {
      title.replaceChildren(document.createTextNode(words.slice(0, -1).join(" ") + " "));
      const last = document.createElement("span");
      last.textContent = words.at(-1) || "";
      title.append(last);
    }
    showToast(`${selectedGame} selected`);
  }

  function updateQuality(step) {
    selectedQuality = (selectedQuality + step + qualityChoices.length) % qualityChoices.length;
    const [resolution, fps] = qualityChoices[selectedQuality].split(" · ");
    const frameRate = String(parseInt(fps, 10) || 60);
    Promise.all([commitSetting("resolution", resolution, { silent: true }), commitSetting("frameRate", frameRate, { silent: true })]).then(() => {
      const label = document.getElementById("console-quality-label");
      if (label) label.textContent = qualityChoices[selectedQuality];
      showToast(`Default quality saved: ${qualityChoices[selectedQuality]}`);
    });
  }

  toConsole?.addEventListener("click", enterConsole);
  toDesktop?.addEventListener("click", enterDesktop);
  document.addEventListener("click", event => {
    const emptyAddAction = event.target.closest("[data-preview-empty-add]");
    if (emptyAddAction) {
      showToast("Game adding will be built in a later phase. This preview starts empty.");
      return;
    }
    const pageButton = event.target.closest(".nav-item[data-page], [data-goto], .settings-shortcuts [data-page]");
    if (pageButton) {
      showPage(pageButton.dataset.page || pageButton.dataset.goto);
      if (pageButton.classList.contains("sidebar-anywhere")) showToast("Your games are ready to browse");
      return;
    }
    const pageAction = event.target.closest("[data-page]");
    if (pageAction && pageNames[pageAction.dataset.page]) {
      showPage(pageAction.dataset.page);
      return;
    }
    const consoleAction = event.target.closest("[data-console-panel]");
    if (consoleAction) {
      openConsolePanel(consoleAction.dataset.consolePanel);
      return;
    }
    const qualityStep = event.target.closest("[data-quality-step]");
    if (qualityStep) {
      updateQuality(Number(qualityStep.dataset.qualityStep));
      return;
    }
    const cover = event.target.closest(".console-cover[data-game]");
    if (cover) {
      selectConsoleGame(cover);
      return;
    }
    const closeButton = event.target.closest("[data-console-close]");
    if (closeButton) {
      closeConsolePanel();
      return;
    }
    const settingsAction = event.target.closest("[data-setting-action]");
    if (settingsAction) {
      handleSettingsAction(settingsAction);
      return;
    }
    const settingSwitch = event.target.closest('button[data-setting-key][role="switch"]');
    if (settingSwitch) {
      const key = settingSwitch.dataset.settingKey;
      const enabled = settingSwitch.getAttribute("aria-checked") !== "true";
      settingSwitch.classList.toggle("enabled", enabled);
      settingSwitch.setAttribute("aria-checked", String(enabled));
      document.querySelectorAll(`[data-setting-key="${key}"][role="switch"]`).forEach(peer => {
        peer.classList.toggle("enabled", enabled);
        peer.setAttribute("aria-checked", String(enabled));
      });
      commitSetting(key, enabled);
      return;
    }
    const settingAccent = event.target.closest("[data-setting-accent]");
    if (settingAccent) {
      commitSetting("accent", settingAccent.dataset.settingAccent);
      return;
    }
    const settingsTab = event.target.closest("[data-settings-tab]");
    if (settingsTab) {
      renderSettingsSection(settingsTab.dataset.settingsTab);
      return;
    }
    const qualityChoice = event.target.closest("[data-quality-choice]");
    if (qualityChoice) {
      selectedQuality = Number(qualityChoice.dataset.qualityChoice);
      document.querySelectorAll("[data-quality-choice]").forEach(button => button.classList.toggle("active", button === qualityChoice));
      const [resolution, fps] = qualityChoices[selectedQuality].split(" · ");
      const frameRate = String(parseInt(fps, 10) || 60);
      Promise.all([commitSetting("resolution", resolution, { silent: true }), commitSetting("frameRate", frameRate, { silent: true })]).then(() => {
        const label = document.getElementById("console-quality-label");
        if (label) label.textContent = qualityChoices[selectedQuality];
        showToast(`Default quality saved: ${qualityChoices[selectedQuality]}`);
      });
      return;
    }
    const desktopSetting = event.target.closest("[data-desktop-setting]");
    if (desktopSetting) {
      renderDesktopSettings(desktopSetting.dataset.desktopSetting);
      return;
    }
    const demoAction = event.target.closest("[data-demo-action]");
    if (demoAction) {
      const messages = {update:"No update service is connected in this preview.",pair:"Pairing is not connected in this preview.",launch:"Game launch is not connected in this preview."};
      showToast(messages[demoAction.dataset.demoAction] || "Preview only");
      return;
    }
    const collapse = event.target.closest(".collapse-quick");
    if (collapse) {
      const quickCard = collapse.closest(".quick-card");
      const actions = quickCard?.querySelectorAll(".quick-action");
      const collapsed = quickCard?.classList.toggle("is-collapsed");
      actions?.forEach(action => action.hidden = Boolean(collapsed));
      collapse.textContent = collapsed ? "⌄" : "⌃";
      return;
    }
    const consolePlay = event.target.closest(".console-play");
    if (consolePlay) {
      showToast(selectedGame ? `${selectedGame} · game launch is not connected` : "No game has been added yet.");
      return;
    }
    const consoleView = event.target.closest(".console-view");
    if (consoleView) {
      openConsolePanel("details");
      return;
    }
    const qualityOption = event.target.closest(".quality-option");
    if (qualityOption) {
      qualityOption.parentElement.querySelectorAll(".quality-option").forEach(item => item.classList.toggle("selected", item === qualityOption));
      const resolutionText = qualityOption.querySelector("b")?.textContent.trim() || "1080p";
      const resolution = resolutionText === "4K" ? "2160p" : resolutionText;
      const frameText = qualityOption.querySelector("small")?.textContent || "60 frames/sec";
      const fpsMatch = frameText.includes("30–60") ? [null, "60"] : frameText.match(/(30|60|120)/);
      Promise.all([commitSetting("resolution", resolution, { silent: true }), commitSetting("frameRate", fpsMatch ? fpsMatch[1] : "60", { silent: true })]).then(() => showToast(`Default stream profile saved: ${resolution}`));
      return;
    }
    const layout = event.target.closest(".layout-choice");
    if (layout) {
      layout.parentElement.querySelectorAll(".layout-choice").forEach(item => item.classList.toggle("active", item === layout));
      showToast(`${layout.querySelector("b")?.textContent || "Layout"} selected · preview only`);
      return;
    }
    const settingTab = event.target.closest(".settings-nav button");
    if (settingTab) {
      renderDesktopSettings(settingTab.dataset.desktopSetting || settingTab.textContent.trim());
      return;
    }
    const goto = event.target.closest("[data-goto]");
    if (goto) {
      showPage(goto.dataset.goto);
      return;
    }
    const toastAction = event.target.closest("[data-toast]");
    if (toastAction) {
      showToast(toastAction.dataset.toast);
      return;
    }
    const previewAction = event.target.closest(".primary-action,.secondary-action,.outline-button,.tab-strip button,.filter-pill,.sort-pill,.library-card-info button,.range-tabs button,.mock-toggle,.accent-choices i,.window-controls button,.icon-button");
    if (previewAction) {
      if (previewAction.classList.contains("mock-toggle")) previewAction.classList.toggle("enabled");
      if (previewAction.matches(".accent-choices i")) {
        previewAction.parentElement.querySelectorAll("i").forEach(item => item.classList.toggle("selected-accent", item === previewAction));
      }
      if (previewAction.matches(".tab-strip button,.range-tabs button")) {
        previewAction.parentElement.querySelectorAll("button").forEach(item => item.classList.toggle("active", item === previewAction));
      }
      showToast("Preview control changed locally; nothing is saved.");
      event.preventDefault();
    }
  });

  overlay?.addEventListener("click", event => {
    if (event.target === overlay) closeConsolePanel();
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
      if (overlay && !overlay.hasAttribute("hidden")) closeConsolePanel();
      else if (consoleUI.classList.contains("active")) enterDesktop();
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
      event.preventDefault();
      showToast("Quick find is a visual placeholder in this preview");
    }
  });

  document.querySelectorAll(".settings-nav button").forEach((button, index) => {
    button.dataset.desktopSetting = Object.keys(settingsSections)[index] || "Appearance";
  });
  document.querySelectorAll(".console-cover").forEach((button,index) => button.setAttribute("aria-pressed",String(index===0)));

  /* ——— Accent color system: updates logo gradients + CSS variables ——— */
  function applyAccent(key, notify = true) {
    const p = ACCENTS[key] || ACCENTS.cyan;
    const root = document.documentElement;
    root.style.setProperty("--accent", p.a);
    root.style.setProperty("--accent-2", p.a2);
    root.style.setProperty("--accent-3", p.a3);
    root.style.setProperty("--accent-glow", p.glow);
    root.style.setProperty("--cyan", p.a);
    root.style.setProperty("--blue", p.a2);
    root.style.setProperty("--violet", p.a3);
    root.dataset.accent = key;

    ["logoGradientDesktop", "logoGradientConsole"].forEach(id => {
      const grad = document.getElementById(id);
      if (!grad) return;
      const stops = grad.querySelectorAll("stop");
      p.stops.forEach((c, i) => { if (stops[i]) stops[i].setAttribute("stop-color", c); });
    });

    const areaStops = document.querySelectorAll("#areaBlue stop");
    if (areaStops[0]) areaStops[0].setAttribute("stop-color", p.a);
    if (areaStops[1]) areaStops[1].setAttribute("stop-color", p.a);
    document.querySelectorAll(".line-chart path[stroke]").forEach(path => {
      path.setAttribute("stroke", p.a);
    });

    document.querySelectorAll(".accent-choices [data-setting-accent]").forEach(el => {
      const selected = el.dataset.settingAccent === key;
      el.classList.toggle("selected-accent", selected);
      el.setAttribute("aria-pressed", String(selected));
    });
    if (notify) showToast(`Accent → ${p.name}`);
  }

  document.addEventListener("change", event => {
    const input = event.target.closest("[data-setting-key]");
    if (input) {
      const field = Object.values(settingsSections).flatMap(section => section.rows).find(row => row.key === input.dataset.settingKey);
      if (!field) return;
      const value = field.type === "range" ? Number(input.value) : input.value;
      commitSetting(field.key, value);
      return;
    }
    const importInput = event.target.closest(".settings-import-file");
    if (importInput) handleSettingsImport(importInput);
  });

  document.addEventListener("input", event => {
    const range = event.target.closest('input[type="range"][data-setting-key]');
    if (range) {
      const output = document.querySelector(`[data-range-output="${range.dataset.settingKey}"]`);
      if (output) output.textContent = `${range.value} Mbps`;
    }
  });

  document.addEventListener("keydown", event => {
    const swatch = event.target.closest("[data-setting-accent]");
    if (swatch && (event.key === "Enter" || event.key === " ")) {
      event.preventDefault();
      commitSetting("accent", swatch.dataset.settingAccent);
    }
  });

  /* Initialize settings UI, then apply any settings loaded from durable storage. */
  document.querySelectorAll(".settings-nav button").forEach((button, index) => {
    button.dataset.desktopSetting = Object.keys(settingsSections)[index] || "Appearance";
  });
  renderDesktopSettings("Appearance");
  applyStoredSettings();
  window.NEXORASettingsStore.subscribe(() => refreshSettingsStatus());
  window.NEXORASettingsStore.ready.then(() => {
    applyStoredSettings();
    renderDesktopSettings(activeDesktopSettings);
    if (!window.NEXORASettingsStore.get("desktopModeOnStartup")) enterConsole();
  }).catch(() => {
    applyStoredSettings();
    showToast("Settings loaded with defaults; storage may be unavailable");
  });
  document.querySelectorAll(".console-cover").forEach((button,index) => button.setAttribute("aria-pressed",String(index===0)));
})();
