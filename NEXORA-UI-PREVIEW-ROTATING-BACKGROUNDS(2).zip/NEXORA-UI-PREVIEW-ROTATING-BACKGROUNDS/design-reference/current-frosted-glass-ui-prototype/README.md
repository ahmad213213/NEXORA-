# NEXORA UI Prototype — Frosted Glass Desktop + Console

This is the approved visual prototype for inspecting the NEXORA layout. It is intentionally opened by the root `PREVIEW.bat`. This preview starts with an **empty game library**; no example game titles or sample cover cards are displayed.

## Run

- **Windows:** double-click `PREVIEW.bat` in the project root.
- **Any modern browser:** open this folder's `index.html`.
- No install, build step, Node.js runtime, or online artwork request is required for the UI preview.

## Empty-state behavior

The empty-state default wallpaper rotates on each opening in this order: **Space Horizon → Nebula → Forest Vista → Earth Orbit → Space Horizon**. The same selected local image is used by the Desktop backdrop/hero and the Console backdrop. If browser local storage is blocked for a `file://` page, the script uses a time-based fallback.

Dashboard, Library, and Console Mode show “No games added yet” / empty-library states. Add Game buttons are placeholders and only tell you that game adding will be implemented later; they do not add games in this phase.

## UI interactions available for preview

- Desktop sidebar navigation and separate screens for Library, Remote Play, AI Patcher, Streaming, Networking, Controls, Performance, and Settings.
- The top-right controller icon switches between Desktop and Console mode.
- Console Settings, Updates, Quality, and Stream panels can be inspected.
- Settings appearance preferences use the prototype's local settings store, including import/export/reset.

Native Electron window controls, Windows startup/tray behavior, native file dialogs, game adding and launching, pairing, hardware telemetry, real streaming, and updater services are not implemented by this browser-only prototype.


Default background sequence: Space Horizon → Nebula → Forest Vista → Earth Orbit → repeat. The chosen local background advances on each fresh opening.
