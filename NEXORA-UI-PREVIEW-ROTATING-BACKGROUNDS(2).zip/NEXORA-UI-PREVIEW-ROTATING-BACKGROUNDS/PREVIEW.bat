@echo off
setlocal
rem NEXORA UI preview only. This opens the approved frosted-glass Desktop/Console prototype.
rem No game entries are preloaded. The empty-state background rotates on each opening.
set "PREVIEW=%~dp0design-reference\current-frosted-glass-ui-prototype\index.html"
if not exist "%PREVIEW%" (
  echo ERROR: The NEXORA UI prototype was not found:
  echo "%PREVIEW%"
  pause
  exit /b 1
)
echo Opening the NEXORA frosted-glass UI preview...
start "NEXORA UI Preview" "%PREVIEW%"
if errorlevel 1 (
  echo Could not open the preview automatically.
  echo Open this file manually:
  echo "%PREVIEW%"
  pause
  exit /b 1
)
echo.
echo This is a UI prototype. Game adding, real streaming, and native Electron actions are not enabled yet.
endlocal
