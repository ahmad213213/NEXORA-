This package is for UI preview only. Program-build and installer BAT files are intentionally not included yet.

Double-click PREVIEW.bat to open the established frosted-glass prototype in your browser. It starts with no games and cycles the default empty-library background across Space Horizon, Nebula, Forest Vista, and Earth Orbit each time it opens.

This does not test the NSIS installer, native Electron window controls, game launching, or Remote Play. Those are separate later tasks.
