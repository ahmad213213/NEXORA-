import { cp, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const appRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
await mkdir(path.join(appRoot, 'dist'), { recursive: true });
await cp(path.join(appRoot, 'src', 'ui'), path.join(appRoot, 'dist', 'ui'), { recursive: true });
// NEXORA ORBIT is plain .mjs (not compiled by tsc): copy it next to the compiled output.
await cp(path.join(appRoot, 'src', 'orbit'), path.join(appRoot, 'dist', 'orbit'), { recursive: true, filter: src => !/\.(d\.mts|ts)$/.test(src) });
await mkdir(path.join(appRoot, 'dist', 'release'), { recursive: true });
await cp(path.resolve(appRoot, '..', '..', 'scripts', 'release', 'apply-update.ps1'), path.join(appRoot, 'dist', 'release', 'apply-update.ps1'));
await cp(path.resolve(appRoot, '..', '..', 'scripts', 'release', 'apply-local-update.ps1'), path.join(appRoot, 'dist', 'release', 'apply-local-update.ps1'));
