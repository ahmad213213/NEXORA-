import test from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync, sign } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const mod = await import(path.join(root, 'apps/host/dist/update/manifest.js'));

function signedManifest() {
  const { publicKey, privateKey } = generateKeyPairSync('ed25519');
  const payload = { schema: 1, product: 'NEXORA-Host', version: '0.2.0', platform: 'win32-x64-portable', url: 'https://updates.example.test/NEXORA-Host-0.2.0.zip', sha256: 'a'.repeat(64), size: 1234, publishedAt: new Date().toISOString() };
  const signature = sign(null, Buffer.from(mod.canonicalManifestPayload(payload)), privateKey).toString('base64');
  const publicKeyDer = publicKey.export({ format: 'der', type: 'spki' }).toString('base64');
  return { manifest: { ...payload, signature }, publicKeyDer };
}

test('semantic version comparison is safe', () => {
  assert.equal(mod.compareVersions('0.2.0', '0.1.9'), 1);
  assert.equal(mod.compareVersions('0.1.0', '0.1.0'), 0);
  assert.equal(mod.compareVersions('0.1.0', '0.2.0'), -1);
});

test('valid signed update manifest verifies', () => {
  const { manifest, publicKeyDer } = signedManifest();
  assert.equal(mod.verifyManifestSignature(manifest, publicKeyDer), true);
});

test('tampered manifest signature fails', () => {
  const { manifest, publicKeyDer } = signedManifest();
  manifest.sha256 = 'b'.repeat(64);
  assert.equal(mod.verifyManifestSignature(manifest, publicKeyDer), false);
});

test('manifest rejects non-HTTPS package URLs', () => {
  const { manifest } = signedManifest();
  manifest.url = 'http://updates.example.test/file.zip';
  assert.throws(() => mod.validateManifest(manifest), /HTTPS/);
});

test('external updater script contains wait, hash verification and rollback', async () => {
  const script = await readFile(path.join(root, 'scripts/release/apply-update.ps1'), 'utf8');
  assert.match(script, /Get-Process/);
  assert.match(script, /Get-FileHash/);
  assert.match(script, /backup/);
  assert.match(script, /Windows\.Forms/);
  assert.match(script, /Get-Process -Id/);
});
