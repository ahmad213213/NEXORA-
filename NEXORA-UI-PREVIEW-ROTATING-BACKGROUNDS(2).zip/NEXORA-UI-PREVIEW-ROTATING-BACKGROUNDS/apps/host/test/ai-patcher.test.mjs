import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const root = new URL('../src/', import.meta.url);
const source = () => readFile(new URL('ai-patcher.ts', root), 'utf8');

test('AI patcher encrypts provider keys and requires a configured workspace', async () => {
  const code = await source();
  assert.match(code, /safeStorage\.encryptString/);
  assert.match(code, /safeStorage\.decryptString/);
  assert.match(code, /encryptedKeys\[provider\]/);
  assert.match(code, /if \(!s\.workspace\)/);
  assert.match(code, /if \(!s\.encryptedKeys\?\.\[s\.provider\]\)/);
});

test('AI patcher bounds source context and excludes secrets, dependencies, and lockfiles', async () => {
  const code = await source();
  assert.match(code, /MAX_FILES = 36/);
  assert.match(code, /MAX_CONTEXT_CHARS = 100_000/);
  assert.match(code, /\.env/);
  assert.match(code, /node_modules/);
  assert.match(code, /\.lock/);
});

test('AI patcher rejects unsafe paths and detects stale proposals before writing', async () => {
  const code = await source();
  assert.match(code, /p === '\.\.'/);
  assert.match(code, /createHash\('sha256'\)/);
  assert.match(code, /File changed after proposal/);
  assert.match(code, /Patch failed and completed changes were rolled back/);
});

test('patching is approval-gated and offers backup rollback and bounded checks', async () => {
  const main = await readFile(new URL('main.ts', root), 'utf8');
  const preload = await readFile(new URL('preload.cts', root), 'utf8');
  const ui = await readFile(new URL('ui/app.js', root), 'utf8');
  const code = await source();
  assert.match(main, /ai-patcher:apply/);
  assert.match(preload, /applyAiPatch/);
  assert.match(ui, /Apply reviewed patch/);
  assert.match(ui, /Rollback last patch/);
  assert.match(ui, /Run project check/);
  assert.match(code, /\['typecheck', 'build', 'test'\]/);
  assert.match(code, /last-patch\.json/);
});

test('proposals show a reviewable diff before the apply action', async () => {
  const code = await source();
  const ui = await readFile(new URL('ui/app.js', root), 'utf8');
  assert.match(code, /function buildDiff/);
  assert.match(code, /diff: buildDiff/);
  assert.match(ui, /file\.diff \|\| file\.content/);
});
