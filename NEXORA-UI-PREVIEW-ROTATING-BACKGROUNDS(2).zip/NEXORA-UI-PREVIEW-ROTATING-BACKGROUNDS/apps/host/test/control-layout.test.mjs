import test from 'node:test';
import assert from 'node:assert/strict';
import { createDefaultLayout, validateControlLayout, normalizeControlLayout } from '../../../packages/shared/dist/index.js';
test('default layout is valid and bounded',()=>{const l=createDefaultLayout('action');assert.equal(validateControlLayout(l),true);assert.ok(l.controls.length<=24);for(const c of l.controls){assert.ok(c.x>=0&&c.x+c.width<=1);assert.ok(c.y>=0&&c.y+c.height<=1)}});
test('invalid duplicate IDs are rejected',()=>{const l=createDefaultLayout();l.controls.push({...l.controls[0]});assert.equal(validateControlLayout(l),false)});
test('oversized layout is rejected',()=>{const l=createDefaultLayout();l.controls=Array.from({length:25},(_,i)=>({...l.controls[0],id:`x${i}`}));assert.equal(validateControlLayout(l),false)});
test('normalization trims labels and bounds opacity precision',()=>{const l=createDefaultLayout();l.controls[0].label='  D  ';l.controls[0].opacity=.876;const n=normalizeControlLayout(l);assert.equal(n.controls[0].label,'D');assert.equal(n.controls[0].opacity,.88)});
