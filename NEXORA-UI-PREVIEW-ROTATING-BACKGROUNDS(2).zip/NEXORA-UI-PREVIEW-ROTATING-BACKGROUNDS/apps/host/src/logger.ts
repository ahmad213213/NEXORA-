import { app } from 'electron';
import { appendFile, mkdir } from 'node:fs/promises';
import path from 'node:path';

export type LogLevel = 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';
let logFile = '';
let queue = Promise.resolve();

export async function initLogger(): Promise<void> {
  const dir = path.join(app.getPath('userData'), 'logs');
  await mkdir(dir, { recursive: true });
  logFile = path.join(dir, 'nexora.jsonl');
}

export function log(level: LogLevel, message: string, meta?: Record<string, unknown>): Promise<void> {
  const entry = JSON.stringify({
    time: new Date().toISOString(),
    level,
    message,
    ...(meta ? { meta } : {})
  }) + '\n';

  queue = queue.then(async () => {
    if (!logFile) return;
    try {
      await appendFile(logFile, entry, 'utf8');
    } catch {
      // Logging must never crash the host.
    }
  });
  return queue;
}
