import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';

export interface PairedDevice { deviceId: string; publicKey: string; name: string; pairedAt: number; lastSeenAt: number | null; revokedAt?: number }
const ID = /^[a-f0-9]{32}$/;
const KEY = /^[A-Za-z0-9_-]{43}$/;
const NAME_MAX = 64;

function filePath(dir: string) { return path.join(dir, 'paired-devices.json'); }
async function atomic(file: string, data: unknown) { const tmp = `${file}.tmp`; await writeFile(tmp, JSON.stringify(data, null, 2), { encoding: 'utf8', mode: 0o600 }); await rename(tmp, file); }

export class PairingStore {
  private devices = new Map<string, PairedDevice>();
  private loaded = false;
  constructor(private readonly dir: string) {}
  async init() {
    if (this.loaded) return;
    await mkdir(this.dir, { recursive: true });
    try {
      const raw = JSON.parse(await readFile(filePath(this.dir), 'utf8'));
      if (!Array.isArray(raw)) throw new Error('invalid pairing store');
      for (const d of raw) if (isPairedDevice(d) && !d.revokedAt) this.devices.set(d.deviceId, d);
    } catch { /* first run or invalid store: start empty; identity is never regenerated here */ }
    this.loaded = true;
  }
  list() { return [...this.devices.values()].map(d => ({ ...d })); }
  get(id: string) { const d = this.devices.get(id); return d ? { ...d } : undefined; }
  isAuthorized(id: string) { return this.devices.has(id); }
  async authorize(device: PairedDevice) { await this.init(); this.devices.set(device.deviceId, { ...device, revokedAt: undefined }); await atomic(filePath(this.dir), this.list()); }
  async touch(id: string, now = Date.now()) { await this.init(); const d = this.devices.get(id); if (!d) return false; d.lastSeenAt = now; await atomic(filePath(this.dir), this.list()); return true; }
  async revoke(id: string, now = Date.now()) { await this.init(); const d = this.devices.get(id); if (!d) return false; this.devices.delete(id); await atomic(filePath(this.dir), [...this.list(), { ...d, revokedAt: now }]); return true; }
}

export class PinManager {
  private current: { pin: string; expiresAt: number; used: boolean } | null = null;
  private bad = new Map<string, { count: number; since: number }>();
  constructor(private readonly ttlMs = 120_000, private readonly maxAttempts = 5, private readonly windowMs = 600_000) {}
  open(now = Date.now()) {
    const pin = String(Math.floor(Math.random() * 1_000_000)).padStart(6, '0');
    this.current = { pin, expiresAt: now + Math.max(30_000, Math.min(600_000, this.ttlMs)), used: false };
    return { pin, expiresAt: this.current.expiresAt };
  }
  inspect(now = Date.now()) { if (!this.current || this.current.used || this.current.expiresAt <= now) return null; return { expiresAt: this.current.expiresAt }; }
  consume(pin: string, source: string, now = Date.now()): 'accepted' | 'invalid' | 'rate_limited' | 'expired' {
    const b = this.bad.get(source); if (b && now - b.since <= this.windowMs && b.count >= this.maxAttempts) return 'rate_limited';
    if (!/^\d{6}$/.test(pin) || !this.current || this.current.used || this.current.expiresAt <= now) return 'expired';
    if (pin !== this.current.pin) { const next = !b || now - b.since > this.windowMs ? { count: 1, since: now } : { count: b.count + 1, since: b.since }; this.bad.set(source, next); return next.count >= this.maxAttempts ? 'rate_limited' : 'invalid'; }
    // PIN is intentionally single-use: successful pairing consumes it immediately.
    this.current.used = true; this.current = null; this.bad.delete(source); return 'accepted';
  }
}

export function isPairedDevice(v: unknown): v is PairedDevice {
  if (!v || typeof v !== 'object' || Array.isArray(v)) return false; const x = v as Record<string, unknown>;
  return ID.test(String(x.deviceId)) && KEY.test(String(x.publicKey)) && typeof x.name === 'string' && x.name.length <= NAME_MAX && Number.isSafeInteger(x.pairedAt) && (x.lastSeenAt === null || Number.isSafeInteger(x.lastSeenAt));
}
