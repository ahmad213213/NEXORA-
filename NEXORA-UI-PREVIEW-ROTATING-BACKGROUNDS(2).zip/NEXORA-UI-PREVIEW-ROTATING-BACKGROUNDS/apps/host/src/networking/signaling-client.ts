import { createEnvelope, encodeEnvelope, type MessageType, type SessionState } from '@nexora/shared';
import { randomBytes } from 'node:crypto';
import { authBytes, loadOrCreateIdentity, sessionSignatureBytes, type DeviceIdentity } from './security.js';
import { PairingStore, PinManager } from './pairing.js';
import { SessionSecurity, type SecureMessage } from './session-security.js';

export interface SignalingTransport { send(data: string): void; close(): void; readonly readyState: number; onopen: (() => void) | null; onmessage: ((event: { data: unknown }) => void) | null; onclose: (() => void) | null; onerror: (() => void) | null }
export interface SignalingHooks { onStatus?(status: 'connecting' | 'connected' | 'disconnected'): void; onPairingPin?(pin: string, expiresAt: number): void; onPairRequest?(device: { deviceId: string; publicKey: string; name: string }): Promise<boolean>; onSignal?(message: SecureMessage): void; onSessionState?(state: SessionState, peerId: string, sessionId: string): void; }
const URL_RE = /^wss:\/\/[^\s]{1,512}$/i;

export class SignalingClient {
  readonly identity: DeviceIdentity;
  readonly pairing: PairingStore;
  readonly pins = new PinManager();
  private socket: SignalingTransport | null = null;
  private sequence = 0;
  private serverNonce = '';
  private readonly controlSessionId = 'control_0001';
  private stopped = true;
  private reconnectTimer: ReturnType<typeof setTimeout> | undefined;
  private attempts = 0;
  private sessions = new Map<string, SessionSecurity>();
  constructor(identity: DeviceIdentity, pairingDir: string, private url: string, private readonly transportFactory: (url: string) => SignalingTransport, private readonly hooks: SignalingHooks = {}) { this.identity = identity; this.pairing = new PairingStore(pairingDir); }
  setUrl(url: string) { if (!URL_RE.test(url)) throw new Error('Invalid signaling URL'); this.url = url; }
  async start() { await this.pairing.init(); this.stopped = false; this.connect(); }
  stop() { this.stopped = true; if (this.reconnectTimer) clearTimeout(this.reconnectTimer); this.reconnectTimer = undefined; try { this.socket?.close(); } catch {} this.socket = null; }
  openPairing() { this.sendRaw({ type: 'pair.open', payload: {} }); }
  createSession(peerId: string, now = Date.now()) {
    if (!/^[a-f0-9]{32}$/.test(peerId)) throw new Error('Invalid peer ID');
    if (!this.socket || this.socket.readyState !== 1) throw new Error('Signaling transport is not connected');
    const sessionId = `sess_${cryptoRandomId()}`;
    const security = new SessionSecurity(sessionId, this.identity.deviceId, peerId, 1);
    this.sessions.set(sessionId, security);
    security.transition('negotiating');
    if (!this.sendSigned('session.open', sessionId, peerId, { requestedAt: now })) {
      this.sessions.delete(sessionId);
      throw new Error('Failed to send session.open');
    }
    return sessionId;
  }
  sendSession(type: Extract<MessageType, 'sdp.offer'|'sdp.answer'|'ice.candidate'|'session.close'>, sessionId: string, peerId: string, payload: Record<string, unknown>) { const s = this.sessions.get(sessionId); if (!s || s.lifecycle === 'closed') throw new Error('Unknown or closed session'); this.sendSigned(type, sessionId, peerId, payload); }
  markSession(sessionId: string, state: SessionState) { const s = this.sessions.get(sessionId); if (!s) return false; s.transition(state); return true; }
  closeSession(sessionId: string) { const s = this.sessions.get(sessionId); if (!s) return; if (s.lifecycle !== 'closed') { if (s.lifecycle === 'connected') s.transition('disconnected'); if (s.lifecycle === 'disconnected' || s.lifecycle === 'negotiating' || s.lifecycle === 'created') s.transition('closed'); } this.sessions.delete(sessionId); }
  private connect() { if (this.stopped) return; this.hooks.onStatus?.('connecting'); let ws: SignalingTransport; try { ws = this.transportFactory(this.url); } catch { this.retry(); return; } this.socket = ws; ws.onopen = () => { this.attempts = 0; this.hooks.onStatus?.('connected'); }; ws.onmessage = e => { try { const m = JSON.parse(String(e.data)); if (m && typeof m === 'object') void this.handle(m); } catch {} }; ws.onclose = () => { if (this.socket === ws) this.socket = null; this.hooks.onStatus?.('disconnected'); this.retry(); }; ws.onerror = () => {}; }
  private retry() { if (this.stopped) return; const delay = Math.min(30_000, 1000 * 2 ** Math.min(this.attempts++, 5)); this.reconnectTimer = setTimeout(() => this.connect(), delay); }
  private sendRaw(message: { type: string; payload: Record<string, unknown> }) { if (!this.socket || this.socket.readyState !== 1) return false; try { const env = createEnvelope(message.type as MessageType, this.controlSessionId, ++this.sequence, message.payload); this.socket.send(encodeEnvelope(env)); return true; } catch { return false; } }
  private sendSigned(type: MessageType, sessionId: string, peerId: string, payload: Record<string, unknown>) { const sequence = ++this.sequence; const signature = this.identity.sign(sessionSignatureBytes({ type, from: this.identity.deviceId, to: peerId, sessionId, sequence, payload, protocolVersion: 1 })); return this.sendRaw({ type, payload: { sessionId, peerId, sequence, timestamp: Date.now(), from: this.identity.deviceId, to: peerId, data: payload, signature } }); }
  private async handle(m: any) {
    if (m.type === 'hello' && typeof m.payload?.nonce === 'string') { this.serverNonce = m.payload.nonce; this.sendRaw({ type: 'auth', payload: { role: 'host', deviceId: this.identity.deviceId, publicKey: this.identity.publicKey, signature: this.identity.sign(authBytes('host', this.identity.deviceId, this.serverNonce, 1)) } }); return; }
    if (m.type === 'pair.opened' && typeof m.payload?.pin === 'string') { const pin = String(m.payload.pin); if (/^\d{6}$/.test(pin)) this.hooks.onPairingPin?.(pin, Number(m.payload.expiresAt)); return; }
    if (m.type === 'pair.request') { const p = m.payload; if (typeof p?.deviceId !== 'string' || typeof p.publicKey !== 'string' || typeof p.name !== 'string') return; if (await this.hooks.onPairRequest?.({ deviceId: p.deviceId, publicKey: p.publicKey, name: p.name })) await this.pairing.authorize({ deviceId: p.deviceId, publicKey: p.publicKey, name: p.name.slice(0,64), pairedAt: Date.now(), lastSeenAt: null }); return; }
    if (!['sdp.offer','sdp.answer','ice.candidate','session.close','session.open','session.state'].includes(m.type)) return;
    const p = m.payload; if (!p || typeof p.sessionId !== 'string' || typeof p.from !== 'string' || typeof p.to !== 'string' || !Number.isSafeInteger(p.sequence) || typeof p.signature !== 'string' || typeof p.data !== 'object') return;
    const session = this.sessions.get(p.sessionId); if (!session || p.from !== this.identity.deviceId && p.to !== this.identity.deviceId) return;
    const peer = p.from === this.identity.deviceId ? p.to : p.from; const paired = this.pairing.get(peer); if (!paired) return;
    const secure: SecureMessage = { protocol:'NEXORA', version:1, type:m.type, sessionId:p.sessionId, sequence:p.sequence, timestamp:Number(p.timestamp), from:p.from, to:p.to, payload:p.data, signature:p.signature };
    if (!session.validateInbound(secure, paired.publicKey)) return;
    if (m.type === 'session.state' && typeof p.data?.state === 'string') this.hooks.onSessionState?.(p.data.state as SessionState, peer, p.sessionId); else this.hooks.onSignal?.(secure);
  }
}
function cryptoRandomId() { return randomBytes(18).toString('base64url'); }

export function createWebSocketTransport(url: string): SignalingTransport {
  const WS = (globalThis as any).WebSocket as (new (url: string) => SignalingTransport) | undefined; if (!WS) throw new Error('WebSocket runtime is unavailable'); return new WS(url);
}
