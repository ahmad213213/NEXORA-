import { createHash, verify as verifySignature } from 'node:crypto';

export interface UpdateManifest {
  schema: 1;
  product: 'NEXORA-Host';
  version: string;
  platform: 'win32-x64-portable';
  url: string;
  sha256: string;
  size: number;
  publishedAt: string;
  signature: string;
}

const VERSION_RE = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/;
const SHA_RE = /^[a-f0-9]{64}$/i;
export const UPDATE_KEY_PLACEHOLDER = 'REPLACE_WITH_RELEASE_PUBLIC_KEY_BASE64';
const TEST_PUBLIC_KEY_B64 = process.env.NEXORA_UPDATE_PUBLIC_KEY_B64 ?? UPDATE_KEY_PLACEHOLDER;

export function isUpdateKeyConfigured(publicKeyB64: string = TEST_PUBLIC_KEY_B64): boolean {
  return publicKeyB64.trim() !== '' && publicKeyB64 !== UPDATE_KEY_PLACEHOLDER;
}

export function parseVersion(version: string): [number, number, number] {
  if (!VERSION_RE.test(version)) throw new Error('Invalid version');
  const core = version.split(/[+-]/, 1)[0].split('.').map(Number);
  return [core[0], core[1], core[2]];
}

export function compareVersions(a: string, b: string): number {
  const av = parseVersion(a); const bv = parseVersion(b);
  for (let i = 0; i < 3; i++) if (av[i] !== bv[i]) return av[i] > bv[i] ? 1 : -1;
  return 0;
}

export function canonicalManifestPayload(m: Omit<UpdateManifest, 'signature'>): string {
  return JSON.stringify({ schema: m.schema, product: m.product, version: m.version, platform: m.platform, url: m.url, sha256: m.sha256.toLowerCase(), size: m.size, publishedAt: m.publishedAt });
}

export function validateManifest(input: unknown): UpdateManifest {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Invalid update manifest');
  const m = input as Record<string, unknown>;
  if (m.schema !== 1 || m.product !== 'NEXORA-Host' || m.platform !== 'win32-x64-portable') throw new Error('Unsupported update manifest');
  if (typeof m.version !== 'string' || !VERSION_RE.test(m.version)) throw new Error('Invalid update version');
  if (typeof m.url !== 'string' || !/^https:\/\//i.test(m.url)) throw new Error('Update URL must use HTTPS');
  if (typeof m.sha256 !== 'string' || !SHA_RE.test(m.sha256)) throw new Error('Invalid update hash');
  if (typeof m.size !== 'number' || !Number.isSafeInteger(m.size) || m.size <= 0) throw new Error('Invalid update size');
  if (typeof m.publishedAt !== 'string' || !m.publishedAt.trim()) throw new Error('Invalid publish time');
  if (typeof m.signature !== 'string' || !/^[A-Za-z0-9+/=]+$/.test(m.signature)) throw new Error('Invalid signature');
  return { schema: 1, product: 'NEXORA-Host', version: m.version, platform: 'win32-x64-portable', url: m.url, sha256: m.sha256.toLowerCase(), size: m.size, publishedAt: m.publishedAt, signature: m.signature };
}

export function verifyManifestSignature(manifest: UpdateManifest, publicKeyB64 = TEST_PUBLIC_KEY_B64): boolean {
  if (!isUpdateKeyConfigured(publicKeyB64)) return false;
  const { signature, ...payload } = manifest;
  return verifySignature(null, Buffer.from(canonicalManifestPayload(payload)), { key: Buffer.from(publicKeyB64, 'base64'), format: 'der', type: 'spki' }, Buffer.from(signature, 'base64'));
}

export function sha256(bytes: Uint8Array): string {
  return createHash('sha256').update(bytes).digest('hex');
}
