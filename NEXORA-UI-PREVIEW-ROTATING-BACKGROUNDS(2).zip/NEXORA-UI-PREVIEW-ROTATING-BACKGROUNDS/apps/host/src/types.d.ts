declare global {
  interface Window {
    nexora: {
      getConfig: () => Promise<import('./config.js').HostConfig>;
      setConfig: (value: unknown) => Promise<import('./config.js').HostConfig>;
      getSettingsCapabilities: () => Promise<{ platform: string; packaged: boolean; startupSupported: boolean; startupWarning: string | null; storagePath: string }>;
      exportSettings: () => Promise<{ cancelled: boolean; fileName?: string }>;
      importSettings: () => Promise<{ cancelled: boolean; config?: import('./config.js').HostConfig }>;
      resetSettings: () => Promise<import('./config.js').HostConfig>;
      getVersion: () => Promise<string>;
      updateFromFile: (mode: 'patch' | 'restore') => Promise<{ status: 'started' | 'cancelled' | 'rejected' | 'unavailable'; reason?: string }>;
      getSystemStats: () => Promise<import('./system-stats.js').SystemStats>;
      getAiPatcherSettings: () => Promise<{ provider: string; model: string; workspace: string; keyConfigured: boolean }>;
      setAiPatcherSettings: (value: unknown) => Promise<{ provider: string; model: string; workspace: string; keyConfigured: boolean }>;
      chooseAiPatcherWorkspace: () => Promise<{ cancelled: boolean; settings?: { provider: string; model: string; workspace: string; keyConfigured: boolean } }>;
      proposeAiPatch: (request: string) => Promise<{ id: string; request: string; summary: string; files: Array<{ path: string; content: string; diff: string; summary: string; existed: boolean }>; createdAt: string }>;
      applyAiPatch: (id: string) => Promise<{ backup: string; changed: string[] }>;
      discardAiPatch: () => Promise<boolean>;
      rollbackAiPatch: () => Promise<{ restored: string[] }>;
      runAiPatchCheck: (check: 'typecheck' | 'build' | 'test') => Promise<{ ok: boolean; code: number | null; output: string; command: string }>;
    };
  }
}
export {};
