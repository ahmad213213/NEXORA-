export type CaptureBackend = 'ddagrab' | 'gdigrab';
export type VideoEncoder = 'nvenc' | 'qsv' | 'amf' | 'x264';

export interface VideoQuality {
  width: number;
  height: number;
  fps: number;
  bitrateKbps: number;
}

export interface StreamingConfig extends VideoQuality {
  ffmpegPath: string;
  capture: CaptureBackend;
  encoder: 'auto' | VideoEncoder;
  audioDevice: string | null;
}

export interface MediaSink {
  video(packet: Buffer): void;
  audio(packet: Buffer): void;
}

export interface StreamStats {
  videoPackets: number;
  audioPackets: number;
  videoBytes: number;
  audioBytes: number;
  restarts: number;
  encoder: VideoEncoder;
  quality: VideoQuality;
  running: boolean;
  startedAt: number | null;
}
