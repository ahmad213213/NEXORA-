import { spawn, type ChildProcess } from 'node:child_process';
import type { CaptureBackend, VideoEncoder, VideoQuality } from './types.js';

export const VIDEO_PT = 96;
export const AUDIO_PT = 111;
export const VIDEO_SSRC = 0x4e585631;
export const AUDIO_SSRC = 0x4e585841;
export const H264_FMTP = 'profile-level-id=42e01f;packetization-mode=1;level-asymmetry-allowed=1';
const COMMON = ['-hide_banner', '-loglevel', 'warning', '-nostdin'];
const GOP_SECONDS = 1;

export function clampQuality(input: Partial<VideoQuality>, fallback: VideoQuality): VideoQuality {
  const width = Number.isFinite(input.width) ? Math.round(input.width!) : fallback.width;
  const height = Number.isFinite(input.height) ? Math.round(input.height!) : fallback.height;
  const fps = Number.isFinite(input.fps) ? Math.round(input.fps!) : fallback.fps;
  const bitrateKbps = Number.isFinite(input.bitrateKbps) ? Math.round(input.bitrateKbps!) : fallback.bitrateKbps;
  return {
    width: Math.max(320, Math.min(3840, width)) & ~1,
    height: Math.max(180, Math.min(2160, height)) & ~1,
    fps: Math.max(15, Math.min(120, fps)),
    bitrateKbps: Math.max(350, Math.min(25000, bitrateKbps))
  };
}

export function encoderCodec(encoder: VideoEncoder): string {
  return { nvenc: 'h264_nvenc', qsv: 'h264_qsv', amf: 'h264_amf', x264: 'libx264' }[encoder];
}

export function encoderArgs(encoder: VideoEncoder, quality: VideoQuality): string[] {
  const g = Math.max(10, Math.round(quality.fps * Math.min(GOP_SECONDS, 1)));
  const rate = ['-b:v', `${quality.bitrateKbps}k`, '-maxrate', `${quality.bitrateKbps}k`, '-bufsize', `${Math.max(500, Math.round(quality.bitrateKbps / 2))}k`];
  switch (encoder) {
    case 'nvenc':
      return ['-c:v', 'h264_nvenc', '-preset', 'p1', '-tune', 'll', '-rc', 'cbr', '-zerolatency', '1', '-profile:v', 'baseline', '-pix_fmt', 'yuv420p', '-bf', '0', '-g', String(g), '-keyint_min', String(g), '-forced-idr', '1', ...rate];
    case 'qsv':
      return ['-c:v', 'h264_qsv', '-preset', 'veryfast', '-profile:v', 'baseline', '-pix_fmt', 'yuv420p', '-look_ahead', '0', '-bf', '0', '-async_depth', '1', '-g', String(g), '-keyint_min', String(g), ...rate];
    case 'amf':
      return ['-c:v', 'h264_amf', '-usage', 'ultralowlatency', '-quality', 'speed', '-rc', 'cbr', '-profile:v', 'constrained_baseline', '-pix_fmt', 'yuv420p', '-bf', '0', '-g', String(g), '-keyint_min', String(g), ...rate];
    default:
      return ['-c:v', 'libx264', '-preset', 'ultrafast', '-tune', 'zerolatency', '-profile:v', 'baseline', '-x264-params', `keyint=${g}:min-keyint=${g}:scenecut=0:repeat-headers=1:bframes=0`, '-g', String(g), '-keyint_min', String(g), ...rate];
  }
}

export function buildVideoArgs(options: {
  capture: CaptureBackend;
  encoder: VideoEncoder;
  quality: VideoQuality;
  port: number;
  inputArgs?: string[];
}): string[] {
  const { quality } = options;
  const fit = `scale=${quality.width}:${quality.height}:force_original_aspect_ratio=decrease:flags=fast_bilinear,pad=${quality.width}:${quality.height}:(ow-iw)/2:(oh-ih)/2,format=yuv420p`;
  const input = options.inputArgs ?? (options.capture === 'ddagrab'
    ? ['-f', 'lavfi', '-i', `ddagrab=output_idx=0:framerate=${quality.fps}:draw_mouse=1`]
    : ['-f', 'gdigrab', '-framerate', String(quality.fps), '-draw_mouse', '1', '-i', 'desktop']);
  const pre = !options.inputArgs && options.capture === 'ddagrab' ? 'hwdownload,format=bgra,' : '';
  return [...COMMON, ...input, '-an', '-vf', pre + fit, '-r', String(quality.fps), ...encoderArgs(options.encoder, quality), '-bsf:v', 'dump_extra=freq=keyframe', '-f', 'rtp', '-payload_type', String(VIDEO_PT), '-ssrc', String(VIDEO_SSRC), '-flush_packets', '1', `rtp://127.0.0.1:${options.port}?pkt_size=1200`];
}

export function buildAudioArgs(options: { audioDevice: string | null; port: number; inputArgs?: string[] }): string[] | null {
  const input = options.inputArgs ?? (options.audioDevice ? ['-f', 'dshow', '-audio_buffer_size', '50', '-i', `audio=${options.audioDevice}`] : null);
  if (!input) return null;
  return [...COMMON, '-fflags', 'nobuffer', ...input, '-vn', '-c:a', 'libopus', '-b:a', '96k', '-application', 'lowdelay', '-frame_duration', '10', '-ar', '48000', '-ac', '2', '-f', 'rtp', '-payload_type', String(AUDIO_PT), '-ssrc', String(AUDIO_SSRC), '-flush_packets', '1', `rtp://127.0.0.1:${options.port}?pkt_size=1200`];
}

export function parseDshowAudioDevices(stderr: string): string[] {
  const out: string[] = [];
  let inAudio = false;
  for (const line of stderr.split(/\r?\n/)) {
    if (/DirectShow audio devices/i.test(line)) { inAudio = true; continue; }
    if (/DirectShow video devices/i.test(line)) { inAudio = false; continue; }
    const match = /"([^"]+)"/.exec(line);
    if (!match || /alternative name/i.test(line)) continue;
    if (/\(audio\)/i.test(line) || (inAudio && !/\(video\)/i.test(line))) out.push(match[1]!);
  }
  return [...new Set(out)];
}


export async function hasFilter(ffmpegPath: string, filterName: string, spawnFn: typeof spawn = spawn): Promise<boolean> {
  return new Promise(resolve => {
    let child: ChildProcess;
    let output = '';
    try { child = spawnFn(ffmpegPath, ['-hide_banner', '-filters'], { stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true }); }
    catch { resolve(false); return; }
    const timer = setTimeout(() => { try { child.kill(); } catch {} resolve(new RegExp(`\\s${filterName}\\s`).test(output)); }, 8000);
    child.stdout?.on('data', chunk => { output = (output + chunk.toString()).slice(-200000); });
    child.once('error', () => { clearTimeout(timer); resolve(false); });
    child.once('exit', () => { clearTimeout(timer); resolve(new RegExp(`\\s${filterName}\\s`).test(output)); });
  });
}

export async function probeEncoder(ffmpegPath: string, encoder: VideoEncoder, spawnFn: typeof spawn = spawn): Promise<boolean> {
  return new Promise(resolve => {
    let child: ChildProcess;
    try {
      child = spawnFn(ffmpegPath, [...COMMON, '-f', 'lavfi', '-i', 'color=c=black:s=320x180:r=15', '-frames:v', '2', '-c:v', encoderCodec(encoder), '-f', 'null', '-'], { stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true });
    } catch { resolve(false); return; }
    const timer = setTimeout(() => { try { child.kill(); } catch {} resolve(false); }, 10000);
    child.once('error', () => { clearTimeout(timer); resolve(false); });
    child.once('exit', code => { clearTimeout(timer); resolve(code === 0); });
  });
}

export async function pickEncoder(ffmpegPath: string, requested: 'auto' | VideoEncoder, spawnFn: typeof spawn = spawn): Promise<VideoEncoder | null> {
  const order: VideoEncoder[] = requested === 'auto' ? ['nvenc', 'qsv', 'amf', 'x264'] : [requested, 'x264'];
  for (const encoder of [...new Set(order)]) if (await probeEncoder(ffmpegPath, encoder, spawnFn)) return encoder;
  return null;
}
