// NEXORA ORBIT core library, embedded in the host from NEXORA-ORBIT-CLI v2.2.0 (zero dependencies).
// Only change from the CLI original: downloadImage() is exported so the host can fetch screenshots.
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';

const TIMEOUT_MS = 10_000;
const USER_AGENT = 'Mozilla/5.0 (compatible; NEXORA-ORBIT-CLI/2.0)';
const IMAGE_TIMEOUT_MS = 30_000;
const MAX_IMAGE_BYTES = 25 * 1024 * 1024;

/* ------------------------------------------------------------------ */
/* HTTP                                                                */
/* ------------------------------------------------------------------ */

export class UpstreamError extends Error {
  constructor(message, status) {
    super(message);
    this.name = 'UpstreamError';
    this.status = status;
  }
}

async function http(url, init = {}) {
  const { timeoutMs = TIMEOUT_MS, ...fetchInit } = init;
  let lastError = new UpstreamError('unreachable');
  for (let attempt = 0; attempt < 2; attempt += 1) {
    let res;
    try {
      res = await fetch(String(url), {
        ...fetchInit,
        signal: AbortSignal.timeout(timeoutMs),
        headers: {
          'user-agent': USER_AGENT,
          accept: 'application/json, text/html;q=0.9,*/*;q=0.5',
          ...(fetchInit.headers ?? {}),
        },
      });
    } catch (err) {
      const msg = err instanceof Error ? `${err.name} ${err.message}` : String(err);
      lastError = new UpstreamError(/timeout|abort/i.test(msg) ? 'timeout' : 'unreachable');
      continue; // one retry for network-level failures
    }
    if (res.status >= 500 && attempt === 0) {
      lastError = new UpstreamError(`HTTP ${res.status}`, res.status);
      continue; // one retry for server errors
    }
    if (!res.ok) throw new UpstreamError(`HTTP ${res.status}`, res.status);
    return res;
  }
  throw lastError;
}

async function httpJson(url, init) {
  const res = await http(url, init);
  try {
    return await res.json();
  } catch {
    throw new UpstreamError('invalid JSON');
  }
}

async function httpText(url) {
  return (await http(url)).text();
}

/** Turn any error into a status + human message (never leaks stack traces). */
export function describeError(err) {
  if (!(err instanceof UpstreamError)) return { status: 'error', message: 'Unexpected error while reading this source.' };
  if (err.message === 'timeout') return { status: 'timeout', message: `No answer within ${TIMEOUT_MS / 1000}s.` };
  if (err.message === 'unreachable') return { status: 'error', message: 'Could not reach this source (internet, firewall or antivirus?).' };
  if ([401, 403, 429].includes(err.status ?? 0)) return { status: 'blocked', message: `Source refused the request (HTTP ${err.status}).` };
  if (err.status === 404) return { status: 'error', message: 'Source returned "not found" (HTTP 404).' };
  return { status: 'error', message: `Source error (${err.message}).` };
}

/* ------------------------------------------------------------------ */
/* Text helpers                                                        */
/* ------------------------------------------------------------------ */

export function text(value) {
  return typeof value === 'string' ? value.trim() : '';
}

export function normalizeKey(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

function safeCodePoint(n) {
  try {
    return String.fromCodePoint(n);
  } catch {
    return '';
  }
}

export function htmlToText(value) {
  return text(value)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(?:p|div|li|h[1-6])\s*>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&#x([0-9a-f]+);/gi, (_m, h) => safeCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_m, d) => safeCodePoint(Number(d)))
    .replace(/&nbsp;/gi, ' ')
    .replace(/&quot;/gi, '"')
    .replace(/&apos;/gi, "'")
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&amp;/gi, '&') // must be last, otherwise "&amp;lt;" decodes twice
    .replace(/\r/g, '')
    .replace(/[ \t]+/g, ' ')
    .replace(/ *\n */g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function numberOrNull(value) {
  if (value === null || value === undefined || value === '') return null;
  const n = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(n) ? n : null;
}

function names(value) {
  if (!Array.isArray(value)) return [];
  return value
    .map((item) => (typeof item === 'string' ? item.trim() : text(item?.name ?? item?.description)))
    .filter(Boolean);
}

function httpsUrl(value) {
  const v = text(value);
  if (!v) return null;
  if (v.startsWith('//')) return `https:${v}`;
  return /^https?:\/\//i.test(v) ? v : null;
}

/* ------------------------------------------------------------------ */
/* Query expansion + scoring                                           */
/* ------------------------------------------------------------------ */

const DEFAULT_ALIASES = {
  cod4mw: 'Call of Duty 4: Modern Warfare',
  cod4: 'Call of Duty 4: Modern Warfare',
  rdr2: 'Red Dead Redemption 2',
  gta4: 'Grand Theft Auto IV',
  gta5: 'Grand Theft Auto V',
  gtav: 'Grand Theft Auto V',
  ac4: "Assassin's Creed IV: Black Flag",
  acblackflag: "Assassin's Creed IV: Black Flag",
  cp2077: 'Cyberpunk 2077',
  witcher3: 'The Witcher 3: Wild Hunt',
  cs2: 'Counter-Strike 2',
  csgo: 'Counter-Strike: Global Offensive',
  tf2: 'Team Fortress 2',
  l4d2: 'Left 4 Dead 2',
  hl2: 'Half-Life 2',
  bg3: "Baldur's Gate 3",
  dos2: 'Divinity: Original Sin 2',
  pubg: 'PUBG: BATTLEGROUNDS',
};
let aliases = { ...DEFAULT_ALIASES };

/** Add/override shortcuts, e.g. { "mw2": "Call of Duty: Modern Warfare II" }. Keys starting with _ are ignored. */
export function setAliases(extra) {
  for (const [key, value] of Object.entries(extra ?? {})) {
    if (key.startsWith('_') || typeof value !== 'string' || !value.trim()) continue;
    const k = normalizeKey(key).replace(/\s/g, '');
    if (k) aliases[k] = value.trim();
  }
}

export function expandGameQuery(query) {
  const key = normalizeKey(query).replace(/\s/g, '');
  const expansion = aliases[key];
  return expansion && normalizeKey(expansion) !== normalizeKey(query) ? [query, expansion] : [query];
}

/** Extra queries to try when nothing matches well (typos): drop last word, short prefixes of the first word. */
export function typoVariants(query) {
  const full = normalizeKey(query);
  const words = full.split(' ').filter(Boolean);
  const out = new Set();
  if (words.length > 1) out.add(words.slice(0, -1).join(' '));
  const first = words[0] ?? '';
  if (first.length >= 5) {
    out.add(first.slice(0, 3));
    out.add(first.slice(0, 4));
  }
  out.delete(full);
  return [...out].filter((v) => v.length >= 3);
}

function levenshteinSimilarity(a, b) {
  if (!a || !b) return 0;
  const prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i += 1) {
    let diagonal = prev[0];
    prev[0] = i;
    for (let j = 1; j <= b.length; j += 1) {
      const above = prev[j];
      prev[j] = Math.min(prev[j] + 1, prev[j - 1] + 1, diagonal + (a[i - 1] === b[j - 1] ? 0 : 1));
      diagonal = above;
    }
  }
  return 1 - prev[b.length] / Math.max(a.length, b.length);
}

const ARTICLE = /^(the|a|an) /;

export function scoreTitle(query, title) {
  const q = normalizeKey(query);
  const t = normalizeKey(title);
  if (!q || !t) return 0;
  if (q === t) return 1;
  if (t.includes(q) || q.includes(t)) return 0.86;
  const titleTokens = new Set(t.split(' '));
  const overlap = q.split(' ').filter((tok) => titleTokens.has(tok)).length / Math.max(q.split(' ').length, 1);
  const similarity = levenshteinSimilarity(q.replace(/\s/g, ''), t.replace(/\s/g, ''));
  let score = Math.min(0.84, overlap * 0.62 + similarity * 0.38);

  // Typo tolerance: compare the query with the opening words of the title ("wicher 3" ~ "The Witcher 3: Wild Hunt").
  const qWords = q.replace(ARTICLE, '').split(' ');
  const tWords = t.replace(ARTICLE, '').split(' ');
  const qCompact = qWords.join('');
  for (const k of [qWords.length, qWords.length + 1]) {
    if (k > tWords.length) continue;
    const sim = levenshteinSimilarity(qCompact, tWords.slice(0, k).join(''));
    if (sim >= 0.75) score = Math.max(score, Math.min(0.88, sim * 0.95));
  }
  return score;
}

function bestScore(queries, title) {
  return Math.max(...queries.map((q) => scoreTitle(q, title)));
}

/* ------------------------------------------------------------------ */
/* Providers                                                           */
/* ------------------------------------------------------------------ */

function candidate(provider, providerId, title, sourceUrl, cover, releaseDate, platforms, genres, queries) {
  return {
    id: `${provider}:${providerId}`,
    provider,
    providerId: String(providerId),
    title,
    sourceUrl,
    coverImageUrl: cover,
    releaseDate,
    platforms,
    genres,
    matchScore: bestScore(queries, title),
  };
}

function platformList(obj) {
  if (!obj || typeof obj !== 'object') return [];
  const map = { windows: 'Windows', mac: 'macOS', linux: 'Linux' };
  return Object.entries(map)
    .filter(([key]) => obj[key] === true || obj[key.charAt(0).toUpperCase() + key.slice(1)] === true)
    .map(([, label]) => label);
}

async function steamSearch(query, limit) {
  const url = new URL('https://store.steampowered.com/api/storesearch/');
  url.searchParams.set('term', query);
  url.searchParams.set('cc', 'us');
  url.searchParams.set('l', 'en');
  const json = await httpJson(url);
  return (json.items ?? []).slice(0, limit).flatMap((item) => {
    const id = item.id == null ? '' : String(item.id);
    const title = text(item.name);
    if (!id || !title) return [];
    return [
      candidate('steam', id, title, `https://store.steampowered.com/app/${id}/`,
        `https://cdn.akamai.steamstatic.com/steam/apps/${id}/header.jpg`, null, platformList(item.platforms), [], [query]),
    ];
  });
}

async function gogRawSearch(query, limit) {
  const url = new URL('https://embed.gog.com/games/ajax/filtered');
  url.searchParams.set('mediaType', 'game');
  url.searchParams.set('search', query);
  const json = await httpJson(url);
  return (Array.isArray(json.products) ? json.products : []).slice(0, limit);
}

async function gogSearch(query, limit) {
  const products = await gogRawSearch(query, limit);
  return products.flatMap((p) => {
    const id = text(String(p.id ?? ''));
    const title = text(p.title);
    if (!id || !title) return [];
    const slug = text(p.slug) || text(p.url).replace(/^.*\/game\//, '');
    const image = text(p.image);
    const cover = image ? (image.startsWith('//') ? `https:${image}.jpg` : image.startsWith('http') ? image : null) : null;
    return [
      candidate('gog', id, title, slug ? `https://www.gog.com/game/${slug}` : null, cover, null,
        platformList(p.worksOn), names(p.genres), [query]),
    ];
  });
}

async function egdataRawSearch(query, limit) {
  const json = await httpJson('https://api.egdata.app/search/v2/search', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ title: query, limit }),
  });
  const hits = Array.isArray(json) ? json : (json.hits ?? json.results ?? json.offers ?? []);
  return hits.filter((h) => h && typeof h === 'object' && !Array.isArray(h));
}

async function egdataSearch(query, limit) {
  const hits = await egdataRawSearch(query, limit);
  return hits.slice(0, limit).flatMap((hit) => {
    const id = text(String(hit.id ?? hit.offerId ?? hit.offer_id ?? ''));
    const title = text(hit.title ?? hit.name);
    if (!title) return [];
    const images = Array.isArray(hit.keyImages) ? hit.keyImages : [];
    const cover = httpsUrl(hit.coverImage ?? hit.imageUrl) ?? httpsUrl(images.find((i) => /tall|wide|thumbnail/i.test(text(i?.type)))?.url);
    return [
      candidate('egdata', id || normalizeKey(title).replace(/\s/g, '-'), title,
        id ? `https://egdata.app/offers/${encodeURIComponent(id)}` : null, cover,
        text(hit.releaseDate ?? hit.effectiveDate) || null, names(hit.platforms), names(hit.genres ?? hit.tags), [query]),
    ];
  });
}

async function itchSearch(query, limit) {
  const html = await httpText(`https://itchdb.info/search?q=${encodeURIComponent(query)}`);
  const results = [];
  const seen = new Set();
  const pattern = /<a[^>]+href=["'](https?:\/\/[a-z0-9-]+\.itch\.io\/[^"'#?]+|\/(?:game|games)\/[^"'#?]+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  for (let m = pattern.exec(html); m && results.length < limit; m = pattern.exec(html)) {
    const title = htmlToText(m[2]);
    if (title.length < 2 || seen.has(m[1])) continue;
    seen.add(m[1]);
    const url = m[1].startsWith('/') ? `https://itchdb.info${m[1]}` : m[1];
    results.push(candidate('itchdb', m[1], title, url, null, null, [], [], [query]));
  }
  return results;
}

async function rawgSearch(query, limit) {
  const key = process.env.RAWG_API_KEY;
  const url = new URL('https://api.rawg.io/api/games');
  url.searchParams.set('search', query);
  url.searchParams.set('page_size', String(limit));
  url.searchParams.set('key', key);
  const json = await httpJson(url);
  return (json.results ?? []).slice(0, limit).flatMap((g) => {
    const id = g.id == null ? '' : String(g.id);
    const title = text(g.name);
    if (!id || !title) return [];
    return [
      candidate('rawg', id, title, g.slug ? `https://rawg.io/games/${g.slug}` : null, httpsUrl(g.background_image),
        text(g.released) || null, (g.platforms ?? []).map((p) => text(p.platform?.name)).filter(Boolean), names(g.genres), [query]),
    ];
  });
}

export const PROVIDERS = [
  { id: 'steam', label: 'Steam Store', search: steamSearch },
  { id: 'gog', label: 'GOG', search: gogSearch },
  { id: 'egdata', label: 'EGData (Epic)', search: egdataSearch, note: 'community API, best-effort' },
  { id: 'itchdb', label: 'itchDB', search: itchSearch, note: 'HTML scraping, best-effort' },
  { id: 'rawg', label: 'RAWG', search: rawgSearch, needsKey: 'RAWG_API_KEY' },
];

async function runProvider(provider, queries, limit) {
  const base = { provider: provider.id, label: provider.label, itemCount: 0, queryUsed: queries.join(' | ') };
  if (provider.needsKey && !process.env[provider.needsKey]) {
    return { games: [], status: { ...base, status: 'needs_config', message: `Optional. Set ${provider.needsKey} to enable.` } };
  }
  const games = [];
  const errors = [];
  let successes = 0;
  for (const q of queries) {
    try {
      games.push(...(await provider.search(q, limit)));
      successes += 1;
    } catch (err) {
      errors.push(describeError(err));
    }
  }
  const unique = [...new Map(games.map((g) => [`${g.providerId}`, g])).values()];
  if (successes === 0) return { games: [], status: { ...base, status: errors[0]?.status ?? 'error', message: errors[0]?.message ?? 'Failed.' } };
  if (errors.length > 0) {
    return { games: unique, status: { ...base, status: 'partial', itemCount: unique.length, message: `Some lookups failed: ${errors[0].message}` } };
  }
  return {
    games: unique,
    status: { ...base, status: 'ok', itemCount: unique.length, message: unique.length ? null : 'No matching games returned.' },
  };
}

/* ------------------------------------------------------------------ */
/* Search                                                              */
/* ------------------------------------------------------------------ */

export function validateQuery(raw) {
  const q = String(raw ?? '').replace(/\s+/g, ' ').trim();
  if (!q) throw new Error('Please type a game name.');
  if (q.length > 120) throw new Error('Game name is too long (max 120 characters).');
  return q;
}

const PROVIDER_PRIORITY = ['steam', 'gog', 'egdata', 'rawg', 'itchdb'];

/** One row per game: the same title found on several stores is merged (primary store + "alsoOn"). */
export function groupGames(games) {
  const groups = new Map();
  for (const g of games) {
    const key = normalizeKey(g.title);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(g);
  }
  const rank = (g) => {
    const i = PROVIDER_PRIORITY.indexOf(g.provider);
    return i === -1 ? 99 : i;
  };
  return [...groups.values()].map((members) => {
    const top = Math.max(...members.map((m) => m.matchScore));
    const sorted = [...members].sort((a, b) => rank(a) - rank(b));
    const primary = sorted.find((m) => m.matchScore >= top - 0.02) ?? sorted[0];
    const others = sorted.filter((m) => m !== primary);
    return {
      ...primary,
      matchScore: top,
      coverImageUrl: primary.coverImageUrl ?? others.find((o) => o.coverImageUrl)?.coverImageUrl ?? null,
      alsoOn: [...new Set(others.map((o) => o.provider))].filter((p) => p !== primary.provider),
      alternatives: others.map((o) => ({ id: o.id, provider: o.provider, providerId: o.providerId, sourceUrl: o.sourceUrl, coverImageUrl: o.coverImageUrl ?? null })),
    };
  });
}

const MIN_SHOWN_SCORE = 0.35;
const GOOD_ENOUGH = 0.6;

export async function searchGames(rawQuery, { limit = 5, fuzzy = true } = {}) {
  const query = validateQuery(rawQuery);
  const queries = expandGameQuery(query);
  const runs = await Promise.all(PROVIDERS.map((p) => runProvider(p, queries, limit)));
  let games = runs.flatMap((r) => r.games);

  // Nothing matches well -> probably a typo. Try shorter variants on the sources that are working,
  // then re-score everything against what the user actually typed.
  let usedFuzzy = false;
  const best = Math.max(0, ...games.map((g) => g.matchScore));
  if (fuzzy && best < GOOD_ENOUGH) {
    const variants = typoVariants(query);
    const usable = PROVIDERS.filter((p, i) => p.id !== 'itchdb' && ['ok', 'partial'].includes(runs[i].status.status));
    if (variants.length && usable.length) {
      usedFuzzy = true;
      const extra = await Promise.all(usable.map((p) => runProvider(p, variants, 10)));
      for (const r of extra) for (const g of r.games) games.push({ ...g, matchScore: bestScore(queries, g.title) });
    }
  }

  games = groupGames([...new Map(games.map((g) => [g.id, g])).values()]);
  const hiddenLowMatches = games.filter((g) => g.matchScore < MIN_SHOWN_SCORE).length;
  games = games
    .filter((g) => g.matchScore >= MIN_SHOWN_SCORE)
    .sort((a, b) => b.matchScore - a.matchScore || a.title.localeCompare(b.title) || a.provider.localeCompare(b.provider));
  return {
    query,
    expandedQueries: queries.slice(1),
    fuzzy: usedFuzzy,
    hiddenLowMatches,
    providers: runs.map((r) => r.status),
    games,
  };
}

/* ------------------------------------------------------------------ */
/* Details                                                             */
/* ------------------------------------------------------------------ */

async function bestFrom(queries, lookup, idOf, titleOf, minScore) {
  let best = null;
  for (const q of queries) {
    for (const item of await lookup(q)) {
      const title = titleOf(item);
      if (!title || !idOf(item)) continue;
      const score = bestScore(queries, title);
      if (!best || score > best.score) best = { item, score };
    }
  }
  return best && best.score >= minScore ? best.item : null;
}

async function fetchSteam(appId) {
  const url = new URL('https://store.steampowered.com/api/appdetails');
  url.searchParams.set('appids', appId);
  url.searchParams.set('cc', 'us');
  url.searchParams.set('l', 'en');
  const json = await httpJson(url);
  const entry = json?.[appId];
  return entry?.success ? (entry.data ?? null) : null;
}

async function fetchSteamReviews(appId) {
  const url = new URL(`https://store.steampowered.com/appreviews/${encodeURIComponent(appId)}`);
  url.searchParams.set('json', '1');
  url.searchParams.set('language', 'all');
  url.searchParams.set('purchase_type', 'all');
  url.searchParams.set('review_type', 'all');
  url.searchParams.set('filter', 'recent');
  url.searchParams.set('num_per_page', '5');
  const json = await httpJson(url);
  const s = json.query_summary ?? {};
  const positive = numberOrNull(s.total_positive) ?? 0;
  const negative = numberOrNull(s.total_negative) ?? 0;
  const total = numberOrNull(s.total_reviews) ?? positive + negative;
  return {
    source: 'Steam Community Reviews',
    label: text(s.review_score_desc) || null,
    scorePercent: positive + negative > 0 ? Math.round((positive / (positive + negative)) * 1000) / 10 : null,
    positive,
    negative,
    total,
    url: `https://store.steampowered.com/app/${appId}/`,
    recent: (json.reviews ?? [])
      .slice(0, 5)
      .map((r) => {
        const minutes = numberOrNull(r.author?.playtime_forever);
        return {
          recommended: Boolean(r.voted_up),
          text: text(r.review).slice(0, 600),
          hoursPlayed: minutes == null ? null : Math.floor(minutes / 60),
        };
      })
      .filter((r) => r.text),
  };
}

async function fetchGogProduct(id) {
  const url = new URL(`https://api.gog.com/products/${encodeURIComponent(id)}`);
  url.searchParams.set('expand', 'description,screenshots');
  url.searchParams.set('locale', 'en-US');
  return httpJson(url);
}

function gogDescriptionText(description) {
  // GOG returns an object { lead, full, whats_cool_about_it } - older code assumed a string.
  if (typeof description === 'string') return htmlToText(description);
  if (description && typeof description === 'object') {
    return [description.lead, description.full].map(htmlToText).filter(Boolean).join('\n\n');
  }
  return '';
}

function gogScreenshots(list) {
  const out = [];
  for (const item of Array.isArray(list) ? list : []) {
    const formatted = Array.isArray(item?.formatted_images) ? item.formatted_images : [];
    const url =
      httpsUrl(formatted[formatted.length - 1]?.formatted_image_url) ??
      httpsUrl(formatted[0]?.formatted_image_url) ??
      httpsUrl(item?.image ?? item?.url ?? item?.src);
    if (url) out.push({ thumbnailUrl: url, imageUrl: url });
    if (out.length >= 12) break;
  }
  return out;
}

async function fetchRawg(title, rawgId) {
  const key = process.env.RAWG_API_KEY;
  let id = rawgId;
  if (!id) {
    const url = new URL('https://api.rawg.io/api/games');
    url.searchParams.set('search', title);
    url.searchParams.set('page_size', '5');
    url.searchParams.set('key', key);
    const json = await httpJson(url);
    const best = (json.results ?? [])
      .filter((g) => g.id != null && text(g.name))
      .map((g) => ({ g, score: scoreTitle(title, text(g.name)) }))
      .sort((a, b) => b.score - a.score)[0];
    if (!best || best.score < 0.45) return null;
    id = String(best.g.id);
  }
  const url = new URL(`https://api.rawg.io/api/games/${encodeURIComponent(id)}`);
  url.searchParams.set('key', key);
  return httpJson(url);
}

/* ------------------------------------------------------------------ */
/* Extra cover-art sources (optional, free keys)                       */
/* ------------------------------------------------------------------ */

// A wrong cover is worse than no cover, so these sources must match the title (almost) exactly:
// "Hades" vs "Hades II" and "Portal" vs "Portal 2" both score 0.86 and must NOT be accepted.
const COVER_MATCH_MIN = 0.97;

async function sgdbJson(pathname, params = {}) {
  const url = new URL(`https://www.steamgriddb.com/api/v2${pathname}`);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  const json = await httpJson(url, { headers: { authorization: `Bearer ${process.env.STEAMGRIDDB_API_KEY}` } });
  if (json?.success === false) throw new UpstreamError(text(json.errors?.[0]) || 'SteamGridDB refused the request');
  return json;
}

/**
 * SteamGridDB: community box art (works for non-Steam games too). Needs STEAMGRIDDB_API_KEY.
 * Returns up to 3 portrait cover URLs, biggest first. [] when the game has none.
 */
export async function fetchSteamGridDbCovers(title, steamAppId = null) {
  try {
    let gridsPath;
    if (steamAppId) {
      gridsPath = `/grids/steam/${encodeURIComponent(String(steamAppId))}`;
    } else {
      const found = await sgdbJson(`/search/autocomplete/${encodeURIComponent(title)}`);
      const best = (Array.isArray(found.data) ? found.data : [])
        .filter((g) => g?.id != null && text(g.name))
        .map((g, index) => ({ g, index, score: scoreTitle(title, text(g.name)) }))
        .sort((a, b) => b.score - a.score || a.index - b.index)[0];
      if (!best || best.score < COVER_MATCH_MIN) return [];
      gridsPath = `/grids/game/${encodeURIComponent(String(best.g.id))}`;
    }
    const grids = await sgdbJson(gridsPath, { types: 'static' });
    return (Array.isArray(grids.data) ? grids.data : [])
      .map((g) => ({ url: httpsUrl(g?.url), width: numberOrNull(g?.width) ?? 0, height: numberOrNull(g?.height) ?? 0, score: numberOrNull(g?.score) ?? 0 }))
      .filter((g) => g.url && g.height > g.width)
      .sort((a, b) => b.width * b.height - a.width * a.height || b.score - a.score)
      .slice(0, 3)
      .map((g) => g.url);
  } catch (err) {
    if (err instanceof UpstreamError && err.status === 404) return []; // game not known to SteamGridDB
    throw err;
  }
}

let igdbToken = null;
async function igdbAccessToken() {
  if (igdbToken && igdbToken.expires > Date.now() + 60_000) return igdbToken.value;
  const url = new URL('https://id.twitch.tv/oauth2/token');
  url.searchParams.set('client_id', process.env.IGDB_CLIENT_ID);
  url.searchParams.set('client_secret', process.env.IGDB_CLIENT_SECRET);
  url.searchParams.set('grant_type', 'client_credentials');
  const json = await httpJson(url, { method: 'POST' });
  const value = text(json?.access_token);
  if (!value) throw new UpstreamError('Twitch did not return an access token');
  igdbToken = { value, expires: Date.now() + (numberOrNull(json.expires_in) ?? 3600) * 1000 };
  return value;
}

/**
 * IGDB (Twitch): very wide game coverage, covers served at original upload size.
 * Needs IGDB_CLIENT_ID + IGDB_CLIENT_SECRET. Returns [] when no closely matching game has a cover.
 */
export async function fetchIgdbCovers(title) {
  const token = await igdbAccessToken();
  const safe = title.replace(/["\\;]/g, ' ');
  const json = await httpJson('https://api.igdb.com/v4/games', {
    method: 'POST',
    headers: { 'client-id': process.env.IGDB_CLIENT_ID, authorization: `Bearer ${token}`, 'content-type': 'text/plain' },
    body: `search "${safe}"; fields name,cover.image_id,cover.width,cover.height; where cover != null; limit 8;`,
  });
  const best = (Array.isArray(json) ? json : [])
    .filter((g) => text(g?.name) && text(g?.cover?.image_id))
    .map((g, index) => ({ g, index, score: scoreTitle(title, text(g.name)) }))
    .sort((a, b) => b.score - a.score || a.index - b.index)[0];
  if (!best || best.score < COVER_MATCH_MIN) return [];
  return [`https://images.igdb.com/igdb/image/upload/t_original/${encodeURIComponent(text(best.g.cover.image_id))}.jpg`];
}

/** Used by the "health" command: a live test call for each optional cover source. */
export async function checkCoverSources() {
  const probe = async (label, configured, run) => {
    if (!configured) return { label, status: 'needs_config', itemCount: 0, message: 'Optional. Key not set (see README).' };
    try {
      const urls = await run();
      return { label, status: 'ok', itemCount: urls.length, message: urls.length ? null : 'Answered, but returned no cover for the test game.' };
    } catch (err) {
      return { label, status: 'error', itemCount: 0, message: describeError(err).message };
    }
  };
  return [
    await probe('SteamGridDB', Boolean(process.env.STEAMGRIDDB_API_KEY), () => fetchSteamGridDbCovers('Portal 2')),
    await probe('IGDB', Boolean(process.env.IGDB_CLIENT_ID && process.env.IGDB_CLIENT_SECRET), () => fetchIgdbCovers('Portal 2')),
  ];
}

/** first non-empty value wins; remembers which source it came from */
function pick(sources, field, candidates) {
  for (const [value, source] of candidates) {
    const has = Array.isArray(value) ? value.length > 0 : value !== null && value !== undefined && String(value).trim() !== '';
    if (has) {
      sources[field] = source;
      return value;
    }
  }
  return Array.isArray(candidates[0]?.[0]) ? [] : null;
}

/** Epic (EGData) offers list several key images; the "Tall" ones are the portrait box art. */
export function epicCoverUrls(hit) {
  if (!hit || typeof hit !== 'object') return [];
  const images = Array.isArray(hit.keyImages) ? hit.keyImages : [];
  const tall = images.filter((i) => /tall/i.test(text(i?.type))).map((i) => httpsUrl(i?.url));
  return [...tall, httpsUrl(hit.coverImage ?? hit.imageUrl)].filter(Boolean);
}

export async function getGameDetails(rawTitle, { steamAppId, extraCoverUrls = [] } = {}) {
  const title = validateQuery(rawTitle);
  const queries = expandGameQuery(title);
  const notices = [];
  const attempt = async (label, fn) => {
    try {
      return await fn();
    } catch (err) {
      notices.push(`${label}: ${describeError(err).message}`);
      return null;
    }
  };

  // ---- Steam
  let appId = steamAppId ? String(steamAppId) : null;
  if (!appId) {
    const found = await attempt('Steam search', () =>
      bestFrom(queries, (q) => steamSearch(q, 8), (c) => c.providerId, (c) => c.title, 0.45));
    appId = found?.providerId ?? null;
    if (!found && !notices.some((n) => n.startsWith('Steam search'))) notices.push('No Steam Store listing matched this title.');
  }
  const steam = appId ? await attempt('Steam details', () => fetchSteam(appId)) : null;
  if (appId && !steam && !notices.some((n) => n.startsWith('Steam details'))) notices.push('Steam did not return a detail record for this app.');
  const reviews = steam ? await attempt('Steam reviews', () => fetchSteamReviews(appId)) : null;

  // ---- GOG, EGData, RAWG (independent, run together)
  const [gogProduct, egdata, rawg] = await Promise.all([
    attempt('GOG', async () => {
      const hit = await bestFrom(queries, (q) => gogRawSearch(q, 10), (p) => /^\d{1,20}$/.test(String(p.id ?? '')), (p) => text(p.title), 0.48);
      return hit ? fetchGogProduct(String(hit.id)).then((d) => ({ ...d, _searchHit: hit })) : null;
    }),
    attempt('EGData', () => bestFrom(queries, (q) => egdataRawSearch(q, 10), (r) => text(String(r.id ?? r.offerId ?? r.offer_id ?? '')) || text(r.title ?? r.name), (r) => text(r.title ?? r.name), 0.48)),
    process.env.RAWG_API_KEY ? attempt('RAWG', () => fetchRawg(title)) : Promise.resolve(null),
  ]);
  if (!process.env.RAWG_API_KEY) notices.push('RAWG is optional and not configured (set RAWG_API_KEY to enable).');

  if (!steam && !gogProduct && !egdata && !rawg) {
    return { record: null, notices };
  }

  // ---- Extra cover-art sources (optional, free keys). They only add image candidates, never text data.
  const coverTitle = (text(steam?.name) || text(gogProduct?.title) || text(rawg?.name) || title).replace(/[™®©]/g, '').replace(/\s+/g, ' ').trim();
  const sgdbOn = Boolean(process.env.STEAMGRIDDB_API_KEY);
  const igdbOn = Boolean(process.env.IGDB_CLIENT_ID && process.env.IGDB_CLIENT_SECRET);
  const [sgdbCovers, igdbCovers] = await Promise.all([
    sgdbOn ? attempt('SteamGridDB', () => fetchSteamGridDbCovers(coverTitle, steam ? appId : null)) : Promise.resolve(null),
    igdbOn ? attempt('IGDB', () => fetchIgdbCovers(coverTitle)) : Promise.resolve(null),
  ]);
  const unconfigured = [!sgdbOn && 'SteamGridDB', !igdbOn && 'IGDB'].filter(Boolean);
  if (unconfigured.length) notices.push(`Extra cover sources not configured (optional, free): ${unconfigured.join(', ')} - see README.`);
  if (sgdbCovers && sgdbCovers.length === 0) notices.push('SteamGridDB: no portrait cover found for this title.');
  if (igdbCovers && igdbCovers.length === 0) notices.push('IGDB: no closely matching game with a cover found.');

  // ---- Compute provider-specific values FIRST (the old server used some of these before declaring them)
  const sourcesMap = {};
  const steamUrl = appId && steam ? `https://store.steampowered.com/app/${appId}/` : null;
  const gogSlug = text(gogProduct?.slug) || text(gogProduct?._searchHit?.slug);
  const gogUrl = httpsUrl(gogProduct?.links?.product_card) ?? (gogSlug ? `https://www.gog.com/game/${gogSlug}` : null);
  const rawgUrl = rawg?.slug ? `https://rawg.io/games/${rawg.slug}` : null;
  const egId = egdata ? text(String(egdata.id ?? egdata.offerId ?? egdata.offer_id ?? '')) : '';
  const egUrl = egId ? `https://egdata.app/offers/${encodeURIComponent(egId)}` : null;

  const steamDesc = htmlToText(steam?.about_the_game);
  const gogDesc = gogDescriptionText(gogProduct?.description);
  const rawgDesc = htmlToText(rawg?.description_raw ?? rawg?.description);
  const gogImages = gogProduct?.images ?? {};
  const steamPlatforms = steam ? platformList(steam.platforms) : [];

  const screenshots = steam && Array.isArray(steam.screenshots)
    ? steam.screenshots.map((s) => ({ thumbnailUrl: text(s.path_thumbnail), imageUrl: text(s.path_full) })).filter((s) => s.imageUrl).slice(0, 12)
    : [];
  if (screenshots.length === 0) screenshots.push(...gogScreenshots(gogProduct?.screenshots));
  if (screenshots.length === 0 && rawg?.background_image) screenshots.push({ thumbnailUrl: rawg.background_image, imageUrl: rawg.background_image });
  if (screenshots.length) sourcesMap.screenshots = steam ? 'Steam Store' : gogProduct ? 'GOG' : 'RAWG';

  // Cover candidates. Order only breaks ties: at save time every candidate is downloaded, its REAL pixel
  // size is measured, and the biggest portrait cover wins (see downloadBestCover). Steam's own "header"
  // image is only ~460x215, so the 600x900 cover (and its 2x version, 1200x1800) come first.
  const steamCdn = appId && steam ? `https://cdn.akamai.steamstatic.com/steam/apps/${appId}` : null;
  const coverCandidates = [...new Set([
    ...(steamCdn ? [`${steamCdn}/library_600x900_2x.jpg`, `${steamCdn}/library_600x900.jpg`] : []),
    ...epicCoverUrls(egdata),
    ...(sgdbCovers ?? []),
    ...(igdbCovers ?? []),
    ...extraCoverUrls.map(httpsUrl),
    httpsUrl(gogImages.logo2x ?? gogImages.logo),
    httpsUrl(steam?.header_image),
    httpsUrl(rawg?.background_image),
  ].filter(Boolean))];
  const heroCandidates = [
    ...(steamCdn ? [`${steamCdn}/library_hero.jpg`] : []),
    httpsUrl(gogImages.background),
    httpsUrl(rawg?.background_image_additional),
    httpsUrl(rawg?.background_image),
  ].filter(Boolean);
  if (coverCandidates.length) sourcesMap.coverImage = steam ? 'Steam Store' : gogProduct ? 'GOG' : 'RAWG';

  const description = pick(sourcesMap, 'description', [[steamDesc, 'Steam Store'], [gogDesc, 'GOG'], [rawgDesc, 'RAWG']]);
  const shortDescription = pick(sourcesMap, 'shortDescription', [
    [htmlToText(steam?.short_description), 'Steam Store'],
    [(gogDesc || '').split('\n')[0].slice(0, 320), 'GOG'],
    [rawgDesc.slice(0, 320), 'RAWG'],
  ]);
  const priceRaw = steam?.is_free ? 'Free' : text(steam?.price_overview?.final_formatted);

  const record = {
    title: text(steam?.name) || text(gogProduct?.title) || text(rawg?.name) || title,
    searchedFor: title,
    steamAppId: steam ? appId : null,
    storeUrl: steamUrl ?? gogUrl ?? rawgUrl ?? egUrl,
    coverImageUrl: coverCandidates[0] ?? null,
    coverImageCandidates: coverCandidates,
    heroImageCandidates: heroCandidates,
    shortDescription,
    description,
    releaseDate: pick(sourcesMap, 'releaseDate', [
      [text(steam?.release_date?.date), 'Steam Store'],
      [text(rawg?.released), 'RAWG'],
      [text(gogProduct?.release_date).slice(0, 10), 'GOG'],
    ]),
    developers: pick(sourcesMap, 'developers', [[names(steam?.developers), 'Steam Store'], [names(rawg?.developers), 'RAWG'], [names(gogProduct?.developers), 'GOG']]),
    publishers: pick(sourcesMap, 'publishers', [[names(steam?.publishers), 'Steam Store'], [names(rawg?.publishers), 'RAWG'], [names(gogProduct?.publishers), 'GOG']]),
    genres: pick(sourcesMap, 'genres', [[names(steam?.genres), 'Steam Store'], [names(rawg?.genres), 'RAWG'], [names(gogProduct?.genres), 'GOG']]),
    categories: names(steam?.categories),
    platforms: pick(sourcesMap, 'platforms', [
      [steamPlatforms, 'Steam Store'],
      [(rawg?.platforms ?? []).map((p) => text(p.platform?.name)).filter(Boolean), 'RAWG'],
      [platformList(gogProduct?.content_system_compatibility), 'GOG'],
    ]),
    website: pick(sourcesMap, 'website', [[text(steam?.website), 'Steam Store'], [text(rawg?.website), 'RAWG'], [text(gogProduct?.links?.homepage ?? gogProduct?.official_website), 'GOG']]),
    metacriticScore: numberOrNull(steam?.metacritic?.score) ?? numberOrNull(rawg?.metacritic),
    price: pick(sourcesMap, 'price', [[priceRaw, 'Steam Store']]),
    screenshots,
    reviews,
    links: Object.fromEntries(Object.entries({ steam: steamUrl, gog: gogUrl, epic: egUrl, rawg: rawgUrl }).filter(([, v]) => v)),
    fieldSources: sourcesMap,
    fetchedAt: new Date().toISOString(),
  };
  return { record, notices };
}

/* ------------------------------------------------------------------ */
/* Output                                                              */
/* ------------------------------------------------------------------ */

export function safeFolderName(name) {
  let n = String(name ?? '')
    .normalize('NFKC')
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, ' ')
    .replace(/[™®©]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/[. ]+$/g, '')
    .slice(0, 80)
    .trim();
  if (!n) n = 'game';
  if (/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i.test(n)) n = `_${n}`;
  return n;
}

export function formatSummary(record, search, notices = []) {
  const L = [];
  const line = (label, value) => L.push(`${label.padEnd(14)}: ${value || '-'}`);
  L.push('='.repeat(64), record.title, '='.repeat(64));
  line('Release date', record.releaseDate);
  line('Developer', record.developers.join(', '));
  line('Publisher', record.publishers.join(', '));
  line('Genres', record.genres.join(', '));
  line('Platforms', record.platforms.join(', '));
  line('Price', record.price);
  line('Metacritic', record.metacriticScore == null ? '' : `${record.metacriticScore}/100`);
  if (record.reviews) {
    line('Reviews', `${record.reviews.label ?? 'n/a'} - ${record.reviews.scorePercent ?? '?'}% positive (${record.reviews.total.toLocaleString('en-US')} reviews)`);
  } else line('Reviews', '');
  line('Website', record.website);
  line('Store page', record.storeUrl);
  for (const [k, v] of Object.entries(record.links)) line(`  ${k}`, v);
  L.push('', 'DESCRIPTION', '-----------', record.shortDescription || '(none provided)');
  if (record.description && record.description !== record.shortDescription) L.push('', record.description.slice(0, 2500));
  if (record.reviews?.recent?.length) {
    L.push('', 'RECENT REVIEWS', '--------------');
    for (const r of record.reviews.recent) L.push(`[${r.recommended ? '+' : '-'}] ${r.text.replace(/\s+/g, ' ').slice(0, 220)}`);
  }
  if (record.savedCover) {
    const c = record.savedCover;
    L.push('', `Cover saved   : ${c.width && c.height ? `${c.width}x${c.height}` : 'size unknown'} ${c.orientation ?? ''} from ${c.source}`.replace(/ +/g, ' '));
  }
  L.push('', `Screenshots found: ${record.screenshots.length}`);
  const fs = Object.entries(record.fieldSources).map(([f, s]) => `${f} <- ${s}`);
  if (fs.length) L.push('', 'DATA SOURCES', '------------', ...fs);
  if (notices.length) L.push('', 'NOTICES', '-------', ...notices.map((n) => `* ${n}`));
  if (search) {
    L.push('', 'PROVIDER REPORT', '---------------');
    for (const p of search.providers) L.push(`${p.label.padEnd(16)} ${String(p.status).padEnd(13)} ${p.itemCount} item(s)${p.message ? '  - ' + p.message : ''}`);
  }
  L.push('', `Fetched: ${record.fetchedAt}`);
  return L.join('\n');
}

/* ------------------------------------------------------------------ */
/* Images                                                              */
/* ------------------------------------------------------------------ */

/**
 * Reads the real type and pixel size from the first bytes of an image (PNG, JPEG, WebP, GIF).
 * Returns null when the bytes are not a recognised image. No dependencies.
 */
export function readImageInfo(buf) {
  if (!buf || buf.length < 10) return null;
  // PNG
  if (buf.length >= 24 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) {
    return { ext: 'png', width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) };
  }
  // GIF
  if (buf.toString('latin1', 0, 3) === 'GIF') {
    return { ext: 'gif', width: buf.readUInt16LE(6), height: buf.readUInt16LE(8) };
  }
  // WebP
  if (buf.length >= 30 && buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WEBP') {
    const kind = buf.toString('latin1', 12, 16);
    if (kind === 'VP8X') return { ext: 'webp', width: 1 + buf.readUIntLE(24, 3), height: 1 + buf.readUIntLE(27, 3) };
    if (kind === 'VP8 ') return { ext: 'webp', width: buf.readUInt16LE(26) & 0x3fff, height: buf.readUInt16LE(28) & 0x3fff };
    if (kind === 'VP8L') {
      const bits = buf.readUInt32LE(21);
      return { ext: 'webp', width: 1 + (bits & 0x3fff), height: 1 + ((bits >> 14) & 0x3fff) };
    }
    return { ext: 'webp', width: 0, height: 0 };
  }
  // JPEG: walk the segments until a Start-Of-Frame marker
  if (buf[0] === 0xff && buf[1] === 0xd8) {
    let i = 2;
    while (i + 9 < buf.length) {
      if (buf[i] !== 0xff) { i += 1; continue; }
      const marker = buf[i + 1];
      if (marker === 0xff) { i += 1; continue; }
      if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { i += 2; continue; }
      const isSof = marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc;
      if (isSof) return { ext: 'jpg', height: buf.readUInt16BE(i + 5), width: buf.readUInt16BE(i + 7) };
      i += 2 + buf.readUInt16BE(i + 2);
    }
    return { ext: 'jpg', width: 0, height: 0 };
  }
  return null;
}

export async function downloadImage(url) {
  const res = await http(url, { headers: { accept: 'image/*,*/*;q=0.5' }, timeoutMs: IMAGE_TIMEOUT_MS });
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length < 4) throw new UpstreamError('empty image');
  if (buf.length > MAX_IMAGE_BYTES) throw new UpstreamError('image too large');
  const type = (res.headers.get('content-type') ?? '').toLowerCase();
  if (type && !type.startsWith('image/') && !type.includes('octet-stream')) throw new UpstreamError('not an image');
  const info = readImageInfo(buf);
  const ext = info?.ext ?? (type.includes('png') ? 'png' : type.includes('webp') ? 'webp' : type.includes('gif') ? 'gif' : 'jpg');
  return { buf, ext, url, width: info?.width ?? 0, height: info?.height ?? 0 };
}

/** Try each URL in order; return the first that downloads. */
async function downloadFirst(urls) {
  let last;
  for (const url of urls) {
    try {
      return await downloadImage(url);
    } catch (err) {
      last = err;
    }
  }
  throw last ?? new UpstreamError('no image url');
}

function sourceLabel(url) {
  const host = (() => { try { return new URL(url).hostname; } catch { return ''; } })();
  if (/steamgriddb/.test(host)) return 'SteamGridDB';
  if (/igdb/.test(host)) return 'IGDB';
  if (/steamstatic|steampowered/.test(host)) return 'Steam';
  if (/gog/.test(host)) return 'GOG';
  if (/epicgames|egdata|unrealengine/.test(host)) return 'Epic';
  if (/rawg/.test(host)) return 'RAWG';
  return host || 'unknown';
}

/**
 * Downloads EVERY cover candidate, measures the real pixel size and keeps the best one:
 *   1. portrait box art that is at least 600 px tall (a real "cover"), biggest first
 *   2. any other image of known size (landscape key art), biggest first
 *   3. images whose size could not be read, in the order listed
 * Nothing is upscaled or edited - the saved file is exactly what the source served.
 */
export async function downloadBestCover(urls) {
  const unique = [...new Set(urls.filter(Boolean))].slice(0, 10);
  if (unique.length === 0) throw new UpstreamError('no image url');
  const settled = await Promise.allSettled(unique.map((u) => downloadImage(u)));
  const got = settled.flatMap((r, index) => (r.status === 'fulfilled' ? [{ ...r.value, index }] : []));
  if (got.length === 0) {
    const firstError = settled.find((r) => r.status === 'rejected')?.reason;
    throw firstError ?? new UpstreamError('no image url');
  }
  const tier = (c) => (!c.width || !c.height ? 1 : c.height > c.width && c.height >= 600 ? 3 : 2);
  got.sort((a, b) => tier(b) - tier(a) || b.width * b.height - a.width * a.height || a.index - b.index);
  const best = got[0];
  const orientation = !best.width || !best.height ? '' : best.height > best.width ? 'portrait' : 'landscape';
  const fullQuality = orientation === 'portrait' ? best.height >= 900 : orientation === 'landscape' ? best.width >= 1280 : true;
  return {
    ...best,
    orientation,
    source: sourceLabel(best.url),
    fullQuality,
    tried: unique.length,
    downloaded: got.length,
  };
}

/** Saves everything into <resourcesDir>/<GameName>/ and returns what was written. */
export async function saveResult({ record, search, notices }, resourcesDir, { screenshots = 5 } = {}) {
  const folder = path.join(resourcesDir, safeFolderName(record.title));
  await mkdir(folder, { recursive: true });
  const written = [];
  const out = async (name, data) => {
    const file = path.join(folder, name);
    await writeFile(file, data);
    written.push(file);
  };

  // Images first, so the real cover size can be written into summary.txt / details.json.
  const imageNotes = [];
  let cover = null;
  const covers = record.coverImageCandidates?.length ? record.coverImageCandidates : record.coverImageUrl ? [record.coverImageUrl] : [];
  if (covers.length) {
    try {
      cover = await downloadBestCover(covers);
      await out(`cover.${cover.ext}`, cover.buf);
      if (!cover.fullQuality) {
        imageNotes.push(
          `cover is only ${cover.width}x${cover.height} (${cover.source}) - ${cover.downloaded} of ${cover.tried} cover sources answered and none had a larger image`,
        );
      }
    } catch (err) {
      imageNotes.push(`cover image not saved (${describeError(err).message})`);
    }
  }
  if (record.heroImageCandidates?.length) {
    try {
      const { buf, ext } = await downloadFirst(record.heroImageCandidates);
      await out(`banner.${ext}`, buf);
    } catch {
      /* banner is optional */
    }
  }
  const shots = (record.screenshots ?? []).slice(0, Math.max(0, screenshots));
  if (shots.length) {
    await mkdir(path.join(folder, 'screenshots'), { recursive: true });
    let failed = 0;
    for (const [i, shot] of shots.entries()) {
      try {
        const { buf, ext } = await downloadImage(shot.imageUrl);
        await out(path.join('screenshots', `${String(i + 1).padStart(2, '0')}.${ext}`), buf);
      } catch {
        failed += 1;
      }
    }
    if (failed) imageNotes.push(`${failed} of ${shots.length} screenshots could not be downloaded`);
  }

  const savedRecord = cover
    ? { ...record, savedCover: { file: `cover.${cover.ext}`, url: cover.url, width: cover.width, height: cover.height, orientation: cover.orientation, bytes: cover.buf.length, source: cover.source } }
    : record;
  await out('details.json', JSON.stringify({ ...savedRecord, notices }, null, 2));
  if (search) await out('search-results.json', JSON.stringify(search, null, 2));
  await out('summary.txt', formatSummary(savedRecord, search, notices).replace(/\n/g, '\r\n'));
  return {
    folder,
    written,
    imageNotes,
    cover: cover ? { file: `cover.${cover.ext}`, width: cover.width, height: cover.height, orientation: cover.orientation, source: cover.source, bytes: cover.buf.length, fullQuality: cover.fullQuality } : null,
  };
}
