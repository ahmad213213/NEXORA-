export type LifecyclePhase = 'starting' | 'running' | 'stopping' | 'stopped';

export class Lifecycle {
  private phase: LifecyclePhase = 'starting';
  private shutdownPromise: Promise<void> | null = null;

  get state(): LifecyclePhase {
    return this.phase;
  }

  markRunning(): void {
    if (this.phase !== 'starting') throw new Error(`Cannot enter running from ${this.phase}`);
    this.phase = 'running';
  }

  canAcceptWork(): boolean {
    return this.phase === 'running';
  }

  async shutdown(cleanup: () => Promise<void>): Promise<void> {
    if (this.shutdownPromise) return this.shutdownPromise;
    if (this.phase === 'stopped') return;
    this.phase = 'stopping';
    this.shutdownPromise = (async () => {
      try {
        await cleanup();
      } finally {
        this.phase = 'stopped';
      }
    })();
    return this.shutdownPromise;
  }
}
