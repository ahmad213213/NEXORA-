import { LayoutController } from './layout/layout-controller.js';
import { KeyMapStore } from './input/key-map-store.js';
import { KeyMapper } from './input/key-mapper.js';
import { InputManager } from './input/input-manager.js';
import { WindowsInputSink } from './input/windows-send-input.js';
import { VirtualGamepadSink, CompositeInputSink } from './input/virtual-gamepad.js';
import { LayoutStore } from './layout/layout-store.js';
import {
  app,
  BrowserWindow,
  dialog,
  protocol,
  ipcMain,
  session,
  screen,
  type IpcMainInvokeEvent
} from 'electron';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Lifecycle } from './lifecycle.js';
import { initLogger, log } from './logger.js';
import { DEFAULT_CONFIG, loadConfig, saveConfig, normalize, type HostConfig, mergeConfigPatch } from './config.js';
import { LibraryController } from './library-controller.js';
import { SteamStoreProvider } from './steam-provider.js';
import { OrbitSearchService, ORBIT_MAX_QUERY, loadDefaultOrbitApi } from './orbit/orbit-search.js';
import { loadOrbitAliases, loadOrbitKeys } from './orbit/orbit-keys.js';
import { readFile, access, stat, writeFile } from 'node:fs/promises';
import { checkUpdate, downloadAndStage, launchExternalUpdater, launchLocalUpdater, stageUpdaterScript, assertZipFile, isInsideFolder, loadUpdateSettings, saveUpdateSettings, isUpdateConfigured, validateManifest, verifyManifestSignature, compareVersions, type UpdateManifest } from './update/index.js';
import { createStatsReader } from './system-stats.js';
import { PairingStore, PinManager } from './networking/pairing.js';
import { loadOrCreateIdentity } from './networking/security.js';
import { AiPatcher } from './ai-patcher.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
protocol.registerSchemesAsPrivileged([{ scheme: 'nexora-cover', privileges: { secure: true, standard: true, supportFetchAPI: true } }]);

const readStats = createStatsReader();
const lifecycle = new Lifecycle();
let mainWindow: BrowserWindow | null = null;
let keyMapStore: KeyMapStore;
let keyMapper: KeyMapper;
let inputManager: InputManager | null = null;
let config: HostConfig = normalize(DEFAULT_CONFIG);
let configMutationQueue: Promise<unknown> = Promise.resolve();
let startupPreferenceWarning: string | null = null;
let shutdownRequested = false;
const library = new LibraryController([new SteamStoreProvider()]);
const orbit = new OrbitSearchService();
const layoutController = new LayoutController(new LayoutStore(path.join(app.getPath('userData'), 'control-layouts.json')));
const pinManager = new PinManager();
const aiPatcher = new AiPatcher();
let pairingStore: PairingStore | null = null;
let hostDeviceId: string | null = null;

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    if (mainWindow.isMinimized()) mainWindow.restore();
    if (!mainWindow.isVisible()) mainWindow.show();
    mainWindow.focus();
  });
}

function isTrustedSender(event: IpcMainInvokeEvent): boolean {
  return Boolean(
    mainWindow &&
      !mainWindow.isDestroyed() &&
      event.sender === mainWindow.webContents &&
      lifecycle.canAcceptWork()
  );
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}

function serializeConfigMutation<T>(work: () => Promise<T>): Promise<T> {
  const operation = configMutationQueue.then(work, work);
  configMutationQueue = operation.then(() => undefined, () => undefined);
  return operation;
}

async function reconcileWindowsStartup(enabled: boolean): Promise<void> {
  startupPreferenceWarning = null;
  if (process.platform !== 'win32' || !app.isPackaged) return;
  try {
    app.setLoginItemSettings({ openAtLogin: enabled });
    const actual = app.getLoginItemSettings();
    if (Boolean(actual.openAtLogin) !== enabled) {
      startupPreferenceWarning = 'Windows did not confirm the startup preference. Check the app startup registration.';
      await log('WARN', 'Windows startup preference did not match saved config', { requested: enabled, actual: actual.openAtLogin });
    }
  } catch (error) {
    startupPreferenceWarning = 'Settings were saved, but the Windows startup preference could not be applied.';
    await log('WARN', 'Could not apply Windows startup preference', { error: String(error) });
  }
}

async function commitConfig(next: HostConfig): Promise<HostConfig> {
  const previousStartWithWindows = config.startWithWindows;
  const saved = await saveConfig(next);
  config = saved;
  if (previousStartWithWindows !== saved.startWithWindows) {
    await reconcileWindowsStartup(saved.startWithWindows);
  }
  return config;
}

type PublicCover = { mime: string; url: string };
type PublicMetadata = {
  title: string;
  description: string;
  genres: string[];
  gameType: string;
  platform: string;
  provider: string;
  sourceUrl: string;
  cover?: PublicCover;
  releaseDate?: string;
  shortDescription?: string;
  developers?: string[];
  publishers?: string[];
  screenshots?: string[];
};
type PublicGame = {
  id: string;
  name: string;
  status: string;
  metadata?: PublicMetadata;
  playTimeSeconds: number;
  lastPlayedAt?: string;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
};

function publicGame(game: {
  id: string;
  name: string;
  status: string;
  metadata?: {
    title: string;
    description: string;
    genres: string[];
    gameType: string;
    platform: string;
    provider: string;
    sourceUrl: string;
    cover?: { path: string; mime: string };
    releaseDate?: string;
    shortDescription?: string;
    developers?: string[];
    publishers?: string[];
    screenshots?: Array<{ file: string; mime: string }>;
  };
  playTimeSeconds: number;
  lastPlayedAt?: string;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}): PublicGame {
  const metadata: PublicMetadata | undefined = game.metadata
    ? {
        title: game.metadata.title,
        description: game.metadata.description,
        genres: Array.isArray(game.metadata.genres) ? game.metadata.genres : [],
        gameType: game.metadata.gameType,
        platform: game.metadata.platform,
        provider: game.metadata.provider,
        sourceUrl: game.metadata.sourceUrl,
        releaseDate: game.metadata.releaseDate,
        shortDescription: game.metadata.shortDescription,
        developers: game.metadata.developers,
        publishers: game.metadata.publishers,
        screenshots: Array.isArray(game.metadata.screenshots) ? game.metadata.screenshots.map((_s, i) => `nexora-cover://${game.id}/shot/${i + 1}`) : undefined,
        cover: game.metadata.cover
          ? { mime: game.metadata.cover.mime, url: `nexora-cover://${game.id}` }
          : undefined
      }
    : undefined;
  return {
    id: game.id,
    name: game.name,
    status: game.status,
    metadata,
    playTimeSeconds: game.playTimeSeconds,
    lastPlayedAt: game.lastPlayedAt,
    pinned: game.pinned,
    createdAt: game.createdAt,
    updatedAt: game.updatedAt
  };
}

async function registerCoverProtocol(): Promise<void> {
  protocol.handle('nexora-cover', async (request) => {
    const url = new URL(request.url);
    const match = url.hostname.match(/^game_[a-f0-9]{24}$/);
    if (!match) return new Response('Not found', { status: 404 });
    const userData = app.getPath('userData');
    const mimeFor = (ext: string) => ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg';
    // nexora-cover://<gameId>/shot/<n>  ->  screenshot n (1-based) saved by NEXORA ORBIT
    const shot = url.pathname.match(/^\/shot\/([1-9]\d?)$/);
    if (shot) {
      const n = String(Number(shot[1])).padStart(2, '0');
      for (const ext of ['jpg', 'png', 'webp']) {
        try {
          const bytes = await readFile(path.join(userData, 'shots', match[0], `${n}.${ext}`));
          return new Response(new Uint8Array(bytes), { status: 200, headers: { 'content-type': mimeFor(ext), 'cache-control': 'no-store' } });
        } catch { /* try next */ }
      }
      return new Response('Not found', { status: 404 });
    }
    if (url.pathname !== '' && url.pathname !== '/') return new Response('Not found', { status: 404 });
    for (const ext of ['jpg', 'png', 'webp']) {
      try {
        const bytes = await readFile(path.join(userData, 'covers', `${match[0]}.${ext}`));
        return new Response(new Uint8Array(bytes), { status: 200, headers: { 'content-type': mimeFor(ext), 'cache-control': 'no-store' } });
      } catch { /* try next */ }
    }
    return new Response('Not found', { status: 404 });
  });
}

ipcMain.handle('layout:list', async (event) => { if (!isTrustedSender(event)) throw new Error('Untrusted sender'); return layoutController.list(); });
ipcMain.handle('layout:save', async (event, layout) => { if (!isTrustedSender(event)) throw new Error('Untrusted sender'); return layoutController.save(layout); });
ipcMain.handle('layout:remove', async (event, id) => { if (!isTrustedSender(event)) throw new Error('Untrusted sender'); return layoutController.remove(String(id)); });

function createWindow(): BrowserWindow {
  // Host UI follows the display work area (not stream resolution).
  const display = screen.getPrimaryDisplay();
  const work = display.workAreaSize;
  // Opens at 1080p (or the biggest size the screen allows).
  const width = Math.min(work.width, 1920);
  const height = Math.min(work.height, 1080);
  const window = new BrowserWindow({
    width,
    height,
    minWidth: 760,
    minHeight: 560,
    show: false,
    frame: false,
    backgroundColor: '#071018',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      webviewTag: false,
      allowRunningInsecureContent: false,
      devTools: !app.isPackaged
    }
  });

  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  window.webContents.on('will-navigate', (event) => event.preventDefault());
  window.webContents.on('will-attach-webview', (event) => event.preventDefault());
  window.webContents.on('did-fail-load', (_event, errorCode, _errorDescription, _validatedURL, isMainFrame) => {
    if (isMainFrame) void log('WARN', 'Renderer failed to load', { errorCode });
  });
  window.once('ready-to-show', () => window.show());
  window.on('closed', () => {
    if (mainWindow === window) mainWindow = null;
  });
  void window.loadFile(path.join(__dirname, 'ui', 'index.html'));
  return window;
}

async function bootstrap(): Promise<void> {
  if (!gotLock) return;
  await app.whenReady();
  app.setAppUserModelId('com.nexora.host');
  await initLogger();
  await registerCoverProtocol();
  config = await loadConfig();
  await reconcileWindowsStartup(config.startWithWindows);
  await library.init();
  await layoutController.ensureDefaults();
  keyMapStore = new KeyMapStore(path.join(app.getPath('userData'), 'keymaps.json'));
  await keyMapStore.load();
  keyMapper = new KeyMapper();
  keyMapper.setProfile(keyMapStore.getActiveProfile());
  keyMapper.setDirection(keyMapStore.getDirection());
  try {
    const kb = new WindowsInputSink();
    const pad = new VirtualGamepadSink();
    const sink = new CompositeInputSink(kb.available ? kb : null, pad.available ? pad : null);
    inputManager = new InputManager(sink);
    inputManager.setKeyMapper(keyMapper);
    await log('INFO', 'Input pipeline ready', {
      keyboard: kb.available,
      virtualGamepad: pad.available,
      mapMode: keyMapStore.snapshot().mode
    });
  } catch (error) {
    inputManager = null;
    await log('WARN', 'Input pipeline unavailable', { error: String(error) });
  }
  try {
    const identity = await loadOrCreateIdentity(app.getPath('userData'));
    hostDeviceId = identity.deviceId;
    pairingStore = new PairingStore(path.join(app.getPath('userData'), 'pairing'));
    await pairingStore.init();
    await log('INFO', 'Host identity ready', { deviceId: hostDeviceId });
  } catch (error) {
    await log('ERROR', 'Host identity failed', { error: String(error) });
    throw error;
  }
  try {
    const orbitDir = path.join(app.getPath('userData'), 'orbit');
    const enabled = await loadOrbitKeys(orbitDir);
    const aliases = await loadOrbitAliases(path.join(orbitDir, 'aliases.json'));
    if (Object.keys(aliases).length) (await import('./orbit/orbit-lib.mjs')).setAliases(aliases);
    await log('INFO', 'NEXORA ORBIT ready', { extraSources: enabled, aliases: Object.keys(aliases).length });
  } catch (error) {
    await log('WARN', 'NEXORA ORBIT optional setup failed', { error: String(error) });
  }

  session.defaultSession.setPermissionRequestHandler((_wc, _permission, callback) => callback(false));
  session.defaultSession.setPermissionCheckHandler(() => false);

  ipcMain.handle('config:get', (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    return config;
  });

  ipcMain.handle('config:set', async (event, value: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    return serializeConfigMutation(async () => commitConfig(mergeConfigPatch(config, value)));
  });

  ipcMain.handle('settings:capabilities', (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    return {
      platform: process.platform,
      packaged: app.isPackaged,
      startupSupported: process.platform === 'win32' && app.isPackaged,
      startupWarning: startupPreferenceWarning,
      storagePath: path.join(app.getPath('userData'), 'config.json')
    };
  });

  ipcMain.handle('settings:export', async (event) => {
    if (!isTrustedSender(event) || !mainWindow) throw new Error('Unauthorized IPC request');
    const result = await dialog.showSaveDialog(mainWindow, {
      title: 'Export NEXORA settings',
      defaultPath: path.join(app.getPath('documents'), 'NEXORA-settings.json'),
      filters: [{ name: 'NEXORA settings', extensions: ['json'] }]
    });
    if (result.canceled || !result.filePath) return { cancelled: true };
    const payload = {
      app: 'NEXORA',
      schemaVersion: 1,
      exportedAt: new Date().toISOString(),
      config
    };
    await writeFile(result.filePath, JSON.stringify(payload, null, 2), { encoding: 'utf8', mode: 0o600 });
    return { cancelled: false, fileName: path.basename(result.filePath) };
  });

  ipcMain.handle('settings:import', async (event) => {
    if (!isTrustedSender(event) || !mainWindow) throw new Error('Unauthorized IPC request');
    const result = await dialog.showOpenDialog(mainWindow, {
      title: 'Import NEXORA settings',
      properties: ['openFile'],
      filters: [{ name: 'NEXORA settings', extensions: ['json'] }]
    });
    const [filePath] = result.filePaths;
    if (result.canceled || !filePath) return { cancelled: true };
    const info = await stat(filePath);
    if (!info.isFile() || info.size > 512 * 1024) throw new Error('Settings file is invalid or too large (maximum 512 KB).');
    let parsed: unknown;
    try {
      parsed = JSON.parse(await readFile(filePath, 'utf8'));
    } catch {
      throw new Error('The selected settings file is not valid JSON. Your current settings were not changed.');
    }
    let candidate: unknown = parsed;
    if (isRecord(parsed) && parsed.app === 'NEXORA') {
      if (parsed.schemaVersion !== 1 || !isRecord(parsed.config) || (parsed.config.version !== 2 && parsed.config.version !== 3)) {
        throw new Error('Unsupported NEXORA settings file version.');
      }
      candidate = parsed.config;
    } else if (!isRecord(parsed) || (parsed.version !== 2 && parsed.version !== 3)) {
      throw new Error('Choose a valid NEXORA settings backup.');
    }
    if (!isRecord(candidate)) throw new Error('Settings file contents are invalid.');
    const normalized = normalize(candidate);
    const saved = await serializeConfigMutation(async () => commitConfig(normalized));
    return { cancelled: false, config: saved };
  });

  ipcMain.handle('settings:reset', async (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    const defaults = normalize(DEFAULT_CONFIG);
    return serializeConfigMutation(async () => commitConfig(defaults));
  });

  // AI patch assistant: secrets stay encrypted in the main process; patches require explicit review.
  ipcMain.handle('ai-patcher:get-settings', async (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    return aiPatcher.getSettings();
  });
  ipcMain.handle('ai-patcher:set-settings', async (event, value: unknown) => {
    if (!isTrustedSender(event) || !value || typeof value !== 'object') throw new Error('Unauthorized or invalid request');
    return aiPatcher.setSettings(value as { provider?: unknown; model?: unknown; workspace?: unknown; apiKey?: unknown });
  });
  ipcMain.handle('ai-patcher:choose-workspace', async (event) => {
    if (!isTrustedSender(event) || !mainWindow) throw new Error('Unauthorized IPC request');
    const result = await dialog.showOpenDialog(mainWindow, { title: 'Choose project source folder', properties: ['openDirectory', 'createDirectory'] });
    if (result.canceled || !result.filePaths[0]) return { cancelled: true };
    await aiPatcher.chooseWorkspace(result.filePaths[0]);
    return { cancelled: false, settings: await aiPatcher.getSettings() };
  });
  ipcMain.handle('ai-patcher:propose', async (event, request: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    return aiPatcher.createProposal(request);
  });
  ipcMain.handle('ai-patcher:apply', async (event, id: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    return aiPatcher.applyProposal(id);
  });
  ipcMain.handle('ai-patcher:discard', (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    aiPatcher.discardProposal(); return true;
  });
  ipcMain.handle('ai-patcher:rollback', async (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    return aiPatcher.rollbackLastPatch();
  });
  ipcMain.handle('ai-patcher:check', async (event, check: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    return aiPatcher.runCheck(check);
  });

  ipcMain.handle('library:list', async (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    await library.init();
    return library.list().map(publicGame);
  });

  ipcMain.handle('library:add-dialog', async (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    const result = await dialog.showOpenDialog(mainWindow!, { properties: ['openFile'], filters: [{ name: 'Windows games', extensions: ['exe'] }] });
    if (result.canceled || !result.filePaths[0]) return { status: 'cancelled', candidates: [], reasons: [] };
    const outcome = await library.addExecutable(result.filePaths[0]);
    return { ...outcome, game: outcome.game ? publicGame(outcome.game) : undefined };
  });

  ipcMain.handle('library:select-candidate', async (event, pendingId: unknown, index: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    if (typeof pendingId !== 'string' || !/^game_[a-f0-9]{24}$/.test(pendingId) || typeof index !== 'number') throw new Error('Invalid metadata selection');
    const outcome = await library.selectCandidate(pendingId, index);
    return { ...outcome, game: outcome.game ? publicGame(outcome.game) : undefined };
  });

  // ---- NEXORA ORBIT add-game flow: pick .exe -> live background search while typing -> pick 1 of 3 -> load the rest
  const PENDING_ID = /^game_[a-f0-9]{24}$/;

  ipcMain.handle('library:begin-add', async (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    const result = await dialog.showOpenDialog(mainWindow!, { properties: ['openFile'], filters: [{ name: 'Windows games', extensions: ['exe'] }] });
    if (result.canceled || !result.filePaths[0]) return { status: 'cancelled' };
    const begun = await library.beginAdd(result.filePaths[0]);
    if (begun.status === 'exists') return { status: 'exists', game: publicGame(begun.game) };
    orbit.openSession(begun.pendingId);
    void loadDefaultOrbitApi().catch(() => undefined); // warm up the Orbit library so the first search starts instantly
    return { status: 'ready', pendingId: begun.pendingId, suggestedName: begun.suggestedName, exeFile: begun.exeFile };
  });

  ipcMain.handle('orbit:search', async (event, pendingId: unknown, query: unknown, requestId: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    if (typeof pendingId !== 'string' || !PENDING_ID.test(pendingId) || typeof query !== 'string' || query.length > ORBIT_MAX_QUERY * 2 || typeof requestId !== 'number') throw new Error('Invalid search request');
    if (!library.hasAdd(pendingId)) return { status: 'unknown-session' };
    return orbit.search(pendingId, query, requestId);
  });

  ipcMain.handle('orbit:choose', async (event, pendingId: unknown, requestId: unknown, index: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    if (typeof pendingId !== 'string' || !PENDING_ID.test(pendingId) || typeof requestId !== 'number' || typeof index !== 'number') throw new Error('Invalid selection');
    if (!library.hasAdd(pendingId)) return { status: 'rejected', reasons: ['This add-game session expired. Start again.'] };
    const sender = event.sender;
    const loaded = await orbit.loadSelection(pendingId, requestId, index, (stage, detail) => {
      if (!sender.isDestroyed()) sender.send('orbit:progress', { pendingId, stage, detail: detail ?? null });
    });
    if (loaded.status !== 'loaded') return { status: 'rejected', reasons: loaded.reasons };
    if (!sender.isDestroyed()) sender.send('orbit:progress', { pendingId, stage: 'saving', detail: null });
    const committed = await library.commitOrbit(pendingId, loaded.loaded);
    if (committed.status !== 'accepted') return { status: 'rejected', reasons: committed.reasons };
    orbit.closeSession(pendingId);
    return { status: 'accepted', game: publicGame(committed.game), notices: loaded.loaded.notices };
  });

  ipcMain.handle('orbit:cancel', async (event, pendingId: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    if (typeof pendingId !== 'string' || !PENDING_ID.test(pendingId)) return false;
    orbit.closeSession(pendingId);
    library.discardAdd(pendingId);
    return true;
  });

  ipcMain.handle('library:remove', async (event, id: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    if (typeof id !== 'string') throw new Error('Invalid game ID');
    return library.remove(id);
  });

  ipcMain.handle('library:pin', async (event, id: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    if (typeof id !== 'string') throw new Error('Invalid game ID');
    const game = await library.pin(id);
    return game ? publicGame(game) : null;
  });

  ipcMain.handle('library:mark-played', async (event, id: unknown, deltaSeconds: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    if (typeof id !== 'string') throw new Error('Invalid game ID');
    const delta = typeof deltaSeconds === 'number' && Number.isFinite(deltaSeconds) ? deltaSeconds : 0;
    const game = await library.markPlayed(id, delta);
    return game ? publicGame(game) : null;
  });

  ipcMain.handle('devices:list', async (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    if (!pairingStore) return [];
    await pairingStore.init();
    return pairingStore.list().map(d => ({
      deviceId: d.deviceId,
      name: d.name,
      pairedAt: d.pairedAt,
      lastSeenAt: d.lastSeenAt
    }));
  });

  ipcMain.handle('devices:revoke', async (event, deviceId: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    if (typeof deviceId !== 'string' || !/^[a-f0-9]{32}$/.test(deviceId)) throw new Error('Invalid device ID');
    if (!pairingStore) return false;
    return pairingStore.revoke(deviceId);
  });

  ipcMain.handle('pairing:open', async (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    const opened = pinManager.open();
    await log('INFO', 'Pairing PIN opened', { expiresAt: opened.expiresAt, hostDeviceId });
    return { pin: opened.pin, expiresAt: opened.expiresAt, hostDeviceId };
  });

  ipcMain.handle('pairing:status', async (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    const open = pinManager.inspect();
    return { open: Boolean(open), expiresAt: open?.expiresAt ?? null, hostDeviceId };
  });


  ipcMain.handle('keymap:get', async (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    return keyMapStore.snapshot();
  });
  ipcMain.handle('keymap:set-mode', async (event, mode: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    const m = mode === 'off' ? 'off' : mode === 'keyboard' ? 'keyboard' : 'controller';
    const state = await keyMapStore.setMode(m);
    keyMapper.setProfile(keyMapStore.getActiveProfile());
    keyMapper.setDirection(keyMapStore.getDirection());
    inputManager?.setKeyMapper(keyMapper);
    return state;
  });
  ipcMain.handle('keymap:set-active', async (event, id: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    const state = await keyMapStore.setActiveProfile(String(id));
    keyMapper.setProfile(keyMapStore.getActiveProfile());
    keyMapper.setDirection(keyMapStore.getDirection());
    inputManager?.setKeyMapper(keyMapper);
    return state;
  });
  ipcMain.handle('keymap:save-profile', async (event, profile: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    const state = await keyMapStore.upsertProfile(profile);
    keyMapper.setProfile(keyMapStore.getActiveProfile());
    keyMapper.setDirection(keyMapStore.getDirection());
    inputManager?.setKeyMapper(keyMapper);
    return state;
  });
  ipcMain.handle('keymap:reset-profile', async (event, id: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    const state = await keyMapStore.resetProfile(String(id));
    keyMapper.setProfile(keyMapStore.getActiveProfile());
    keyMapper.setDirection(keyMapStore.getDirection());
    inputManager?.setKeyMapper(keyMapper);
    return state;
  });

  ipcMain.handle('app:version', (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    return app.getVersion();
  });

  ipcMain.handle('window:minimize', (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    mainWindow?.minimize();
  });
  ipcMain.handle('window:maximize', (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    if (!mainWindow || mainWindow.isDestroyed()) return false;
    if (mainWindow.isMaximized()) mainWindow.unmaximize();
    else mainWindow.maximize();
    return mainWindow.isMaximized();
  });
  ipcMain.handle('window:close', (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    mainWindow?.close();
  });
  ipcMain.handle('window:is-maximized', (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    return Boolean(mainWindow && !mainWindow.isDestroyed() && mainWindow.isMaximized());
  });

  const updateSettingsDir = () => path.join(app.getPath('userData'), 'update');
  const releaseScript = (name: string) => path.join(__dirname, 'release', name);
  const notInstalledReason = 'Updates only work in the installed NEXORA app.';

  ipcMain.handle('update:check', async (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    const settings = await loadUpdateSettings(updateSettingsDir());
    if (!isUpdateConfigured(settings)) return { available: false, manifest: null, reason: 'Update service not configured' };
    return checkUpdate(app.getVersion(), settings.manifestUrl, settings.publicKeyB64);
  });

  ipcMain.handle('update:get-settings', async (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    const settings = await loadUpdateSettings(updateSettingsDir());
    const envLocked = Boolean(process.env.NEXORA_UPDATE_MANIFEST_URL || process.env.NEXORA_UPDATE_PUBLIC_KEY_B64);
    return {
      manifestUrl: settings.manifestUrl,
      publicKeyConfigured: Boolean(settings.publicKeyB64),
      configured: isUpdateConfigured(settings),
      envLocked,
      packaged: app.isPackaged
    };
  });

  ipcMain.handle('update:set-settings', async (event, raw: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    if (process.env.NEXORA_UPDATE_MANIFEST_URL || process.env.NEXORA_UPDATE_PUBLIC_KEY_B64) {
      throw new Error('Update settings are locked by environment variables on this install.');
    }
    const body = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw as Record<string, unknown> : {};
    const saved = await saveUpdateSettings(updateSettingsDir(), {
      manifestUrl: typeof body.manifestUrl === 'string' ? body.manifestUrl : undefined,
      publicKeyB64: typeof body.publicKeyB64 === 'string' ? body.publicKeyB64 : undefined
    });
    return { configured: isUpdateConfigured(saved), manifestUrl: saved.manifestUrl, publicKeyConfigured: Boolean(saved.publicKeyB64) };
  });

  ipcMain.handle('system:stats', (event) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    return readStats();
  });

  // Update from a file (patch zip, after saving a backup zip) or restore a backup zip. No technical steps for the user.
  ipcMain.handle('update:from-file', async (event, mode: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    if (mode !== 'patch' && mode !== 'restore') throw new Error('Invalid update mode');
    if (!app.isPackaged) return { status: 'unavailable', reason: notInstalledReason };
    const pick = await dialog.showOpenDialog(mainWindow!, {
      title: mode === 'patch' ? 'Choose the NEXORA patch (.zip)' : 'Choose a NEXORA backup (.zip)',
      properties: ['openFile'],
      filters: [{ name: 'Zip file', extensions: ['zip'] }]
    });
    if (pick.canceled || !pick.filePaths[0]) return { status: 'cancelled' };
    const packagePath = pick.filePaths[0];
    try { await assertZipFile(packagePath); } catch (error) { return { status: 'rejected', reason: error instanceof Error ? error.message : 'That file cannot be used.' }; }
    const installDir = path.dirname(process.execPath);
    let backupZip: string | undefined;
    if (mode === 'patch') {
      const stamp = new Date().toISOString().slice(0, 10);
      const save = await dialog.showSaveDialog(mainWindow!, {
        title: 'Where should NEXORA save a backup of the current version?',
        defaultPath: path.join(app.getPath('documents'), `NEXORA-backup-${app.getVersion()}-${stamp}.zip`),
        filters: [{ name: 'Zip file', extensions: ['zip'] }]
      });
      if (save.canceled || !save.filePath) return { status: 'cancelled' };
      const chosen: string = /\.zip$/i.test(save.filePath) ? save.filePath : `${save.filePath}.zip`;
      backupZip = chosen;
      if (isInsideFolder(installDir, chosen)) return { status: 'rejected', reason: 'Please save the backup outside the NEXORA folder.' };
    }
    const scriptPath = await stageUpdaterScript(releaseScript('apply-local-update.ps1'));
    launchLocalUpdater({ mode, packagePath, backupZip, installDir, currentPid: process.pid, scriptPath });
    shutdownRequested = true;
    void lifecycle.shutdown(async () => {
      await log('INFO', 'Local updater launched', { mode });
    }).then(() => app.exit(0));
    return { status: 'started' };
  });

  ipcMain.handle('update:stage', async (event, rawManifest: unknown) => {
    if (!isTrustedSender(event)) throw new Error('Unauthorized IPC request');
    if (!app.isPackaged) throw new Error(notInstalledReason);
    const manifest: UpdateManifest = validateManifest(rawManifest);
    const settings = await loadUpdateSettings(updateSettingsDir());
    if (!(settings.publicKeyB64 ? verifyManifestSignature(manifest, settings.publicKeyB64) : verifyManifestSignature(manifest))) throw new Error('Invalid update signature');
    if (compareVersions(manifest.version, app.getVersion()) <= 0) throw new Error('Update is not newer than the installed version');
    const packagePath = await downloadAndStage(manifest);
    const scriptPath = await stageUpdaterScript(releaseScript('apply-update.ps1'));
    launchExternalUpdater({ packagePath, installDir: path.dirname(process.execPath), currentPid: process.pid, expectedSha256: manifest.sha256, version: manifest.version, scriptPath });
    shutdownRequested = true;
    void lifecycle.shutdown(async () => {
      await log('INFO', 'External updater launched', { version: manifest.version });
    }).then(() => app.exit(0));
    return { staged: true, version: manifest.version };
  });

  mainWindow = createWindow();
  lifecycle.markRunning();
  await log('INFO', 'NEXORA Host started', { version: app.getVersion() });
}

app.on('before-quit', (event) => {
  if (shutdownRequested) return;
  shutdownRequested = true;
  event.preventDefault();
  void lifecycle.shutdown(async () => {
    await log('INFO', 'NEXORA Host shutting down');
    try { mainWindow?.destroy(); } catch { /* already gone */ }
    mainWindow = null;
  }).then(() => app.exit(0)).catch(async (error) => {
    await log('ERROR', 'Shutdown failed', { error: String(error) });
    app.exit(1);
  });
});

void bootstrap().catch(async (error) => {
  try { await initLogger(); } catch { /* logger may be unavailable during early failure */ }
  await log('ERROR', 'Fatal startup error', { error: String(error) });
  app.exit(1);
});

export { config, normalize };
