import type { MetadataCandidate, MetadataProvider } from './metadata.js';

const MAX_COVER_BYTES = 5 * 1024 * 1024;
const SEARCH_URL = 'https://store.steampowered.com/api/storesearch/';
const APP_URL = 'https://store.steampowered.com/api/appdetails';
const COVER_HOSTS = new Set(['steamstatic.com', 'akamai.steamstatic.com', 'cdn.akamai.steamstatic.com']);

type FetchLike = typeof fetch;

function withTimeout(signal: AbortSignal | undefined, ms: number): AbortSignal {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  if (signal) {
    if (signal.aborted) controller.abort();
    else signal.addEventListener('abort', () => controller.abort(), { once: true });
  }
  void controller.signal.addEventListener('abort', () => clearTimeout(timer), { once: true });
  return controller.signal;
}

function text(value: unknown): string { return typeof value === 'string' ? value.trim() : ''; }

async function json<T>(fetcher: FetchLike, url: string, signal: AbortSignal): Promise<T> {
  const response = await fetcher(url, { signal, headers: { accept: 'application/json' } });
  if (!response.ok) throw new Error(`Steam HTTP ${response.status}`);
  return await response.json() as T;
}

async function downloadCover(fetcher: FetchLike, url: string, signal: AbortSignal): Promise<{bytes: Uint8Array; mime: string}> {
  const parsed = new URL(url);
  if (parsed.protocol !== 'https:' || ![...COVER_HOSTS].some(host => parsed.hostname === host || parsed.hostname.endsWith(`.${host}`))) throw new Error('Untrusted cover host');
  const response = await fetcher(url, { signal, headers: { accept: 'image/avif,image/webp,image/jpeg,image/png;q=0.9,*/*;q=0.1' } });
  if (!response.ok) throw new Error(`Cover HTTP ${response.status}`);
  const contentLength = Number(response.headers.get('content-length') || '0');
  if (contentLength > MAX_COVER_BYTES) throw new Error('Cover too large');
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (!bytes.length || bytes.byteLength > MAX_COVER_BYTES) throw new Error('Cover too large or empty');
  const mime = text(response.headers.get('content-type')).split(';')[0] || 'image/jpeg';
  return { bytes, mime };
}

interface SearchResponse { total: number; items: Array<{id: number; name: string; tiny_image?: string}>; }
interface DetailResponse { [appid: string]: { success: boolean; data?: { name?: string; type?: string; detailed_description?: string; short_description?: string; header_image?: string; website?: string; genres?: Array<{description?: string}>; platforms?: {windows?: boolean; linux?: boolean; mac?: boolean}; release_date?: {date?: string}; }; }; }

export class SteamStoreProvider implements MetadataProvider {
  readonly id = 'steam';
  constructor(private readonly fetcher: FetchLike = fetch) {}

  async search(title: string, signal?: AbortSignal): Promise<MetadataCandidate[]> {
    const searchSignal = withTimeout(signal, 8000);
    const searchUrl = `${SEARCH_URL}?term=${encodeURIComponent(title)}&l=english&cc=us`;
    const result = await json<SearchResponse>(this.fetcher, searchUrl, searchSignal);
    const items = Array.isArray(result.items) ? result.items.slice(0, 8) : [];
    const candidates: MetadataCandidate[] = [];
    const concurrency = 3;
    let cursor = 0;
    const providerId = this.id;
    const fetcher = this.fetcher;

    async function loadOne(item: { id: number; name: string }): Promise<void> {
      try {
        const details = await json<DetailResponse>(fetcher, `${APP_URL}?appids=${item.id}&l=english`, withTimeout(signal, 8000));
        const data = details[String(item.id)]?.data;
        if (!details[String(item.id)]?.success || !data || data.type !== 'game' || !data.platforms?.windows || !data.header_image) return;
        const cover = await downloadCover(fetcher, data.header_image, withTimeout(signal, 8000));
        candidates.push({
          provider: providerId,
          title: text(data.name) || item.name,
          description: text(data.detailed_description) || text(data.short_description),
          genres: Array.isArray(data.genres) ? data.genres.map(g => text(g.description)).filter(Boolean) : [],
          gameType: 'game',
          platform: 'windows',
          sourceUrl: `https://store.steampowered.com/app/${item.id}/`,
          cover,
          releaseDate: text(data.release_date?.date),
          sourceConfidence: 0.9
        });
      } catch {
        // One broken candidate must not block others.
      }
    }

    async function worker(): Promise<void> {
      while (cursor < items.length) {
        const item = items[cursor++];
        if (!item?.id || !item.name) continue;
        await loadOne(item);
      }
    }

    await Promise.all(Array.from({ length: Math.min(concurrency, Math.max(1, items.length)) }, () => worker()));
    return candidates;
  }
}
