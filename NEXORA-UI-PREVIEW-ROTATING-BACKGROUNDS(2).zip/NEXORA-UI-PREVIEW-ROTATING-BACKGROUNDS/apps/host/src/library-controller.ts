import { createPendingGame, commitVerifiedGame, togglePinned, updatePlayState, type GameRecord } from './library.js';
import { acceptanceGate, detectCoverMime, resolveMetadata, type MetadataProvider } from './metadata.js';
import { loadLibrary, removeCover, removeScreenshots, saveCover, saveLibrary, saveScreenshots } from './library-store.js';
import { ORBIT_COVER_MAX_BYTES, type OrbitLoaded } from './orbit/orbit-search.js';
import { enhanceArtwork, type ArtworkMime } from './orbit/artwork-enhancer.js';

const PENDING_TTL_MS = 5 * 60 * 1000;
const PENDING_MAX = 20;
const ADD_TTL_MS = 10 * 60 * 1000;

export class LibraryController {
  private games: GameRecord[] = [];
  private loaded = false;
  private pending = new Map<string, { game: GameRecord; candidates: Awaited<ReturnType<typeof resolveMetadata>>['candidates']; createdAt: number }>();

  /** Executables the user picked and that are waiting for the NEXORA ORBIT match (not in the library yet). */
  private adds = new Map<string, { game: GameRecord; createdAt: number }>();

  constructor(private readonly providers: MetadataProvider[]) {}

  private purgeAdds(now = Date.now()): void {
    for (const [id, entry] of this.adds) if (now - entry.createdAt > ADD_TTL_MS) this.adds.delete(id);
    while (this.adds.size > PENDING_MAX) {
      const oldest = [...this.adds.entries()].sort((a, b) => a[1].createdAt - b[1].createdAt)[0];
      if (!oldest) break;
      this.adds.delete(oldest[0]);
    }
  }

  private purgePending(now = Date.now()): void {
    for (const [id, entry] of this.pending) {
      if (now - entry.createdAt > PENDING_TTL_MS) this.pending.delete(id);
    }
    while (this.pending.size > PENDING_MAX) {
      const oldest = [...this.pending.entries()].sort((a, b) => a[1].createdAt - b[1].createdAt)[0];
      if (!oldest) break;
      this.pending.delete(oldest[0]);
    }
  }

  async init(): Promise<void> {
    if (!this.loaded) { this.games = await loadLibrary(); this.loaded = true; }
  }

  list(): GameRecord[] { return this.games.filter(g => g.status === 'verified').map(g => ({ ...g })); }

  async addExecutable(exePath: string): Promise<{status: 'accepted'|'ambiguous'|'rejected'; game?: GameRecord; pendingId?: string; candidates: unknown[]; reasons: string[]}> {
    await this.init();
    const safePath = exePath.trim().toLowerCase();
    const existing = this.games.find(game => game.exePath.trim().toLowerCase() === safePath);
    if (existing) return { status: 'accepted', game: existing, candidates: [], reasons: ['already in library'] };
    const pending = createPendingGame(exePath);
    const result = await resolveMetadata(pending.name, this.providers);
    if (result.status === 'ambiguous') {
      this.purgePending();
      this.pending.set(pending.id, { game: pending, candidates: result.candidates, createdAt: Date.now() });
      return { status: 'ambiguous', pendingId: pending.id, candidates: result.candidates.map(({cover: _cover, ...candidate}) => candidate), reasons: result.reasons };
    }
    if (result.status !== 'accepted' || !result.selected) {
      return { status: 'rejected', candidates: result.candidates.map(({cover: _cover, ...candidate}) => candidate), reasons: result.reasons };
    }
    return await this.commitCandidate(pending, result.selected);
  }

  /** Step 1 of the ORBIT add flow: remember the picked .exe (nothing is saved yet). */
  async beginAdd(exePath: string): Promise<{ status: 'exists'; game: GameRecord } | { status: 'ready'; pendingId: string; suggestedName: string; exeFile: string }> {
    await this.init();
    this.purgeAdds();
    const pending = createPendingGame(exePath);
    const safePath = pending.exePath.toLowerCase();
    const existing = this.games.find(game => game.exePath.trim().toLowerCase() === safePath);
    if (existing) return { status: 'exists', game: existing };
    this.adds.set(pending.id, { game: pending, createdAt: Date.now() });
    return { status: 'ready', pendingId: pending.id, suggestedName: pending.name, exeFile: pending.exePath.split(/[\\/]/).pop() || pending.exePath };
  }

  hasAdd(pendingId: string): boolean {
    this.purgeAdds();
    return this.adds.has(pendingId);
  }

  discardAdd(pendingId: string): void {
    this.adds.delete(pendingId);
  }

  /** Final step: the user picked one of the 3 ORBIT options and the rest was loaded. Saves everything atomically. */
  async commitOrbit(pendingId: string, loaded: OrbitLoaded): Promise<{ status: 'accepted'; game: GameRecord } | { status: 'rejected'; reasons: string[] }> {
    await this.init();
    this.purgeAdds();
    const entry = this.adds.get(pendingId);
    if (!entry) return { status: 'rejected', reasons: ['This add-game session expired. Start again.'] };
    const pending = entry.game;
    if (!loaded.title.trim()) return { status: 'rejected', reasons: ['The selected match has no title.'] };
    if (this.games.some(g => g.exePath.trim().toLowerCase() === pending.exePath.toLowerCase())) {
      this.adds.delete(pendingId);
      return { status: 'rejected', reasons: ['This executable is already in your library.'] };
    }
    let cover: { path: string; mime: string } | undefined;
    let shots: Array<{ file: string; mime: string }> = [];
    try {
      if (loaded.cover) {
        const mime: ArtworkMime = loaded.cover.ext === 'png' ? 'image/png' : loaded.cover.ext === 'webp' ? 'image/webp' : 'image/jpeg';
        const artwork = await enhanceArtwork(loaded.cover.bytes, mime, `${pending.id}-cover`);
        cover = { path: await saveCover(pending.id, artwork.bytes, artwork.extension, ORBIT_COVER_MAX_BYTES), mime: artwork.mime };
      }
      if (loaded.screenshots.length) {
        const preparedShots: Array<{ bytes: Uint8Array; ext: string }> = [];
        for (const [index, shot] of loaded.screenshots.entries()) {
          const mime: ArtworkMime = shot.ext === 'png' ? 'image/png' : shot.ext === 'webp' ? 'image/webp' : 'image/jpeg';
          const artwork = await enhanceArtwork(shot.bytes, mime, `${pending.id}-shot-${index + 1}`);
          preparedShots.push({ bytes: artwork.bytes, ext: artwork.extension });
        }
        shots = await saveScreenshots(pending.id, preparedShots);
      }
      const game = commitVerifiedGame(pending, {
        title: loaded.title,
        description: loaded.description,
        genres: loaded.genres,
        gameType: 'game',
        platform: 'windows',
        provider: loaded.provider,
        sourceUrl: loaded.sourceUrl,
        cover,
        releaseDate: loaded.releaseDate || undefined,
        shortDescription: loaded.shortDescription || undefined,
        developers: loaded.developers.length ? loaded.developers : undefined,
        publishers: loaded.publishers.length ? loaded.publishers : undefined,
        screenshots: shots.length ? shots : undefined,
        orbit: {
          fetchedAt: loaded.fetchedAt,
          coverWidth: loaded.cover?.width,
          coverHeight: loaded.cover?.height,
          coverSource: loaded.cover?.source,
          coverFullQuality: loaded.cover?.fullQuality,
          notices: loaded.notices.slice(0, 10)
        }
      });
      this.games.push(game);
      try { await saveLibrary(this.games); }
      catch (error) { this.games = this.games.filter(item => item.id !== game.id); throw error; }
      this.adds.delete(pendingId);
      return { status: 'accepted', game };
    } catch (error) {
      await removeCover(pending.id);
      await removeScreenshots(pending.id);
      throw error;
    }
  }

  async selectCandidate(pendingId: string, index: number): Promise<{status: 'accepted'|'rejected'; game?: GameRecord; candidates: unknown[]; reasons: string[]}> {
    await this.init();
    this.purgePending();
    const pending = this.pending.get(pendingId);
    if (!pending || !Number.isInteger(index) || index < 0 || index >= pending.candidates.length) return { status: 'rejected', candidates: [], reasons: ['invalid or expired metadata selection'] };
    const candidate = pending.candidates[index];
    const result = await this.commitCandidate(pending.game, candidate);
    this.pending.delete(pendingId);
    return { status: result.status === 'accepted' ? 'accepted' : 'rejected', game: result.game, candidates: [], reasons: result.reasons };
  }

  private async commitCandidate(pending: GameRecord, selected: NonNullable<Awaited<ReturnType<typeof resolveMetadata>>['selected']>): Promise<{status: 'accepted'|'rejected'; game?: GameRecord; candidates: unknown[]; reasons: string[]}> {
    const gate = acceptanceGate(selected);
    if (!gate.ok || selected.score < 70) return { status: 'rejected', candidates: [], reasons: gate.reasons.length ? gate.reasons : ['metadata confidence too low'] };
    const detectedMime = detectCoverMime(selected.cover.bytes);
    if (!detectedMime) return { status: 'rejected', candidates: [], reasons: ['cover bytes failed image validation'] };
    const extension = detectedMime === 'image/png' ? 'png' : detectedMime === 'image/webp' ? 'webp' : 'jpg';
    const mime = detectedMime as ArtworkMime;
    const artwork = await enhanceArtwork(selected.cover.bytes, mime, `${pending.id}-cover`);
    const coverPath = await saveCover(pending.id, artwork.bytes, artwork.extension, ORBIT_COVER_MAX_BYTES);
    try {
      const game = commitVerifiedGame(pending, {
        title: selected.title,
        description: selected.description,
        genres: selected.genres,
        gameType: selected.gameType,
        platform: 'windows',
        provider: selected.provider,
        sourceUrl: selected.sourceUrl,
        cover: { path: coverPath, mime: artwork.mime },
        releaseDate: selected.releaseDate
      });
      this.games.push(game);
      try { await saveLibrary(this.games); }
      catch (error) { this.games = this.games.filter(item => item.id !== game.id); await removeCover(game.id); throw error; }
      return { status: 'accepted', game, candidates: [], reasons: selected.reasons };
    } catch (error) {
      await removeCover(pending.id);
      throw error;
    }
  }

  async remove(id: string): Promise<boolean> {
    await this.init();
    const before = this.games.length;
    this.games = this.games.filter(g => g.id !== id);
    if (before === this.games.length) return false;
    await removeCover(id);
    await removeScreenshots(id);
    await saveLibrary(this.games);
    return true;
  }

  async pin(id: string): Promise<GameRecord | undefined> {
    await this.init();
    const index = this.games.findIndex(g => g.id === id);
    if (index < 0) return undefined;
    this.games[index] = togglePinned(this.games[index]);
    await saveLibrary(this.games);
    return this.games[index];
  }

  /** Record that the user started a session (updates lastPlayedAt and optional play-time delta). */
  async markPlayed(id: string, deltaSeconds = 0): Promise<GameRecord | undefined> {
    await this.init();
    const index = this.games.findIndex(g => g.id === id);
    if (index < 0) return undefined;
    this.games[index] = updatePlayState(this.games[index], deltaSeconds);
    await saveLibrary(this.games);
    return this.games[index];
  }

}
