import { randomUUID } from 'node:crypto';

export type PeerState = 'new' | 'connecting' | 'connected' | 'disconnected' | 'closed';
export type SdpType = 'offer' | 'answer' | 'rollback';
export interface IceCandidateInit { candidate: string; sdpMid: string | null; sdpMLineIndex: number | null; usernameFragment?: string | null; }
export interface SessionDescription { type: SdpType; sdp: string; }
export interface WebRtcTransportAdapter {
  createOffer(): Promise<SessionDescription>; createAnswer(): Promise<SessionDescription>;
  setLocalDescription(description: SessionDescription): Promise<void>;
  setRemoteDescription(description: SessionDescription): Promise<void>;
  addIceCandidate(candidate: IceCandidateInit): Promise<void>; close(): Promise<void>;
}
export interface PeerSessionEvents { onLocalDescription?: (description: SessionDescription) => void; onIceCandidate?: (candidate: IceCandidateInit) => void; onState?: (state: PeerState) => void; }
const MAX_SDP = 256 * 1024;
function validateSdp(d: SessionDescription): SessionDescription {
  if (!['offer','answer','rollback'].includes(d.type)) throw new Error('Invalid SDP type');
  if (typeof d.sdp !== 'string' || d.sdp.length > MAX_SDP) throw new Error('Invalid SDP size');
  if (d.type !== 'rollback' && !d.sdp.includes('v=0')) throw new Error('Invalid SDP');
  return { type:d.type, sdp:d.sdp };
}
export class WebRtcPeerSession {
  readonly id = randomUUID(); private state: PeerState = 'new'; private generation = 0; private closed = false;
  constructor(private readonly transport: WebRtcTransportAdapter, private readonly events: PeerSessionEvents = {}) {}
  getState(): PeerState { return this.state; }
  private setState(next: PeerState): void { if (this.closed && next !== 'closed') return; this.state=next; this.events.onState?.(next); }
  async createOffer(): Promise<SessionDescription> { this.assertOpen(); const g=++this.generation; this.setState('connecting'); const d=validateSdp(await this.transport.createOffer()); if(g!==this.generation||this.closed) throw new Error('Stale WebRTC operation'); await this.transport.setLocalDescription(d); this.events.onLocalDescription?.(d); return d; }
  async acceptOffer(offer: SessionDescription): Promise<SessionDescription> { this.assertOpen(); const g=++this.generation; this.setState('connecting'); const r=validateSdp(offer); if(r.type!=='offer') throw new Error('Expected offer'); await this.transport.setRemoteDescription(r); const a=validateSdp(await this.transport.createAnswer()); if(g!==this.generation||this.closed) throw new Error('Stale WebRTC operation'); await this.transport.setLocalDescription(a); this.events.onLocalDescription?.(a); return a; }
  async acceptAnswer(answer: SessionDescription): Promise<void> { this.assertOpen(); const g=++this.generation; const r=validateSdp(answer); if(r.type!=='answer') throw new Error('Expected answer'); await this.transport.setRemoteDescription(r); if(g!==this.generation||this.closed) throw new Error('Stale WebRTC operation'); this.setState('connected'); }
  async addIceCandidate(c: IceCandidateInit): Promise<void> { this.assertOpen(); if(typeof c.candidate!=='string'||c.candidate.length>8192) throw new Error('Invalid ICE candidate'); await this.transport.addIceCandidate(c); }
  markDisconnected(): void { if(!this.closed)this.setState('disconnected'); } markConnected(): void { if(!this.closed)this.setState('connected'); }
  async close(): Promise<void> { if(this.closed)return; this.closed=true;++this.generation;await this.transport.close();this.setState('closed'); }
  private assertOpen(): void { if(this.closed)throw new Error('WebRTC session is closed'); }
}
