import { isValidInputEvent, type InputEvent } from '@nexora/shared';
import type { KeyMapper } from './key-mapper.js';

export interface InputSink { send(event: InputEvent): Promise<void>; releaseAll(): Promise<void>; }

export class InputManager {
  private lastSequence = -1;
  private readonly pressed = new Set<string>();
  private mapper: KeyMapper | null = null;

  constructor(private readonly sink: InputSink) {}

  setKeyMapper(mapper: KeyMapper | null): void {
    this.mapper = mapper;
  }

  async handle(event: InputEvent): Promise<boolean> {
    if (!isValidInputEvent(event)) return false;
    if (event.sequence <= this.lastSequence) return false;
    this.lastSequence = event.sequence;

    const events = this.mapper ? this.mapper.translate(event) : [event];
    if (!events.length) return true;

    for (const e of events) {
      const key = `${e.kind}:${e.code}`;
      if (e.action === 'down') this.pressed.add(key);
      if (e.action === 'up') this.pressed.delete(key);
      await this.sink.send(e);
    }
    return true;
  }

  async reset(): Promise<void> {
    this.lastSequence = -1;
    this.pressed.clear();
    this.mapper?.reset();
    await this.sink.releaseAll();
  }
}
