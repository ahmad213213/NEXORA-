export function createLayoutEditor(api, root) {
  let layouts=[]; let selected=null;
  async function refresh(){ layouts=await api.listLayouts(); if(!selected) selected=layouts[0]?.id; render(); }
  function render(){ root.replaceChildren(); const bar=document.createElement('div'); bar.className='layout-editor-bar';
    const title=document.createElement('strong'); title.textContent='CONTROL LAYOUTS'; bar.append(title);
    const select=document.createElement('select'); layouts.forEach(l=>{const o=document.createElement('option');o.value=l.id;o.textContent=l.name;select.append(o)}); select.value=selected||''; select.onchange=()=>{selected=select.value;render()};bar.append(select);root.append(bar);
    const l=layouts.find(x=>x.id===selected); if(!l)return; const canvas=document.createElement('div');canvas.className='layout-editor-canvas';
    l.controls.forEach(c=>{const el=document.createElement('button');el.textContent=c.label;el.dataset.id=c.id;el.style.left=`${c.x*100}%`;el.style.top=`${c.y*100}%`;el.style.width=`${c.width*100}%`;el.style.height=`${c.height*100}%`;el.style.opacity=String(c.opacity);el.onclick=()=>{c.opacity=c.opacity>.5?.45:.85;api.saveLayout(l).then(refresh)};canvas.append(el)});root.append(canvas);
  }
  return {refresh};
}
