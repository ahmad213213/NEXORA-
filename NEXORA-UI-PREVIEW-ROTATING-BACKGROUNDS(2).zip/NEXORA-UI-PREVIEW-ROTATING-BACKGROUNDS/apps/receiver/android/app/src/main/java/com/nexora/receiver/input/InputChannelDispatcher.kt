package com.nexora.receiver.input

import org.webrtc.DataChannel

class InputChannelDispatcher : InputDispatcher {
    private var sender: InputDataChannelSender? = null
    private var fallback: ((InputEvent) -> Unit)? = null

    fun attach(channel: DataChannel) { sender = InputDataChannelSender(channel) }
    fun onFallback(handler: (InputEvent) -> Unit) { fallback = handler }

    override fun dispatch(event: InputEvent) {
        sender?.send(event) ?: fallback?.invoke(event)
    }
}
