package com.nexora.receiver

import android.app.Activity
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import com.nexora.receiver.gameplay.ControlOverlayView
import com.nexora.receiver.gameplay.LandscapeGameplayController
import com.nexora.receiver.input.InputChannelDispatcher
import com.nexora.receiver.webrtc.WebRtcReceiver
import org.webrtc.EglBase
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

class MainActivity : Activity() {
    private lateinit var overlay: ControlOverlayView
    private lateinit var webRtc: WebRtcReceiver
    private lateinit var videoRenderer: SurfaceViewRenderer
    private lateinit var eglBase: EglBase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this)
        val dispatcher = InputChannelDispatcher()

        eglBase = EglBase.create()
        videoRenderer = SurfaceViewRenderer(this).apply {
            init(eglBase.eglBaseContext, null)
            setEnableHardwareScaler(true)
            setMirror(false)
        }
        root.addView(videoRenderer, FrameLayout.LayoutParams(-1, -1))

        webRtc = WebRtcReceiver(
            this,
            onLocalIce = { /* injected signaling layer forwards ICE */ },
            onState = { /* connection controller consumes peer state */ },
            onRemoteAudio = { track -> track.setEnabled(true) },
            onRemoteVideo = ::attachVideoTrack,
            onInputChannel = dispatcher::attach
        )

        overlay = ControlOverlayView(
            this, dispatcher, com.nexora.receiver.gameplay.DefaultLayouts.action()
        )
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        LandscapeGameplayController(this).enter(root)
    }

    private fun attachVideoTrack(track: VideoTrack) {
        track.setEnabled(true)
        track.addSink(videoRenderer)
    }

    override fun onDestroy() {
        if (::webRtc.isInitialized) webRtc.close()
        if (::videoRenderer.isInitialized) videoRenderer.release()
        if (::eglBase.isInitialized) eglBase.release()
        super.onDestroy()
    }
}
